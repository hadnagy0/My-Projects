﻿grammar MiniLang;

// ===== REGULI SINTACTICE (Parser Rules) =====

program
    : (globalDeclaration | functionDeclaration)* EOF
    ;

globalDeclaration
    : variableDeclaration
    ;

variableDeclaration
    : CONST? type ID ('=' expression)? ';'
    ;

functionDeclaration
    : type ID '(' parameterList? ')' '{' functionBody '}'
    ;

parameterList
    : parameter (',' parameter)*
    ;

parameter
    : type ID
    ;

functionBody
    : (variableDeclaration | statement)*
    ;

type
    : INT
    | FLOAT
    | DOUBLE
    | STRING_TYPE
    | VOID
    ;

statement
    : block
    | ifStatement
    | whileStatement
    | forStatement
    | returnStatement
    | expressionStatement
    | emptyStatement
    | assignmentStatement // Adăugat pentru siguranță la i++ sau atribuiri simple
    ;

block
    : '{' statement* '}'
    ;

ifStatement
    : IF '(' expression ')' statement (ELSE statement)?
    ;

whileStatement
    : WHILE '(' expression ')' statement
    ;

forStatement
    : FOR '(' forInit? ';' expression? ';' expression? ')' statement
    ;

forInit
    : variableDeclaration // Aceasta include deja ';' la final în regula ta
    | expression
    ;

forUpdate
    : expression
    ;

returnStatement
    : RETURN expression? ';'
    ;

expressionStatement
    : expression ';'
    ;

assignmentStatement
    : expression ';'
    ;

emptyStatement
    : ';'
    ;

// Ierarhia expresiilor pentru precedență corectă
expression
    : assignmentExpression
    ;

assignmentExpression
    : logicalOrExpression (assignmentOperator assignmentExpression)?
    ;

assignmentOperator
    : '=' | '+=' | '-=' | '*=' | '/=' | '%='
    ;

logicalOrExpression
    : logicalAndExpression ('||' logicalAndExpression)*
    ;

logicalAndExpression
    : equalityExpression ('&&' equalityExpression)*
    ;

equalityExpression
    : relationalExpression (('==' | '!=') relationalExpression)*
    ;

relationalExpression
    : additiveExpression (('<' | '>' | '<=' | '>=') additiveExpression)*
    ;

additiveExpression
    : multiplicativeExpression (('+' | '-') multiplicativeExpression)*
    ;

multiplicativeExpression
    : unaryExpression (('*' | '/' | '%') unaryExpression)*
    ;

unaryExpression
    : postfixExpression
    | '!' unaryExpression
    | '-' unaryExpression
    | '+' unaryExpression
    ;

postfixExpression
    : primaryExpression ('++' | '--')?
    ;

primaryExpression
    : '(' expression ')'
    | functionCall
    | ID
    | literal
    ;

functionCall
    : ID '(' argumentList? ')'
    ;

argumentList
    : expression (',' expression)*
    ;

literal
    : NUMBER
    | FLOAT_NUMBER
    | STRING_LITERAL
    ;

// ===== REGULI LEXICALE (Lexer Rules) =====

// Cuvinte cheie
INT         : 'int';
FLOAT       : 'float';
DOUBLE      : 'double';
STRING_TYPE : 'string';
CONST       : 'const';
VOID        : 'void';
IF          : 'if';
ELSE        : 'else';
FOR         : 'for';
WHILE       : 'while';
RETURN      : 'return';

// Operatori și Delimitatori
INC         : '++';
DEC         : '--';
ADD_ASSIGN  : '+=';
SUB_ASSIGN  : '-=';
MUL_ASSIGN  : '*=';
DIV_ASSIGN  : '/=';
MOD_ASSIGN  : '%=';
EQ          : '==';
NEQ         : '!=';
LE          : '<=';
GE          : '>=';
AND         : '&&';
OR          : '||';

// Identificatori
ID          : [a-zA-Z_][a-zA-Z0-9_]*;

// Constante numerice
FLOAT_NUMBER : [0-9]+ '.' [0-9]+;
NUMBER       : [0-9]+;

// Literali string
STRING_LITERAL : '"' ( ~["\\\r\n] | '\\' . )* '"';

// Comentarii (Skip înseamnă că Parser-ul le ignoră complet)
BLOCK_COMMENT : '/*' .*? '*/' -> skip;
LINE_COMMENT  : '//' ~[\r\n]* -> skip;

// Spații albe
WS : [ \t\r\n]+ -> skip;

// --- DETECTARE ERORI LEXICALE (La finalul fișierului!) ---

UNCLOSED_STRING
    : '"' ( ~["\\\r\n] | '\\' . )* ([\r\n] | EOF)
    ;

UNCLOSED_COMMENT
    : '/*' ( . )*? EOF
    ;

INVALID_CHAR
    : .
    ;