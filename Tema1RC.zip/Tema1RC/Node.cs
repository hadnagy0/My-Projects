﻿namespace Tema1;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

public class Node
{
    public int Id { get; }
    public Node NextNode { get; set; }
    public BlockingCollection<Frame> InQueue { get; } = new BlockingCollection<Frame>();
    public ConcurrentQueue<(int dest, string data)> MessagesToSend { get; } = new ConcurrentQueue<(int, string)>();
        
    private bool _running = true;
    
    private readonly Random Rnd = new Random();
    
    private const double NoiseProbability = 1.0; 

    public Node(int id)
    {
        Id = id;
    }

    public void Start()
    {
        Task.Run(() => RunNodeLogic());
    }
    
    public void Stop()
    {
        _running = false;
    }

    private void RunNodeLogic()
    {
        while (_running)
        {
            if (InQueue.TryTake(out Frame frame, 1000))
            {
                if (frame.IsBusy)
                {
                    ProcessBusyFrame(frame);
                }
                else
                {
                    ProcessIdleToken(frame);
                }
            }
        }
    }

    private void ProcessBusyFrame(Frame frame)
    {
        if (frame.DestId == Id)
        {
            frame.FsAddressRecognized = true;
            Console.WriteLine($"[Nod {Id}] DESTINATIE: Adresa recunoscuta de la Nodul {frame.SrcId}.");
            
            if (!string.IsNullOrEmpty(frame.DataPayload) && 
                CrcCalculator.CheckCrc(frame.DataPayload, CrcCalculator.Polynomial))
            {
                frame.FsFrameCopied = true;
                frame.Ack = true;
                Console.WriteLine($"[Nod {Id}] DESTINATIE: CRC Valid. Date acceptate (ACK).");
            }
            else
            {
                frame.Ack = false;
                Console.WriteLine($"[Nod {Id}] DESTINATIE: Eroare CRC! Date corupte (NACK).");
            }

            Thread.Sleep(500);
            NextNode.InQueue.Add(frame);
        }
        else if (frame.SrcId == Id)
        {
            Console.WriteLine($"[Nod {Id}] SURSA: Pachetul s-a intors.");
            if (frame.FsAddressRecognized)
            {
                if (frame.Ack)
                    Console.WriteLine($"[Nod {Id}] SURSA: Succes! Pachet confirmat de destinat ie.");
                else
                    Console.WriteLine($"[Nod {Id}] SURSA: Esec! Pachet respins (Zgomot pe traseu).");
            }
            else
            {
                Console.WriteLine($"[Nod {Id}] SURSA: Destinația nu a fost gasita în inel.");
            }

            Console.WriteLine($"[Nod {Id}] SURSA: Eliberez Jetonul Liber.\n");
            frame.MakeFree();
            Thread.Sleep(500);
            NextNode.InQueue.Add(frame);
        }
        else
        {
            Console.WriteLine($"[Nod {Id}] INTERMEDIAR: Cadru in tranzit ({frame.SrcId} -> {frame.DestId}).");
            ApplyNoise(frame);
            Thread.Sleep(500);
            NextNode.InQueue.Add(frame);
        }
    }

    private void ProcessIdleToken(Frame frame)
    {
        if (MessagesToSend.TryDequeue(out var msg))
        {
            Console.WriteLine($"\n[Nod {Id}] SURSA: Jeton capturat! Trimit '{msg.data}' catre Nodul {msg.dest}.");
            string encodedData = CrcCalculator.EncodeData(msg.data, CrcCalculator.Polynomial);
            frame.MakeBusy(Id, msg.dest, encodedData);
        }
        else
        {
            Thread.Sleep(100); 
        }
        
        NextNode.InQueue.Add(frame);
    }

    private void ApplyNoise(Frame frame)
    {
        if (Id == 2 && frame.IsBusy && Rnd.NextDouble() < NoiseProbability)
        {
            Console.WriteLine($"[!] ZGOMOT la Nodul {Id}: Un bit s-a inversat pe traseul catre Nodul {NextNode.Id}!");
            
            if (frame.DataPayload != null && frame.DataPayload.Length > 0)
            {
                int idx = Rnd.Next(frame.DataPayload.Length);
                char[] payloadChars = frame.DataPayload.ToCharArray();
                payloadChars[idx] = payloadChars[idx] == '0' ? '1' : '0';
                frame.DataPayload = new string(payloadChars);
            }
        }
    }
}
