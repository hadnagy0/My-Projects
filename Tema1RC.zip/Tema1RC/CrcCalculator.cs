﻿namespace Tema1;
using System;

public static class CrcCalculator
{
    public const string Polynomial = "1011";

    public static string EncodeData(string data, string poly)
    {
        if (string.IsNullOrEmpty(data)) return ""; 

        string appendedData = data + new string('0', poly.Length - 1);
        string remainder = Mod2Div(appendedData, poly);
        return data + remainder;
    }

    public static bool CheckCrc(string dataWithCrc, string poly)
    {
        if (string.IsNullOrEmpty(dataWithCrc)) return false;

        string remainder = Mod2Div(dataWithCrc, poly);
        
        return !remainder.Contains("1"); 
    }

    public static string Mod2Div(string dividend, string divisor)
    {
        if (dividend.Length < divisor.Length) return dividend;

        Console.WriteLine($"   [CRC START] Dividend: {dividend} / Divizor: {divisor}");
        
        int pick = divisor.Length;
        string tmp = dividend.Substring(0, pick);

        while (pick < dividend.Length)
        {
            if (tmp[0] == '1')
                tmp = Xor(divisor, tmp) + dividend[pick];
            else
                tmp = Xor(new string('0', divisor.Length), tmp) + dividend[pick];
            
            Console.WriteLine($"   [CRC Step] Rest curent: {tmp}");
            pick += 1;
        }

        if (tmp[0] == '1')
            tmp = Xor(divisor, tmp);
        else
            tmp = Xor(new string('0', divisor.Length), tmp);

        Console.WriteLine($"   [CRC FINAL] Rezultat (Rest): {tmp}");
        return tmp;
    }

    private static string Xor(string a, string b)
    {
        var result = "";
        
        for (int i = 1; i < b.Length; i++)
        {
            if (i < a.Length) 
                result += (a[i] == b[i]) ? "0" : "1";
        }
        return result;
    }
}
