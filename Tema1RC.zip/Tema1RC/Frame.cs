﻿namespace Tema1;

public class Frame
{
    public bool IsBusy { get; set; } = false;
    public int? SrcId { get; set; } = null;
    public int? DestId { get; set; } = null;
    public string DataPayload { get; set; } = null;
    
    public bool FsAddressRecognized { get; set; } = false;
    public bool FsFrameCopied { get; set; } = false;
    public bool Ack { get; set; } = false;
    
    public void MakeBusy(int src, int dest, string payload)
    {
        IsBusy = true;
        SrcId = src;
        DestId = dest;
        DataPayload = payload;
        FsAddressRecognized = false;
        FsFrameCopied = false;
        Ack = false;
    }
    
    public void MakeFree()
    {
        IsBusy = false;
        SrcId = null;
        DestId = null;
        DataPayload = null;
    }
}