﻿namespace Tema1;
using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== START SIMULARE TOKEN RING ===");
        
        int nodeCount = 10;
        var nodes = new Node[nodeCount];
        for (int i = 0; i < nodeCount; i++)
        {
            nodes[i] = new Node(i + 1);
        }

        for (int i = 0; i < nodes.Length; i++)
        {
            nodes[i].NextNode = nodes[(i + 1) % nodes.Length];
        }

        foreach (var node in nodes)
        {
            node.Start();
        }

        nodes[0].MessagesToSend.Enqueue((3, "110101"));
        nodes[1].MessagesToSend.Enqueue((4, "100010"));
        nodes[0].MessagesToSend.Enqueue((5, "111111")); 

        var initialToken = new Frame();
        nodes[0].InQueue.Add(initialToken);

        Thread.Sleep(25000); 

        Console.WriteLine("\n=== OPRIRE SIMULARE ===");
        foreach (var node in nodes)
        {
            node.Stop();
        }

        Console.WriteLine("Apasa orice tasta pentru a inchide...");
        Console.ReadKey();
    }
}
