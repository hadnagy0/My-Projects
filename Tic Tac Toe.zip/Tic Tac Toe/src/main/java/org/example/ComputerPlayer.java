package org.example;

import java.util.List;
import java.util.Random;

/**
 * Simple computer player: picks a random available move and applies it to the board.
 */
public class ComputerPlayer {
    private final Random rnd = new Random();

    /**
     * Make a move for the given symbol on the provided board.
     * Returns the move performed as {row, col} or null if no move possible.
     */
    public int[] makeMove(Board board, char symbol) {
        if (board == null) return null;
        List<int[]> moves = board.availableMoves();
        if (moves == null || moves.isEmpty()) return null;
        int idx = rnd.nextInt(moves.size());
        int[] mv = moves.get(idx);
        boolean ok = board.set(mv[0], mv[1], symbol);
        if (!ok) {
            // fallback: try to apply first available move
            for (int[] m : moves) {
                if (board.set(m[0], m[1], symbol)) return new int[]{m[0], m[1]};
            }
            return null;
        }
        return new int[]{mv[0], mv[1]};
    }
}
