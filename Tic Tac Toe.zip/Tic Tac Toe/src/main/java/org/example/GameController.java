package org.example;

import java.util.List;

public class GameController {
    private final Board board = new Board();
    private final ComputerPlayer ai = new ComputerPlayer();
    private boolean started = false;
    private boolean playerFirst = true;

    // New: player and ai symbols
    private char playerSymbol = 'X';
    private char aiSymbol = 'O';

    // Start a new game. Sets who goes first, resets the board and (if computer goes first) performs the AI move.
    public void start(boolean playerFirst) {
        this.playerFirst = playerFirst;
        board.reset();
        started = true;
        if (!playerFirst && !board.isFull()) {
            ai.makeMove(board, aiSymbol);
        }
    }

    // Reset game state and stop the game (waiting for a new start)
    public void reset() {
        board.reset();
        started = false;
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean s) {
        started = s;
    }

    // Allow GUI/controller to set chosen player symbol; AI gets the opposite
    public void setPlayerSymbol(char sym) {
        if (sym != 'X' && sym != 'O') return;
        this.playerSymbol = sym;
        this.aiSymbol = (sym == 'X') ? 'O' : 'X';
    }

    // Attempt a player move; returns true if move applied.
    // Only allow when a game is started and the target cell is empty.
    public boolean playerMove(int row, int col) {
        if (!started) return false;
        return board.set(row, col, playerSymbol);
    }

    // Request AI move; will only act when game started and board has available moves.
    // Returns the move performed as [row,col] or null if no move made.
    public int[] aiMove() {
        if (!started) return null;
        List<int[]> moves = board.availableMoves();
        if (moves.isEmpty()) return null;
        ai.makeMove(board, aiSymbol);
        // find the last move by checking difference (cheap approach)
        // prefer to return any occupied O cell (first found) that wasn't there before is complex;
        // instead return the most recently placed O by scanning board (last available move before call not tracked).
        // We'll scan for any 'O' (caller will refresh UI anyway).
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board.get(i, j) == aiSymbol) {
                    // return first found O (sufficient for GUI refresh)
                    return new int[]{i, j};
                }
        return null;
    }

    public char getCell(int row, int col) {
        return board.get(row, col);
    }

    public char checkWinner() {
        return board.checkWinner();
    }

    public boolean isFull() {
        return board.isFull();
    }

    public boolean isPlayerFirst() {
        return playerFirst;
    }

    // Helper: get a defensive copy of board state
    public char[][] getBoardCopy() {
        char[][] copy = new char[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                copy[i][j] = board.get(i, j);
        return copy;
    }

    // Helper: number of available moves
    public int availableMovesCount() {
        return board.availableMoves().size();
    }
}
