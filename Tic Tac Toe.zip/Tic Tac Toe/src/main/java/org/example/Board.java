package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Board {
    private final char[][] cells = new char[3][3];

    public Board() {
        reset();
    }

    public void reset() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                cells[i][j] = '\0';
    }

    public boolean set(int row, int col, char player) {
        if (row < 0 || row > 2 || col < 0 || col > 2) return false;
        if (cells[row][col] != '\0') return false;
        cells[row][col] = player;
        return true;
    }

    public char get(int row, int col) {
        if (row < 0 || row > 2 || col < 0 || col > 2) return '\0';
        return cells[row][col];
    }

    public List<int[]> availableMoves() {
        List<int[]> moves = new ArrayList<>();
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (cells[i][j] == '\0') moves.add(new int[]{i, j});
        return moves;
    }

    public boolean isFull() {
        return availableMoves().isEmpty();
    }

    // returns 'X' or 'O' if winner exists, otherwise '\0'
    public char checkWinner() {
        for (int i = 0; i < 3; i++) {
            if (cells[i][0] != '\0' && cells[i][0] == cells[i][1] && cells[i][1] == cells[i][2]) return cells[i][0];
            if (cells[0][i] != '\0' && cells[0][i] == cells[1][i] && cells[1][i] == cells[2][i]) return cells[0][i];
        }
        if (cells[0][0] != '\0' && cells[0][0] == cells[1][1] && cells[1][1] == cells[2][2]) return cells[0][0];
        if (cells[0][2] != '\0' && cells[0][2] == cells[1][1] && cells[1][1] == cells[2][0]) return cells[0][2];
        return '\0';
    }

    // --- New helper methods ---

    // Defensive copy of the board state
    public char[][] getCells() {
        char[][] copy = new char[3][3];
        for (int i = 0; i < 3; i++)
            System.arraycopy(cells[i], 0, copy[i], 0, 3);
        return copy;
    }

    // Replace board contents from a provided 3x3 array (defensive)
    public boolean setCells(char[][] src) {
        if (src == null || src.length != 3) return false;
        for (int i = 0; i < 3; i++) if (src[i] == null || src[i].length != 3) return false;
        for (int i = 0; i < 3; i++)
            System.arraycopy(src[i], 0, cells[i], 0, 3);
        return true;
    }

    // Check if a specific cell is empty
    public boolean isEmptyCell(int row, int col) {
        if (row < 0 || row > 2 || col < 0 || col > 2) return false;
        return cells[row][col] == '\0';
    }

    // Find any cell occupied by the given player ('X' or 'O'). Returns first match as [row,col] or null.
    // Useful when caller needs to know a move performed by the AI.
    public int[] findLastMove(char player) {
        if (player != 'X' && player != 'O') return null;
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (cells[i][j] == player) return new int[]{i, j};
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (char[] row : cells) {
            sb.append(Arrays.toString(row)).append(System.lineSeparator());
        }
        return sb.toString();
    }
}

