module org.example.mip_tema2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    // --- DEPENDINȚE JACKSON (Adăugate pentru JSON Export/Import) ---
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.annotation;

    // --- DEPENDINȚE BAZĂ DE DATE ---
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.sql;

    // Necesare pentru ca Hibernate să funcționeze cu byte-buddy
    requires net.bytebuddy;
    requires java.naming;

    // --- PERMISIUNI (OPENS) ---
    // Aici am adaugat 'com.fasterxml.jackson.databind' la lista de module care pot citi clasele tale
    opens org.example.mip_tema2 to javafx.graphics, javafx.fxml, com.google.gson, org.hibernate.orm.core, javafx.base, com.fasterxml.jackson.databind;

    exports org.example.mip_tema2;

    exports org.example.mip_tema2.Repository;
    opens org.example.mip_tema2.Repository to com.google.gson, javafx.fxml, javafx.graphics, org.hibernate.orm.core;

    exports org.example.mip_tema2.Config;
    opens org.example.mip_tema2.Config to com.google.gson, javafx.fxml, javafx.graphics, org.hibernate.orm.core;
}