package org.example.mip_tema2;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.Proxy;

@Entity
@DiscriminatorValue("BAUTURA") // Majuscule pentru compatibilitate DB
@Proxy(lazy = false)
public final class Bautura extends Produs {

    @Column(name = "volum_ml")
    @JsonProperty("volumMl")
    private int volumMl;

    @Column(name = "este_alcoolic")
    @JsonProperty("alcoolic")
    private boolean alcoolic;

    // 1. Constructor obligatoriu pentru JPA/Hibernate
    protected Bautura() {
        super();
    }

    // 2. Constructor pentru JSON si utilizare normala
    @JsonCreator
    public Bautura(
            @JsonProperty("nume") String nume,
            @JsonProperty("pret") double pret,
            @JsonProperty("volumMl") int volumMl,
            @JsonProperty("alcoolic") boolean alcoolic) {

        super(nume, pret);
        if (volumMl <= 0) throw new IllegalArgumentException("Volum invalid");
        this.volumMl = volumMl;
        this.alcoolic = alcoolic;
    }

    // --- GETTERI ---
    public int getVolumMl() { return volumMl; }
    public boolean isAlcoolic() { return alcoolic; }

    // --- SETTERI (Adăugați pentru a repara eroarea din AdminController) ---
    public void setVolumMl(int volumMl) { this.volumMl = volumMl; }
    public void setAlcoolic(boolean alcoolic) { this.alcoolic = alcoolic; }

    @Override
    public String detalii() {
        return "Volum: " + volumMl + "ml, Alcoolic: " + (alcoolic ? "Da" : "Nu");
    }
}