package org.example.mip_tema2;

import jakarta.persistence.*;

@Entity
@Table(name = "comanda_items")
public class ComandaItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "comanda_id", nullable = false)
    private Comanda comanda;

    @ManyToOne(optional = false)
    @JoinColumn(name = "produs_id", nullable = false)
    private Produs produs;

    @Column(nullable = false)
    private int cantitate;

    @Column(nullable = false)
    private double pretLaVanzare; // Store price at the time of order

    // JPA constructor
    protected ComandaItem() {}

    public ComandaItem(Comanda comanda, Produs produs, int cantitate) {
        this.comanda = comanda;
        this.produs = produs;
        this.cantitate = cantitate;
        this.pretLaVanzare = produs.getPret();
    }

    // Getters
    public Long getId() { return id; }
    public Comanda getComanda() { return comanda; }
    public Produs getProdus() { return produs; }
    public int getCantitate() { return cantitate; }
    public double getPretLaVanzare() { return pretLaVanzare; }
    public void setCantitate(int cantitate) { this.cantitate = cantitate; }

    public double getSubtotal() {
        return this.cantitate * this.pretLaVanzare;
    }
}
