package org.example.mip_tema2.Repository;

import jakarta.persistence.*;
import org.example.mip_tema2.User;

import java.util.List;
import java.util.Optional;

public class UserRepository {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("restaurantPU");

    public Optional<User> findByUsername(String username) {
        try (EntityManager em = emf.createEntityManager()) {
            try {
                User user = em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class)
                        .setParameter("username", username)
                        .getSingleResult();
                return Optional.of(user);
            } catch (NoResultException e) {
                return Optional.empty();
            }
        }
    }

    public List<User> findAll() {
        try (EntityManager em = emf.createEntityManager()) {
            return em.createQuery("SELECT u FROM User u", User.class).getResultList();
        }
    }

    public void save(User user) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.merge(user); // merge handles both new and existing entities
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public void delete(User user) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            // Ensure the entity is in the managed state before removal
            if (!em.contains(user)) {
                user = em.merge(user);
            }
            em.remove(user);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
