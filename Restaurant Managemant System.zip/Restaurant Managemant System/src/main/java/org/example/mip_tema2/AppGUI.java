package org.example.mip_tema2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import org.example.mip_tema2.Config.AppConfig;

import java.io.IOException;

public class AppGUI extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        // Set the title from AppConfig, with a fallback
        try {
            primaryStage.setTitle(AppConfig.INSTANCE.getRestaurantName());
        } catch (Exception e) {
            primaryStage.setTitle("Restaurant App");
        }
        showLoginView();
    }

    public void showLoginView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/mip_tema2/login-view.fxml"));
            Parent root = loader.load();

            LoginController controller = loader.getController();
            controller.setMainApp(this);

            primaryStage.setScene(new Scene(root, 350, 300));
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Could not load the login view.").show();
        }
    }

    public void showRoleSpecificView(User user) {
        if (user == null) {
            showLoginView();
            return;
        }

        switch (user.getRole()) {
            case GUEST:
                showGuestView();
                break;
            case STAFF:
                showStaffView(user);
                break;
            case ADMIN:
                showAdminView(user);
                break;
            default:
                showLoginView();
                break;
        }
    }

    private void showGuestView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/mip_tema2/guest-view.fxml"));
            Parent root = loader.load();
            primaryStage.setScene(new Scene(root, 800, 600));
            primaryStage.setTitle("Guest Menu");
        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Could not load the guest view.").show();
        }
    }

    private void showStaffView(User staff) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/mip_tema2/staff-view.fxml"));
            Parent root = loader.load();

            StaffController controller = loader.getController();
            controller.setUser(staff);

            primaryStage.setScene(new Scene(root, 1024, 768));
            primaryStage.setTitle("Staff Dashboard - " + staff.getUsername());
        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Could not load the staff view.").show();
        }
    }

    private void showAdminView(User admin) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/mip_tema2/admin-view.fxml"));
            Parent root = loader.load();
            primaryStage.setScene(new Scene(root, 1024, 768));
            primaryStage.setTitle("Admin Dashboard - " + admin.getUsername());
        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Could not load the admin view.").show();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
