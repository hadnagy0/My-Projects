package org.example.mip_tema2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.mip_tema2.Repository.ComandaRepository;
import org.example.mip_tema2.Repository.MasaRepository;
import org.example.mip_tema2.Repository.ProdusRepository;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class StaffController {

    // User and Repositories
    private User user;
    private final ProdusRepository produsRepository = new ProdusRepository();
    private final MasaRepository masaRepository = new MasaRepository();
    private final ComandaRepository comandaRepository = new ComandaRepository();

    // Active Orders Management
    private final Map<Masa, Comanda> activeOrders = new HashMap<>();
    private Comanda currentOrder;

    // --- FXML Components ---
    @FXML private ListView<Masa> tablesListView;

    @FXML private Label currentOrderLabel;
    @FXML private TableView<ComandaItem> orderItemsTable;
    @FXML private TableColumn<ComandaItem, String> orderItemNameColumn;
    @FXML private TableColumn<ComandaItem, Integer> orderItemQuantityColumn;
    @FXML private TableColumn<ComandaItem, Double> orderItemPriceColumn;
    @FXML private TableColumn<ComandaItem, Double> orderItemTotalColumn;
    @FXML private Label subtotalLabel;
    @FXML private Label discountLabel;
    @FXML private Label totalLabel;
    @FXML private Button finalizeOrderButton;

    @FXML private TextField menuSearchField;
    @FXML private TableView<Produs> menuTable;
    @FXML private TableColumn<Produs, String> menuNameColumn;
    @FXML private TableColumn<Produs, Double> menuPriceColumn;

    @FXML private TableView<Comanda> historyTable;
    @FXML private TableColumn<Comanda, Long> historyIdColumn;
    @FXML private TableColumn<Comanda, Integer> historyMasaColumn;
    @FXML private TableColumn<Comanda, String> historyDateColumn;
    @FXML private TableColumn<Comanda, Double> historyTotalColumn;
    @FXML private TableColumn<Comanda, Comanda.ComandaStatus> historyStatusColumn;

    public StaffController() {
        // Constructor gol
    }

    @FXML
    public void initialize() {
        setupTablesView();
        setupMenuView();
        setupOrderView();
        setupHistoryView();

        // Încărcăm datele inițiale
        loadTablesFull();
        loadMenu();

        tablesListView.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> handleTableSelection(newSelection)
        );
    }

    public void setUser(User user) {
        this.user = user;
        loadStaffHistory();
    }

    // --- Setup Methods ---
    private void setupTablesView() {
        tablesListView.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(Masa masa, boolean empty) {
                super.updateItem(masa, empty);
                if (empty || masa == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText("Masa " + masa.getNumar() + " (" + masa.getStatus() + ")");
                    if (masa.getStatus() == Masa.MasaStatus.OCUPATA) {
                        setStyle("-fx-background-color: #ffcdd2;"); // Roșu deschis
                    } else {
                        setStyle("-fx-background-color: #c8e6c9;"); // Verde deschis
                    }
                }
            }
        });
    }

    private void setupMenuView() {
        menuNameColumn.setCellValueFactory(new PropertyValueFactory<>("nume"));
        menuPriceColumn.setCellValueFactory(new PropertyValueFactory<>("pret"));
    }

    private void setupOrderView() {
        orderItemNameColumn.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(cell.getValue().getProdus().getNume()));
        orderItemQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("cantitate"));
        orderItemPriceColumn.setCellValueFactory(new PropertyValueFactory<>("pretLaVanzare"));
        orderItemTotalColumn.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleDoubleProperty(cell.getValue().getSubtotal()).asObject());
    }

    private void setupHistoryView() {
        historyIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        historyMasaColumn.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleIntegerProperty(cell.getValue().getMasa().getNumar()).asObject());
        historyDateColumn.setCellValueFactory(cell -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            return new javafx.beans.property.SimpleStringProperty(cell.getValue().getDataCreare().format(formatter));
        });
        historyTotalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));
        historyStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    // --- Data Loading Methods ---

    // Metodă redenumită pentru claritate: Reîncarcă tot din DB (pierde selecția)
    private void loadTablesFull() {
        tablesListView.setItems(FXCollections.observableArrayList(masaRepository.findAll()));
    }

    private void loadMenu() {
        ObservableList<Produs> allProducts = FXCollections.observableArrayList(produsRepository.findAll());
        FilteredList<Produs> filteredProducts = new FilteredList<>(allProducts, p -> true);

        menuSearchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredProducts.setPredicate(produs -> {
                if (newVal == null || newVal.isEmpty()) return true;
                return produs.getNume().toLowerCase().contains(newVal.toLowerCase());
            });
        });
        menuTable.setItems(filteredProducts);
    }

    private void loadStaffHistory() {
        if (user != null) {
            historyTable.setItems(FXCollections.observableArrayList(comandaRepository.findByStaff(user)));
        }
    }

    // --- Event Handlers (MODIFICAT) ---
    private void handleTableSelection(Masa selectedMasa) {
        if (selectedMasa == null) {
            currentOrder = null;
            updateOrderView();
            return;
        }

        // Folosim computeIfAbsent pentru a găsi sau crea comanda
        currentOrder = activeOrders.computeIfAbsent(selectedMasa, masa -> {
            // Dacă masa era liberă, o marcăm ocupată și salvăm
            if (masa.getStatus() == Masa.MasaStatus.LIBERA) {
                masa.setStatus(Masa.MasaStatus.OCUPATA);
                masaRepository.save(masa);

                // IMPORTANT: Doar redesenăm lista (refresh), NU reîncărcăm datele (setItems).
                // Astfel, obiectul "selectedMasa" rămâne valid și selecția nu se pierde.
                tablesListView.refresh();
            }
            return new Comanda(masa, user);
        });

        updateOrderView();
    }

    @FXML
    private void handleAddToOrder() {
        Produs selectedProdus = menuTable.getSelectionModel().getSelectedItem();
        if (selectedProdus != null && currentOrder != null) {
            currentOrder.addItem(selectedProdus, 1);
            updateOrderView();
        } else {
            new Alert(Alert.AlertType.WARNING, "Selectati o masa si un produs.").show();
        }
    }

    @FXML
    private void handleIncreaseQuantity() {
        ComandaItem item = orderItemsTable.getSelectionModel().getSelectedItem();
        if (item != null) {
            item.setCantitate(item.getCantitate() + 1);
            updateOrderView();
        }
    }

    @FXML
    private void handleDecreaseQuantity() {
        ComandaItem item = orderItemsTable.getSelectionModel().getSelectedItem();
        if (item != null) {
            int newQ = item.getCantitate() - 1;
            if (newQ > 0) item.setCantitate(newQ);
            else currentOrder.getItems().remove(item);
            updateOrderView();
        }
    }

    @FXML
    private void handleRemoveFromOrder() {
        ComandaItem item = orderItemsTable.getSelectionModel().getSelectedItem();
        if (item != null && currentOrder != null) {
            currentOrder.getItems().remove(item);
            updateOrderView();
        }
    }

    @FXML
    private void handleFinalizeOrder() {
        if (currentOrder == null || currentOrder.getItems().isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Comanda este goala.").show();
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION, "Finalizati comanda?", ButtonType.YES, ButtonType.NO);
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                currentOrder.setStatus(Comanda.ComandaStatus.FINALIZATA);
                comandaRepository.save(currentOrder);

                Masa masa = currentOrder.getMasa();
                masa.setStatus(Masa.MasaStatus.LIBERA);
                masaRepository.save(masa);

                activeOrders.remove(masa);
                currentOrder = null;

                updateOrderView();

                // Aici reîncărcăm complet lista pentru a fi siguri că statusul e sincronizat
                loadTablesFull();
                loadStaffHistory();
            }
        });
    }

    // --- UI Update & Calculation Methods ---

    private void updateOrderView() {
        if (currentOrder != null) {
            currentOrderLabel.setText("Comanda Masa: " + currentOrder.getMasa().getNumar());
            orderItemsTable.setItems(FXCollections.observableArrayList(currentOrder.getItems()));
            orderItemsTable.refresh();
            finalizeOrderButton.setDisable(false);

            calculateTotals();
        } else {
            currentOrderLabel.setText("Masa: -");
            orderItemsTable.getItems().clear();
            subtotalLabel.setText("0.00 RON");
            discountLabel.setText("0.00 RON");
            totalLabel.setText("0.00 RON");
            finalizeOrderButton.setDisable(true);
        }
    }

    private void calculateTotals() {
        if (currentOrder == null) return;

        double subtotal = currentOrder.getItems().stream().mapToDouble(ComandaItem::getSubtotal).sum();
        currentOrder.setSubtotal(subtotal);

        // --- CONSTRUIRE DINAMICĂ A LISTEI DE OFERTE ---
        List<Oferta> oferteActive = new ArrayList<>();
        GlobalSettings settings = GlobalSettings.getInstance();

        if (settings.isHappyHourActive()) {
            oferteActive.add(Oferta.happyHour());
        }
        if (settings.isMealDealActive()) {
            oferteActive.add(Oferta.cumpariPizzaPrimestiBautura());
        }
        if (settings.isPartyPackActive()) {
            oferteActive.add(Oferta.partyPack());
        }

        DiscountService service = new DiscountService(oferteActive);
        // -----------------------------------------------

        double discount = service.calculateTotalDiscount(currentOrder);
        currentOrder.setDiscount(discount);

        double total = subtotal - discount;
        currentOrder.setTotal(total);

        subtotalLabel.setText(String.format("%.2f RON", subtotal));
        discountLabel.setText(String.format("-%.2f RON", discount));
        totalLabel.setText(String.format("%.2f RON", total));
    }
}