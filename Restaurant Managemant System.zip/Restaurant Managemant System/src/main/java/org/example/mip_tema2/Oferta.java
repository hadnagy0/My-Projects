package org.example.mip_tema2;

import java.time.LocalTime;
import java.util.Comparator;
import java.util.stream.Stream;
import java.util.List;

@FunctionalInterface
public interface Oferta {
    double aplica(Comanda comanda, double subtotal);

    static Oferta happyHour() {
        return (comanda, subtotal) -> {
            // Luăm toate băuturile din comandă, expandate (dacă am cantitate 2, avem 2 obiecte)
            List<Produs> bauturi = comanda.getItems().stream()
                    .filter(item -> item.getProdus() instanceof Bautura)
                    .flatMap(item -> Stream.generate(item::getProdus).limit(item.getCantitate()))
                    .sorted(Comparator.comparingDouble(Produs::getPret)) // Sortăm (opțional, de obicei se reduce cea mai ieftină)
                    .toList();

            double discount = 0.0;
            // Aplicăm reducere la fiecare a doua băutură (index 1, 3, 5...)
            for (int i = 1; i < bauturi.size(); i += 2) {
                discount += bauturi.get(i).getPret() * 0.5; // 50% reducere
            }
            return discount;
        };
    }
    // 2. Reducere procentuală simplă
    static Oferta reducereProcentuala(double procent) {
        return (comanda, subtotal) -> subtotal * procent;
    }

    // 3. Meal Deal: Cumperi Pizza, primești reducere la cea mai ieftină băutură (Meal Deal simplificat)
    // SAU varianta complexă cerută: Pizza + Desert redus.
    // Aici păstrez logica "Meal Deal" generică (Pizza + Bautura sau Pizza + Desert)
    static Oferta cumpariPizzaPrimestiBautura() {
        return (comanda, subtotal) -> {
            long numarPizza = comanda.getItems().stream()
                    .filter(item -> item.getProdus() instanceof Pizza)
                    .mapToLong(ComandaItem::getCantitate)
                    .sum();

            if (numarPizza == 0) return 0.0;

            // Găsim băuturile (sau deserturile) și le reducem pe cele mai ieftine
            return comanda.getItems().stream()
                    .filter(item -> item.getProdus() instanceof Bautura)
                    .flatMap(item -> Stream.generate(item::getProdus).limit(item.getCantitate()))
                    .mapToDouble(Produs::getPret)
                    .sorted()
                    .limit(numarPizza)
                    .sum() * 0.25; // 25% reducere
        };
    }

    // 4. PARTY PACK: La 4 Pizza, una gratis (cea mai ieftină)
    static Oferta partyPack() {
        return (comanda, subtotal) -> {
            var toatePizzele = comanda.getItems().stream()
                    .filter(item -> item.getProdus() instanceof Pizza)
                    .flatMap(item -> Stream.generate(item::getProdus).limit(item.getCantitate()))
                    .sorted(Comparator.comparingDouble(Produs::getPret)) // Sortăm crescător după preț
                    .toList();

            long numarPizze = toatePizzele.size();

            if (numarPizze >= 4) {
                long pizzeGratuite = numarPizze / 4;
                // Sumăm prețurile primelor X pizze (cele mai ieftine)
                return toatePizzele.stream()
                        .limit(pizzeGratuite)
                        .mapToDouble(Produs::getPret)
                        .sum();
            }
            return 0.0;
        };
    }
}