package org.example.mip_tema2;

import java.util.List;

public class DiscountService {

    private final List<Oferta> oferte;

    public DiscountService(List<Oferta> oferte) {
        this.oferte = oferte;
    }

    public double calculateTotalDiscount(Comanda comanda) {
        double subtotal = comanda.getItems().stream()
                .mapToDouble(ComandaItem::getSubtotal)
                .sum();

        return oferte.stream()
                .mapToDouble(oferta -> oferta.aplica(comanda, subtotal))
                .sum();
    }
}
