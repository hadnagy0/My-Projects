package org.example.mip_tema2.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import org.example.mip_tema2.Comanda;
import org.example.mip_tema2.User;

import java.util.List;

public class ComandaRepository {
    // Asigură-te că numele "restaurantPU" este identic cu cel din persistence.xml
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("restaurantPU");

    /**
     * Returnează toate comenzile, PRE-ÎNCĂRCÂND Masa și Staff-ul.
     */
    public List<Comanda> findAll() {
        try (EntityManager em = emf.createEntityManager()) {
            // MODIFICARE AICI: Am adăugat LEFT JOIN FETCH
            return em.createQuery(
                            "SELECT c FROM Comanda c " +
                                    "LEFT JOIN FETCH c.masa " +
                                    "LEFT JOIN FETCH c.staff " +
                                    "ORDER BY c.dataCreare DESC", Comanda.class)
                    .getResultList();
        }
    }

    public void save(Comanda comanda) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            if (comanda.getId() == null) {
                em.persist(comanda);
            } else {
                em.merge(comanda);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public List<Comanda> findByStaff(User staff) {
        try (EntityManager em = emf.createEntityManager()) {
            // MODIFICARE AICI: Am adăugat LEFT JOIN FETCH și aici
            return em.createQuery(
                            "SELECT c FROM Comanda c " +
                                    "LEFT JOIN FETCH c.masa " +
                                    "LEFT JOIN FETCH c.staff " +
                                    "WHERE c.staff = :staff " +
                                    "ORDER BY c.dataCreare DESC", Comanda.class)
                    .setParameter("staff", staff)
                    .getResultList();
        }
    }
}