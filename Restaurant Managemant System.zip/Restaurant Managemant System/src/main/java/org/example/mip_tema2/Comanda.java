package org.example.mip_tema2;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Entity
@Table(name = "comenzi")
public class Comanda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "masa_id", nullable = false)
    private Masa masa;

    @ManyToOne
    @JoinColumn(name = "staff_id") // Can be null if not assigned
    private User staff;

    @Column(nullable = false)
    private LocalDateTime dataCreare = LocalDateTime.now();

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private ComandaStatus status = ComandaStatus.IN_ASTEPTARE;

    @OneToMany(mappedBy = "comanda", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<ComandaItem> items = new ArrayList<>();

    @Column
    private double subtotal;

    @Column
    private double discount;

    @Column
    private double total;

    public enum ComandaStatus {
        IN_ASTEPTARE, FINALIZATA, ANULATA
    }

    // JPA constructor
    protected Comanda() {}

    public Comanda(Masa masa, User staff) {
        this.masa = masa;
        this.staff = staff;
    }

    public void addItem(Produs produs, int cantitate) {
        if (produs == null || cantitate <= 0) {
            return;
        }

        Optional<ComandaItem> existingItem = items.stream()
                .filter(item -> item.getProdus().getId().equals(produs.getId()))
                .findFirst();

        if (existingItem.isPresent()) {
            ComandaItem item = existingItem.get();
            item.setCantitate(item.getCantitate() + cantitate);
        } else {
            ComandaItem newItem = new ComandaItem(this, produs, cantitate);
            this.items.add(newItem);
        }
    }

    // Getters and Setters
    public Long getId() { return id; }
    public Masa getMasa() { return masa; }
    public User getStaff() { return staff; }
    public LocalDateTime getDataCreare() { return dataCreare; }
    public ComandaStatus getStatus() { return status; }
    public void setStatus(ComandaStatus status) { this.status = status; }
    public List<ComandaItem> getItems() { return items; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public double getTotal() { return total; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    public void setDiscount(double discount) { this.discount = discount; }
    public void setTotal(double total) { this.total = total; }
    public void setItems(List<ComandaItem> items) { this.items = items; }
}
