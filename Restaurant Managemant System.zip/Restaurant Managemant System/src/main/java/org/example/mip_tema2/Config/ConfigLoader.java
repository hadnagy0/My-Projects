package org.example.mip_tema2.Config;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import org.example.mip_tema2.*;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public final class ConfigLoader {
    private ConfigLoader() {}

    public static AppConfig load() {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("config.json")) {
            return gson.fromJson(reader, AppConfig.class);
        } catch (Exception e) {
            return new AppConfig("La Andrei", 0.09, "menu-export.json");
        }
    }

    public static List<Produs> incarcaProduse(String caleFisier) {
        List<Produs> listaFinala = new ArrayList<>();
        Gson gson = new Gson();

        try (FileReader reader = new FileReader(caleFisier)) {
            JsonObject root = gson.fromJson(reader, JsonObject.class);

            // Verificăm dacă există secțiunea "categories" din fișierul tău
            if (root.has("categories")) {
                JsonObject categories = root.getAsJsonObject("categories");
                for (String catName : categories.keySet()) {
                    JsonArray produseArray = categories.getAsJsonArray(catName);
                    for (int i = 0; i < produseArray.size(); i++) {
                        JsonObject obj = produseArray.get(i).getAsJsonObject();
                        String type = obj.get("type").getAsString().toLowerCase();

                        // Mapare manuală pentru a evita problemele cu clasa abstractă
                        if (type.equals("pizza")) {
                            listaFinala.add(gson.fromJson(obj, Pizza.class));
                        } else if (type.equals("bautura")) {
                            listaFinala.add(gson.fromJson(obj, Bautura.class));
                        } else if (type.equals("preparatculinar")) {
                            listaFinala.add(gson.fromJson(obj, PreparatCulinar.class));
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Eroare la parsare JSON: " + e.getMessage());
        }
        return listaFinala;
    }
}