package org.example.mip_tema2;
import org.example.mip_tema2.Config.AppConfig;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class Meniu {
    private final Map<String, List<Produs>> categorii = new LinkedHashMap<>();

    public Meniu() { /* constructor gol */ }

    public void addProdus(String categorie, Produs produs) {
        if (categorie == null || categorie.trim().isEmpty()) throw new IllegalArgumentException("Categorie invalida");
        if (produs == null) throw new IllegalArgumentException("Produs nul");
        categorii.computeIfAbsent(categorie.trim(), k -> new ArrayList<>()).add(produs);
    }

    public List<Produs> getByCategorie(String categorie) {
        if (categorie == null) return Collections.emptyList();
        List<Produs> list = categorii.get(categorie.trim());
        return list == null ? Collections.emptyList() : Collections.unmodifiableList(list);
    }

    public Stream<Produs> streamAllProduse() {
        return categorii.values().stream().flatMap(List::stream);
    }

    // --- FIX AICI: Am eliminat .orElse(false) deoarece isVegetarian returneaza boolean ---
    public List<Produs> toateVegetarieneSorted() {
        return streamAllProduse()
                .filter(p -> p instanceof PreparatCulinar)
                .map(p -> (PreparatCulinar) p)
                .filter(pc -> {
                    try {
                        // FIX: Acum isVegetarian() returneaza boolean, deci il folosim direct
                        return pc.isVegetarian();
                    } catch (Exception ex) {
                        return false;
                    }
                })
                .sorted(Comparator.comparing(Produs::getNume, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
    }

    public double pretMediuCategoria(String categorie) {
        if (categorie == null) return 0.0;
        return getByCategorie(categorie).stream()
                .mapToDouble(Produs::getPret)
                .average()
                .orElse(0.0);
    }

    public boolean existaProdusPestePret(double prag) {
        return streamAllProduse().anyMatch(p -> p.getPret() > prag);
    }

    public Optional<Produs> cautaProdus(String query) {
        if (query == null || query.trim().isEmpty()) return Optional.empty();
        String qNorm = normalize(query);

        // 1) exact match (case-insensitive, normalized)
        Optional<Produs> exact = streamAllProduse()
                .filter(p -> normalize(p.getNume()).equals(qNorm))
                .findFirst();
        if (exact.isPresent()) return exact;

        // 2) contains (normalized, case-insensitive)
        Optional<Produs> partial = streamAllProduse()
                .filter(p -> normalize(p.getNume()).contains(qNorm))
                .findFirst();
        if (partial.isPresent()) return partial;

        return Optional.empty();
    }

    public Set<String> getCategorii() {
        return Collections.unmodifiableSet(categorii.keySet());
    }

    private static String normalize(String s) {
        if (s == null) return "";
        String trimmed = s.trim().toLowerCase(Locale.ROOT);
        String noDiacritics = Normalizer.normalize(trimmed, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        return noDiacritics;
    }

    // Responsible for printing the structured menu (uses AppConfig)
    public void printMenu() {
        String restaurant = "Unknown";
        try {
            restaurant = AppConfig.INSTANCE.getRestaurantName();
        } catch (Throwable t) {
            // fallback
        }
        System.out.println("--- Meniul Restaurantului \"" + restaurant + "\" ---");
        for (Map.Entry<String, List<Produs>> e : categorii.entrySet()) {
            String categorie = e.getKey();
            List<Produs> produse = e.getValue();
            System.out.println("[" + categorie + "]");
            for (Produs p : produse) {
                String detalii = "";
                try {
                    detalii = p.detalii();
                } catch (Exception ex) {
                    detalii = "";
                }
                System.out.printf("  > %s - %.2f RON%s%n", p.getNume(), p.getPret(),
                        detalii == null || detalii.isEmpty() ? "" : " - " + detalii);
            }
        }
        System.out.println("----------------------------------------------------");
    }

    // Export menu to JSON file (simple manual serialization). Returns true on success.
    public boolean exportToJson(String filename) {
        if (filename == null || filename.trim().isEmpty()) filename = AppConfig.INSTANCE.getMenuExportFile();
        Path path = Paths.get(filename);
        return exportToJson(path);
    }

    public boolean exportToJson(Path path) {
        Map<String, Object> root = new LinkedHashMap<>();
        try {
            root.put("restaurantName", AppConfig.INSTANCE.getRestaurantName());
        } catch (Throwable t) {
            root.put("restaurantName", "Unknown");
        }
        root.put("generatedAt", new Date().toString());

        Map<String, List<Map<String, Object>>> cats = new LinkedHashMap<>();
        for (Map.Entry<String, List<Produs>> e : categorii.entrySet()) {
            List<Map<String, Object>> prodList = new ArrayList<>();
            for (Produs p : e.getValue()) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("type", p.getClass().getSimpleName().toLowerCase());
                item.put("nume", p.getNume());
                item.put("pret", p.getPret());

                // try to add optional known properties via reflection to keep compile-time loose coupling
                try {
                    // gramaj
                    try {
                        Object gramaj = p.getClass().getMethod("getGramaj").invoke(p);
                        item.put("gramaj", gramaj);
                    } catch (NoSuchMethodException ignored) { }
                    // volumMl
                    try {
                        Object volum = p.getClass().getMethod("getVolumMl").invoke(p);
                        item.put("volumMl", volum);
                    } catch (NoSuchMethodException ignored) { }
                    // blat
                    try {
                        Object blat = p.getClass().getMethod("getBlat").invoke(p);
                        item.put("blat", blat);
                    } catch (NoSuchMethodException ignored) { }
                    // sos
                    try {
                        Object sos = p.getClass().getMethod("getSos").invoke(p);
                        item.put("sos", sos);
                    } catch (NoSuchMethodException ignored) { }
                    // toppinguri
                    try {
                        Object topp = p.getClass().getMethod("getToppinguri").invoke(p);
                        item.put("toppinguri", topp);
                    } catch (NoSuchMethodException ignored) { }
                    // vegetarian (acum boolean primitiv)
                    try {
                        Object veg = p.getClass().getMethod("isVegetarian").invoke(p);
                        item.put("vegetarian", veg);
                    } catch (NoSuchMethodException ignored) { }
                    // alcoolic
                    try {
                        Object alc = p.getClass().getMethod("isAlcoolic").invoke(p);
                        item.put("alcoolic", alc);
                    } catch (NoSuchMethodException ignored) { }
                } catch (Exception ex) {
                    // ignore reflection issues; proceed with basic fields
                }

                prodList.add(item);
            }
            cats.put(e.getKey(), prodList);
        }
        root.put("categories", cats);

        // Simple pretty-print JSON (manual, minimal). Avoid external lib dependency.
        String json = toPrettyJson(root);

        try {
            Files.write(path, json.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException ex) {
            System.out.println("Error: Failed to export menu to '" + path + "'. Please check file permissions.");
            return false;
        }
    }

    // Minimal pretty JSON serializer for Maps/Lists/primitive values (sufficient for our structure)
    private static String toPrettyJson(Object obj) {
        StringBuilder sb = new StringBuilder();
        toJson(obj, sb, 0);
        return sb.toString();
    }

    private static void toJson(Object obj, StringBuilder sb, int indent) {
        if (obj == null) {
            sb.append("null");
        } else if (obj instanceof Map) {
            sb.append("{\n");
            Map<?,?> map = (Map<?,?>) obj;
            Iterator<? extends Map.Entry<?,?>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<?,?> e = it.next();
                indent(sb, indent + 2);
                sb.append("\"").append(escape(String.valueOf(e.getKey()))).append("\": ");
                toJson(e.getValue(), sb, indent + 2);
                if (it.hasNext()) sb.append(",");
                sb.append("\n");
            }
            indent(sb, indent);
            sb.append("}");
        } else if (obj instanceof List) {
            sb.append("[\n");
            List<?> list = (List<?>) obj;
            Iterator<?> it = list.iterator();
            while (it.hasNext()) {
                indent(sb, indent + 2);
                toJson(it.next(), sb, indent + 2);
                if (it.hasNext()) sb.append(",");
                sb.append("\n");
            }
            indent(sb, indent);
            sb.append("]");
        } else if (obj instanceof Number || obj instanceof Boolean) {
            sb.append(obj.toString());
        } else {
            sb.append("\"").append(escape(String.valueOf(obj))).append("\"");
        }
    }

    private static void indent(StringBuilder sb, int n) {
        for (int i = 0; i < n; i++) sb.append(' ');
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}