package org.example.mip_tema2;

import org.example.mip_tema2.Repository.UserRepository;

public class DataSeeder {

    /**
     * Run this main method once to create default users in the database.
     */
    public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();

        // Create Admin User if it doesn't exist
        if (userRepository.findByUsername("admin").isEmpty()) {
            User admin = new User("admin", "adminpass", User.UserRole.ADMIN);
            userRepository.save(admin);
            System.out.println("Successfully created ADMIN user with username 'admin' and password 'adminpass'.");
        } else {
            System.out.println("Admin user 'admin' already exists.");
        }

        // Create Staff User if it doesn't exist
        if (userRepository.findByUsername("staff").isEmpty()) {
            User staff = new User("staff", "staffpass", User.UserRole.STAFF);
            userRepository.save(staff);
            System.out.println("Successfully created STAFF user with username 'staff' and password 'staffpass'.");
        } else {
            System.out.println("Staff user 'staff' already exists.");
        }
    }
}
