package org.example.mip_tema2.Repository;

import jakarta.persistence.*;
import org.example.mip_tema2.Produs;

import java.util.List;

public class ProdusRepository {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("restaurantPU");

    public List<Produs> findAll() {
        try (EntityManager em = emf.createEntityManager()) {
            return em.createQuery("SELECT p FROM Produs p", Produs.class).getResultList();
        }
    }

    public void salveaza(Produs p) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public void sterge(Produs p) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            // Trebuie să facem merge înainte de remove dacă obiectul e detașat
            Produs deSters = em.contains(p) ? p : em.merge(p);
            em.remove(deSters);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public void stergeToate() {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            // Ștergem întâi legăturile (topping-urile), apoi produsele
            em.createNativeQuery("TRUNCATE TABLE pizza_toppinguri CASCADE").executeUpdate();
            em.createNativeQuery("TRUNCATE TABLE produse CASCADE").executeUpdate();
            // Alternativ, dacă vrei JPA pur:
            // em.createQuery("DELETE FROM Produs").executeUpdate();
            tx.commit();
            System.out.println("DEBUG: Baza de date a fost curățată complet.");
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            System.err.println("Eroare la ștergere: " + e.getMessage());
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}