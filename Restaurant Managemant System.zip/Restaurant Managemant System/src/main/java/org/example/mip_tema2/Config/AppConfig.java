package org.example.mip_tema2.Config;

public final class AppConfig {
    private final String restaurantName;
    private final double tva;
    private final String menuExportFile;

    // Safe singleton initialized via helper to avoid static init failures
    public static final AppConfig INSTANCE = loadSafe();

    // package-private so ConfigLoader in same package can instantiate
    AppConfig(String restaurantName, double tva, String menuExportFile) {
        this.restaurantName = (restaurantName == null || restaurantName.isBlank()) ? "La Andrei" : restaurantName;
        this.tva = (tva >= 0.0 && tva <= 1.0) ? tva : 0.09;
        this.menuExportFile = (menuExportFile == null || menuExportFile.isBlank()) ? "menu-export.json" : menuExportFile;
    }

    private static AppConfig loadSafe() {
        try {
            // attempt to load via ConfigLoader; if it fails, fall back to defaults
            return ConfigLoader.load();
        } catch (Throwable t) {
            System.out.println("Warning: failed to load configuration (using defaults). Reason: " + t.getMessage());
            return new AppConfig("La Andrei", 0.09, "menu-export.json");
        }
    }

    public String getRestaurantName() { return restaurantName; }
    public double getTva() { return tva; }
    public String getMenuExportFile() { return menuExportFile; }
}
