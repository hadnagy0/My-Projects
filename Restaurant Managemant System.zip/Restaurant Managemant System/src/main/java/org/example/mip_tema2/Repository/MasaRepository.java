package org.example.mip_tema2.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import org.example.mip_tema2.Masa;

import java.util.List;

public class MasaRepository {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("restaurantPU");

    public List<Masa> findAll() {
        try (EntityManager em = emf.createEntityManager()) {
            return em.createQuery("SELECT m FROM Masa m ORDER BY m.numar", Masa.class).getResultList();
        }
    }

    public void save(Masa masa) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.merge(masa); // face update dacă are ID, insert dacă nu are
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    // --- METODA NOUĂ ---
    public void delete(Masa masa) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            // Dacă obiectul nu este atașat sesiunii curente, îl atașăm cu merge
            Masa deSters = em.contains(masa) ? masa : em.merge(masa);
            em.remove(deSters);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            // Aruncăm eroarea pentru a o putea prinde în Controller (ex: constrângeri FK)
            throw new RuntimeException("Eroare la ștergerea mesei: " + e.getMessage());
        } finally {
            em.close();
        }
    }
}