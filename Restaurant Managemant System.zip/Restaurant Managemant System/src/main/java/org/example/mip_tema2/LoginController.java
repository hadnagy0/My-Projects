package org.example.mip_tema2;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.example.mip_tema2.Repository.UserRepository;

import java.util.Optional;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private final UserRepository userRepository = new UserRepository();
    private AppGUI mainApp;

    public void setMainApp(AppGUI mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Username and password cannot be empty.");
            return;
        }

        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            // NOTE: In a real application, passwords should be hashed and salted.
            if (user.getPassword().equals(password)) {
                mainApp.showRoleSpecificView(user);
            } else {
                showAlert("Login Failed", "Invalid username or password.");
            }
        } else {
            showAlert("Login Failed", "Invalid username or password.");
        }
    }

    @FXML
    private void handleGuestLogin() {
        // Create a temporary guest user to show the guest view
        User guestUser = new User("guest", "", User.UserRole.GUEST);
        mainApp.showRoleSpecificView(guestUser);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
