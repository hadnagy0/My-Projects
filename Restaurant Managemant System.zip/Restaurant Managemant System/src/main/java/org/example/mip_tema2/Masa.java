package org.example.mip_tema2;

import jakarta.persistence.*;

@Entity
@Table(name = "mese")
public class Masa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private int numar;

    @Column(nullable = false)
    private int capacitate;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private MasaStatus status = MasaStatus.LIBERA;

    public enum MasaStatus {
        LIBERA, OCUPATA
    }

    // JPA constructor
    protected Masa() {}

    public Masa(int numar, int capacitate) {
        this.numar = numar;
        this.capacitate = capacitate;
    }

    // Getters
    public Long getId() { return id; }
    public int getNumar() { return numar; }
    public int getCapacitate() { return capacitate; }
    public MasaStatus getStatus() { return status; }

    // Setters (ESENȚIALI PENTRU EDITARE)
    public void setNumar(int numar) {
        this.numar = numar;
    }

    public void setCapacitate(int capacitate) {
        this.capacitate = capacitate;
    }

    public void setStatus(MasaStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Masa " + numar + " (Capacitate: " + capacitate + ")";
    }

    // --- CODUL NOU PENTRU REZOLVAREA PROBLEMEI DE SELECȚIE ---
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Masa masa = (Masa) o;
        return id != null && id.equals(masa.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}