package org.example.mip_tema2;

import com.google.gson.Gson;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Singleton persistent care păstrează setările aplicației.
 * Salvează automat în 'settings.json' la orice modificare și încarcă la pornire.
 */
public class GlobalSettings {
    private static GlobalSettings instance;
    private static final String FILE_NAME = "settings.json";

    // Starea ofertelor (implicit false)
    private boolean happyHourActive = false;
    private boolean mealDealActive = false;
    private boolean partyPackActive = false;

    // Constructor privat
    private GlobalSettings() {}

    /**
     * Returnează instanța unică.
     * Dacă nu există în memorie, încearcă să o încarce din fișier.
     */
    public static synchronized GlobalSettings getInstance() {
        if (instance == null) {
            instance = loadFromFile();
        }
        return instance;
    }

    // --- METODE DE PERSISTENȚĂ (Load/Save) ---

    private static GlobalSettings loadFromFile() {
        File file = new File(FILE_NAME);
        if (file.exists()) {
            try (FileReader reader = new FileReader(file)) {
                // Citim starea salvată anterior
                return new Gson().fromJson(reader, GlobalSettings.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // Dacă fișierul nu există, returnăm setările implicite (totul false)
        return new GlobalSettings();
    }

    private void save() {
        try (FileWriter writer = new FileWriter(FILE_NAME)) {
            // Scriem starea curentă în fișier
            new Gson().toJson(this, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- GETTERS & SETTERS (Cu Auto-Save) ---

    public boolean isHappyHourActive() {
        return happyHourActive;
    }

    public void setHappyHourActive(boolean happyHourActive) {
        this.happyHourActive = happyHourActive;
        save(); // Salvăm imediat ce se modifică
    }

    public boolean isMealDealActive() {
        return mealDealActive;
    }

    public void setMealDealActive(boolean mealDealActive) {
        this.mealDealActive = mealDealActive;
        save(); // Salvăm imediat
    }

    public boolean isPartyPackActive() {
        return partyPackActive;
    }

    public void setPartyPackActive(boolean partyPackActive) {
        this.partyPackActive = partyPackActive;
        save(); // Salvăm imediat
    }
}