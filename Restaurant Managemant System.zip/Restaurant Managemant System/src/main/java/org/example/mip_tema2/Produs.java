package org.example.mip_tema2;

import jakarta.persistence.*;
import javafx.beans.property.*;
import com.google.gson.annotations.SerializedName;
import org.hibernate.annotations.Proxy;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonProperty; // Import necesar nou

// 1. Aici schimbam din "tip_produs" in "type" (pentru ca in JSON ai cheia "type")
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type"
)
// 2. Aici folosim litere mici la 'name' pentru ca in JSON ai "type": "pizza" (nu "Pizza")
@JsonSubTypes({
        @JsonSubTypes.Type(value = Pizza.class, name = "pizza"),
        @JsonSubTypes.Type(value = Bautura.class, name = "bautura"),
        @JsonSubTypes.Type(value = PreparatCulinar.class, name = "preparatculinar")
})

@Entity
@Table(name = "produse")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tip_produs")
@Proxy(lazy = false)
// 3. Adaugam Pizza in lista permits (daca Pizza extinde direct Produs)
public abstract sealed class Produs permits PreparatCulinar, Bautura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Mapare SQL: numedb | Mapare JSON: "nume"
    @Column(name = "numedb")
    @SerializedName("nume") // Pentru Gson
    @JsonProperty("nume")   // 4. Pentru Jackson (Importul tau curent)
    private String numeDb;

    // Mapare SQL: pretdb | Mapare JSON: "pret"
    @Column(name = "pretdb")
    @SerializedName("pret") // Pentru Gson
    @JsonProperty("pret")   // 4. Pentru Jackson
    private double pretDb;

    // Proprietatea JavaFX (nu se salvează în DB)
    @Transient
    private DoubleProperty pretProperty;

    protected Produs() {
        // Constructor gol cerut de Hibernate & Jackson
    }

    public Produs(String nume, double pret) {
        this.numeDb = nume;
        this.pretDb = pret;
    }

    public Long getId() { return id; }

    public String getNume() { return numeDb; }

    // Setter necesar pentru Jackson uneori, daca nu foloseste direct field-ul
    public void setNume(String nume) { this.numeDb = nume; }

    public double getPret() {
        return pretProperty != null ? pretProperty.get() : pretDb;
    }

    public void setPret(double pret) { this.pretDb = pret; }

    // Binding-ul pentru GUI
    public DoubleProperty pretProperty() {
        if (pretProperty == null) {
            pretProperty = new SimpleDoubleProperty(this, "pret", pretDb);
            // Sincronizăm proprietatea cu câmpul salvat în DB
            pretProperty.addListener((obs, old, newValue) -> this.pretDb = newValue.doubleValue());
        }
        return pretProperty;
    }

    public abstract String detalii();

    @Override
    public String toString() {
        return numeDb + " (" + getPret() + " RON)";
    }
}