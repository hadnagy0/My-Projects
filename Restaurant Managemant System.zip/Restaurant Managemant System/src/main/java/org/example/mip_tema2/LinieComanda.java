package org.example.mip_tema2;
public final class LinieComanda {
    private final Produs produs;
    private final int cantitate;

    public LinieComanda(Produs produs, int cantitate) {
        if (produs == null) throw new IllegalArgumentException("Produs nul");
        if (cantitate <= 0) throw new IllegalArgumentException("Cantitate invalida");
        this.produs = produs;
        this.cantitate = cantitate;
    }

    public Produs getProdus() { return produs; }
    public int getCantitate() { return cantitate; }
}
