package org.example.mip_tema2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import org.example.mip_tema2.Repository.ProdusRepository;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GuestController {

    // UI Components
    @FXML private TableView<Produs> productTable;
    @FXML private TableColumn<Produs, String> nameColumn;
    @FXML private TableColumn<Produs, Double> priceColumn;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> typeComboBox;
    @FXML private CheckBox vegetarianCheckBox;
    @FXML private Slider priceSlider;
    @FXML private VBox detailsPanel;
    @FXML private Label detailsNameLabel;
    @FXML private Label detailsPriceLabel;
    @FXML private Label detailsTypeLabel;
    @FXML private Label detailsSpecificLabel;

    private final ProdusRepository produsRepository = new ProdusRepository();
    private List<Produs> allProducts;
    private final ObservableList<Produs> filteredProducts = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // 1. Load all data from repository
        allProducts = produsRepository.findAll();

        // 2. Configure Table
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("nume"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("pret"));
        productTable.setItems(filteredProducts);

        // 3. Configure Filters
        setupFilterControls();

        // 4. Configure Details Panel
        productTable.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, newSelection) -> showProductDetails(newSelection)
        );

        // 5. Initial data load
        applyFilters();
    }

    private void setupFilterControls() {
        // Populate type filter
        typeComboBox.getItems().add("Toate");
        typeComboBox.getItems().addAll(
                allProducts.stream()
                        .map(p -> p.getClass().getSimpleName())
                        .distinct()
                        .sorted()
                        .collect(Collectors.toList())
        );
        typeComboBox.getSelectionModel().select("Toate");

        // Set price slider range
        double maxPrice = allProducts.stream().mapToDouble(Produs::getPret).max().orElse(100.0);
        priceSlider.setMax(Math.ceil(maxPrice / 10.0) * 10); // Round up to nearest 10
        priceSlider.setValue(priceSlider.getMax());

        // Add listeners to all filter controls
        searchField.textProperty().addListener((obs, old, val) -> applyFilters());
        typeComboBox.valueProperty().addListener((obs, old, val) -> applyFilters());
        vegetarianCheckBox.selectedProperty().addListener((obs, old, val) -> applyFilters());
        priceSlider.valueProperty().addListener((obs, old, val) -> applyFilters());
    }

    private void applyFilters() {
        Stream<Produs> stream = allProducts.stream();

        // Căutare robustă după nume
        String searchQuery = searchField.getText();
        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            stream = stream.filter(p -> p.getNume().toLowerCase().contains(searchQuery.toLowerCase()));
        }

        // Filtrare complexă (Tip, Vegetarian, Preț)
        String selectedType = typeComboBox.getValue();
        if (selectedType != null && !selectedType.equals("Toate")) {
            stream = stream.filter(p -> p.getClass().getSimpleName().equals(selectedType));
        }

        if (vegetarianCheckBox.isSelected()) {
            stream = stream.filter(p -> {
                // Verificăm dacă e instanță de PreparatCulinar (care include și Pizza)
                if (p instanceof PreparatCulinar) {
                    // FIX: Folosim direct boolean-ul, fără .orElse(false)
                    return ((PreparatCulinar) p).isVegetarian();
                }
                return false; // Băuturile nu sunt considerate vegetariene în acest context de filtrare
            });
        }

        double maxPrice = priceSlider.getValue();
        stream = stream.filter(p -> p.getPret() <= maxPrice);

        // Update the table
        filteredProducts.setAll(stream.collect(Collectors.toList()));
    }

    private void showProductDetails(Produs produs) {
        if (produs != null) {
            detailsNameLabel.setText("Nume: " + produs.getNume());
            detailsPriceLabel.setText(String.format("Pret: %.2f RON", produs.getPret()));
            detailsTypeLabel.setText("Tip: " + produs.getClass().getSimpleName());
            detailsSpecificLabel.setText("Specific: " + produs.detalii());
            detailsPanel.setVisible(true);
        } else {
            detailsNameLabel.setText("Nume: -");
            detailsPriceLabel.setText("Pret: -");
            detailsTypeLabel.setText("Tip: -");
            detailsSpecificLabel.setText("Specific: -");
        }
    }
}