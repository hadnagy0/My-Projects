package org.example.mip_tema2;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.Proxy;

@Entity
@DiscriminatorValue("PREPARAT") // FIX: Revenim la ce era in DB (sau PREPARAT_CULINAR, verifica DB-ul daca mai da eroare)
@Proxy(lazy = false)
public non-sealed class PreparatCulinar extends Produs {

    @Column(name = "gramaj")
    @JsonProperty("gramaj")
    private int gramaj;

    @Column(name = "este_vegetarian")
    @JsonProperty("vegetarian")
    private boolean vegetarian;

    protected PreparatCulinar() {
        super();
    }

    public PreparatCulinar(String nume, double pret, int gramaj) {
        this(nume, pret, gramaj, false);
    }

    @JsonCreator
    public PreparatCulinar(
            @JsonProperty("nume") String nume,
            @JsonProperty("pret") double pret,
            @JsonProperty("gramaj") int gramaj,
            @JsonProperty("vegetarian") boolean vegetarian) {

        super(nume, pret);
        if (gramaj <= 0) throw new IllegalArgumentException("Gramaj invalid");
        this.gramaj = gramaj;
        this.vegetarian = vegetarian;
    }

    public int getGramaj() { return gramaj; }
    public void setGramaj(int gramaj) { this.gramaj = gramaj; }

    public boolean isVegetarian() { return vegetarian; }
    public void setVegetarian(boolean vegetarian) { this.vegetarian = vegetarian; }

    @Override
    public String detalii() {
        String vegStatus = vegetarian ? " - vegetarian" : "";
        return "Gramaj: " + gramaj + "g" + vegStatus;
    }
}