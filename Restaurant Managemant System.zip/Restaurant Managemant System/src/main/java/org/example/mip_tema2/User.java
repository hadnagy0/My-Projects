package org.example.mip_tema2;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password; // In a real app, this should be hashed

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private UserRole role;

    // A staff member can have multiple orders
    @OneToMany(mappedBy = "staff", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comanda> comenziProcesate = new ArrayList<>();

    public enum UserRole {
        GUEST, STAFF, ADMIN
    }

    // JPA constructor
    protected User() {}

    public User(String username, String password, UserRole role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public UserRole getRole() { return role; }
    public List<Comanda> getComenziProcesate() { return comenziProcesate; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(UserRole role) { this.role = role; }
}
