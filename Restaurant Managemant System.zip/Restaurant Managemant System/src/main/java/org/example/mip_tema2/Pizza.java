package org.example.mip_tema2;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("PIZZA") // Majuscule pentru compatibilitate DB
public final class Pizza extends PreparatCulinar {

    @Column(name = "tip_blat")
    private String blat;

    @Column(name = "tip_sos")
    private String sos;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "pizza_toppinguri", joinColumns = @JoinColumn(name = "pizza_id"))
    @Column(name = "topping")
    private List<String> toppinguri = new ArrayList<>();

    protected Pizza() {
        super();
    }

    // Constructor JSON
    @JsonCreator
    public Pizza(
            @JsonProperty("nume") String nume,
            @JsonProperty("pret") double pret,
            @JsonProperty("gramaj") int gramaj,
            @JsonProperty("blat") String blat,
            @JsonProperty("sos") String sos,
            @JsonProperty("toppinguri") List<String> toppinguri,
            @JsonProperty("vegetarian") boolean vegetarian) {

        super(nume, pret, gramaj, vegetarian);

        if (blat == null || blat.isBlank()) throw new IllegalArgumentException("Tip blat obligatoriu");
        if (sos == null || sos.isBlank()) throw new IllegalArgumentException("Tip sos obligatoriu");

        this.blat = blat;
        this.sos = sos;
        this.toppinguri = toppinguri == null ? new ArrayList<>() : new ArrayList<>(toppinguri);
    }

    // Constructor Builder
    private Pizza(Builder b) {
        super(b.nume, b.pret, b.gramaj, b.vegetarian);
        this.blat = b.blat;
        this.sos = b.sos;
        this.toppinguri = new ArrayList<>(b.toppinguri);
    }

    // --- GETTERI ---
    public String getBlat() { return blat; }
    public String getSos() { return sos; }
    public List<String> getToppinguri() { return toppinguri; }

    // --- SETTERI (Adăugați pentru a repara eroarea din AdminController) ---
    public void setBlat(String blat) { this.blat = blat; }
    public void setSos(String sos) { this.sos = sos; }
    public void setToppinguri(List<String> toppinguri) { this.toppinguri = toppinguri; }

    @Override
    public String detalii() {
        String base = "Blat: " + blat + " - Sos: " + sos;
        if (toppinguri != null && !toppinguri.isEmpty()) {
            base += " - Toppinguri: " + String.join(", ", toppinguri);
        }
        return super.detalii() + " | " + base;
    }

    public static Builder builder(String nume, double pret, int gramaj, String blat, String sos) {
        return new Builder(nume, pret, gramaj, blat, sos);
    }

    public static final class Builder {
        private final String nume;
        private final double pret;
        private final int gramaj;
        private final String blat;
        private final String sos;
        private final List<String> toppinguri = new ArrayList<>();
        private boolean vegetarian = false;

        private Builder(String nume, double pret, int gramaj, String blat, String sos) {
            this.nume = nume; this.pret = pret; this.gramaj = gramaj;
            this.blat = blat; this.sos = sos;
        }

        public Builder addTopping(String topping) {
            if (topping != null && !topping.isBlank()) toppinguri.add(topping.trim());
            return this;
        }

        public Builder vegetarian(boolean v) {
            this.vegetarian = v;
            return this;
        }

        public Pizza build() {
            return new Pizza(this);
        }
    }
}