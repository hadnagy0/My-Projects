package org.example.mip_tema2;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import org.example.mip_tema2.Repository.ComandaRepository;
import org.example.mip_tema2.Repository.MasaRepository;
import org.example.mip_tema2.Repository.ProdusRepository;
import org.example.mip_tema2.Repository.UserRepository;

// --- IMPORTURI PENTRU JSON (JACKSON) ---
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class AdminController {

    // --- REPOSITORIES ---
    private final ProdusRepository produsRepository = new ProdusRepository();
    private final UserRepository userRepository = new UserRepository();
    private final MasaRepository masaRepository = new MasaRepository();
    private final ComandaRepository comandaRepository = new ComandaRepository();

    // --- FXML FIELDS: Products Tab ---
    @FXML private TableView<Produs> productsTable;
    @FXML private TableColumn<Produs, Long> productIdColumn;
    @FXML private TableColumn<Produs, String> productNameColumn;
    @FXML private TableColumn<Produs, Double> productPriceColumn;
    @FXML private TableColumn<Produs, String> productTypeColumn;
    @FXML private TableColumn<Produs, String> productDetailsColumn;

    // --- FXML FIELDS: Users Tab ---
    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, Long> userIdColumn;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, User.UserRole> userRoleColumn;

    // --- FXML FIELDS: Tables Tab ---
    @FXML private TableView<Masa> tablesTable;
    @FXML private TableColumn<Masa, Long> tableIdColumn;
    @FXML private TableColumn<Masa, Integer> tableNumberColumn;
    @FXML private TableColumn<Masa, Integer> tableCapacityColumn;
    @FXML private TableColumn<Masa, Masa.MasaStatus> tableStatusColumn;

    // --- FXML FIELDS: Offers ---
    @FXML private CheckBox happyHourCheckBox;
    @FXML private CheckBox pizzaOfferCheckBox;
    @FXML private CheckBox partyPackCheckBox;

    // --- FXML FIELDS: Global History Tab ---
    @FXML private TableView<Comanda> globalHistoryTable;
    @FXML private TableColumn<Comanda, Long> ghIdColumn;
    @FXML private TableColumn<Comanda, Object> ghMasaColumn;
    @FXML private TableColumn<Comanda, String> ghStaffColumn;
    @FXML private TableColumn<Comanda, String> ghDateColumn;
    @FXML private TableColumn<Comanda, Double> ghTotalColumn;
    @FXML private TableColumn<Comanda, Comanda.ComandaStatus> ghStatusColumn;

    @FXML
    public void initialize() {
        System.out.println("AdminController: Initializare...");
        setupProductTable();
        setupUsersTable();
        setupTablesTable();
        setupGlobalHistory();
        setupOffers();

        loadAllData();
    }

    // --- SETUP METHODS ---
    private void setupProductTable() {
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("nume"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("pret"));

        productTypeColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getClass().getSimpleName()));

        productDetailsColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().detalii()));
    }

    private void setupUsersTable() {
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        userRoleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
    }

    private void setupTablesTable() {
        tableIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableNumberColumn.setCellValueFactory(new PropertyValueFactory<>("numar"));
        tableCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacitate"));
        tableStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupGlobalHistory() {
        ghIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        ghMasaColumn.setCellValueFactory(cell -> {
            if (cell.getValue().getMasa() != null) {
                return new SimpleObjectProperty<>(cell.getValue().getMasa().getNumar());
            } else {
                return new SimpleObjectProperty<>("Masa Ștearsă");
            }
        });

        ghStaffColumn.setCellValueFactory(cell -> {
            User staff = cell.getValue().getStaff();
            return new SimpleStringProperty(staff != null ? staff.getUsername() : "N/A");
        });

        ghDateColumn.setCellValueFactory(cell -> {
            if (cell.getValue().getDataCreare() != null) {
                DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
                return new SimpleStringProperty(cell.getValue().getDataCreare().format(fmt));
            }
            return new SimpleStringProperty("-");
        });

        ghTotalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));
        ghStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupOffers() {
        GlobalSettings settings = GlobalSettings.getInstance();

        if (happyHourCheckBox != null) {
            happyHourCheckBox.setSelected(settings.isHappyHourActive());
            happyHourCheckBox.selectedProperty().addListener((obs, old, val) -> settings.setHappyHourActive(val));
        }
        if (pizzaOfferCheckBox != null) {
            pizzaOfferCheckBox.setSelected(settings.isMealDealActive());
            pizzaOfferCheckBox.selectedProperty().addListener((obs, old, val) -> settings.setMealDealActive(val));
        }
        if (partyPackCheckBox != null) {
            partyPackCheckBox.setSelected(settings.isPartyPackActive());
            partyPackCheckBox.selectedProperty().addListener((obs, old, val) -> settings.setPartyPackActive(val));
        }
    }

    // --- LOAD DATA ---
    public void loadAllData() {
        loadProducts();
        loadUsers();
        loadTables();
        handleRefreshHistory();
    }

    private void loadProducts() {
        List<Produs> list = produsRepository.findAll();
        productsTable.setItems(FXCollections.observableArrayList(list));
        productsTable.refresh();
    }

    private void loadUsers() {
        usersTable.setItems(FXCollections.observableArrayList(userRepository.findAll()));
        usersTable.refresh();
    }

    private void loadTables() {
        tablesTable.setItems(FXCollections.observableArrayList(masaRepository.findAll()));
        tablesTable.refresh();
    }

    @FXML
    private void handleRefreshHistory() {
        if (globalHistoryTable != null) {
            List<Comanda> comenzi = comandaRepository.findAll();
            globalHistoryTable.getItems().clear();

            if (comenzi != null && !comenzi.isEmpty()) {
                globalHistoryTable.getItems().addAll(comenzi);
            }
            globalHistoryTable.refresh();
        } else {
            System.err.println("EROARE: globalHistoryTable nu este injectat (fx:id gresit?)");
        }
    }

    // =================================================================================
    //                            LOGICA PRODUSE
    // =================================================================================

    @FXML
    private void handleAddProduct() {
        showProductDialog(null);
    }

    @FXML
    private void handleEditProduct() {
        Produs selected = productsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Te rog selecteaza un produs pentru editare.");
            return;
        }
        showProductDialog(selected);
    }

    @FXML
    private void handleDeleteProduct() {
        Produs selected = productsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Te rog selecteaza un produs pentru stergere.");
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Sigur vrei sa stergi: " + selected.getNume() + "?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                produsRepository.sterge(selected);
                loadProducts();
            }
        });
    }

    private void showProductDialog(Produs produsDeEditat) {
        Dialog<Produs> dialog = new Dialog<>();
        dialog.setTitle(produsDeEditat == null ? "Adaugă Produs Nou" : "Editează Produs");
        dialog.setHeaderText("Completează detaliile produsului.");

        ButtonType saveButtonType = new ButtonType("Salvează", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);

        ComboBox<String> typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("PreparatCulinar", "Bautura", "Pizza");

        TextField numeField = new TextField(); numeField.setPromptText("Nume Produs");
        TextField pretField = new TextField(); pretField.setPromptText("Pret (RON)");

        // Dynamic Fields
        TextField gramajField = new TextField(); gramajField.setPromptText("Gramaj (g)");
        CheckBox vegetarianCheck = new CheckBox("Vegetarian");
        TextField volumField = new TextField(); volumField.setPromptText("Volum (ml)");
        CheckBox alcoolicCheck = new CheckBox("Alcoolic");

        // Pizza specific
        TextField blatField = new TextField(); blatField.setPromptText("Tip Blat (ex: Subtire)");
        TextField sosField = new TextField(); sosField.setPromptText("Tip Sos (ex: Rosii)");
        TextField toppingField = new TextField(); toppingField.setPromptText("Toppinguri (sep. prin virgula)");

        VBox dynamicArea = new VBox(10);

        grid.add(new Label("Tip Produs:"), 0, 0); grid.add(typeCombo, 1, 0);
        grid.add(new Label("Nume:"), 0, 1); grid.add(numeField, 1, 1);
        grid.add(new Label("Pret:"), 0, 2); grid.add(pretField, 1, 2);
        grid.add(dynamicArea, 0, 3, 2, 1);

        dialog.getDialogPane().setContent(grid);

        // Switch Logic based on selection
        typeCombo.valueProperty().addListener((obs, oldVal, newVal) -> {
            dynamicArea.getChildren().clear();
            if (newVal == null) return;

            if (newVal.equals("Bautura")) {
                dynamicArea.getChildren().addAll(new Label("Volum (ml):"), volumField, alcoolicCheck);
            } else {
                dynamicArea.getChildren().addAll(new Label("Gramaj (g):"), gramajField, vegetarianCheck);
                if (newVal.equals("Pizza")) {
                    dynamicArea.getChildren().addAll(
                            new Label("Blat:"), blatField,
                            new Label("Sos:"), sosField,
                            new Label("Toppinguri:"), toppingField
                    );
                }
            }
            if (dialog.getDialogPane().getScene() != null) {
                dialog.getDialogPane().getScene().getWindow().sizeToScene();
            }
        });

        // Pre-fill if editing
        if (produsDeEditat != null) {
            typeCombo.setDisable(true);
            numeField.setText(produsDeEditat.getNume());
            pretField.setText(String.valueOf(produsDeEditat.getPret()));

            if (produsDeEditat instanceof Pizza) {
                typeCombo.setValue("Pizza");
                Pizza p = (Pizza) produsDeEditat;
                gramajField.setText(String.valueOf(p.getGramaj()));
                vegetarianCheck.setSelected(p.isVegetarian()); // Acum este in PreparatCulinar, deci si in Pizza
                blatField.setText(p.getBlat());
                sosField.setText(p.getSos());
                toppingField.setText(String.join(", ", p.getToppinguri()));
            } else if (produsDeEditat instanceof PreparatCulinar) {
                typeCombo.setValue("PreparatCulinar");
                PreparatCulinar p = (PreparatCulinar) produsDeEditat;
                gramajField.setText(String.valueOf(p.getGramaj()));
                vegetarianCheck.setSelected(p.isVegetarian());
            } else if (produsDeEditat instanceof Bautura) {
                typeCombo.setValue("Bautura");
                Bautura b = (Bautura) produsDeEditat;
                volumField.setText(String.valueOf(b.getVolumMl()));
                alcoolicCheck.setSelected(b.isAlcoolic());
            }
        } else {
            typeCombo.setValue("PreparatCulinar"); // Default
        }

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    String tip = typeCombo.getValue();
                    String nume = numeField.getText();
                    double pret = Double.parseDouble(pretField.getText());

                    if (tip.equals("Bautura")) {
                        int volum = Integer.parseInt(volumField.getText());
                        return new Bautura(nume, pret, volum, alcoolicCheck.isSelected());
                    } else if (tip.equals("Pizza")) {
                        int gramaj = Integer.parseInt(gramajField.getText());
                        List<String> toppings = Arrays.asList(toppingField.getText().split("\\s*,\\s*"));

                        // FIX: Pasam si vegetarianCheck.isSelected() la constructorul de Pizza
                        return new Pizza(nume, pret, gramaj, blatField.getText(), sosField.getText(), toppings, vegetarianCheck.isSelected());
                    } else {
                        // PreparatCulinar
                        int gramaj = Integer.parseInt(gramajField.getText());
                        // FIX: Pasam si vegetarianCheck.isSelected() la constructorul de PreparatCulinar
                        return new PreparatCulinar(nume, pret, gramaj, vegetarianCheck.isSelected());
                    }
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Eroare Validare", "Te rog verifica datele introduse.");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(produsNou -> {
            if (produsDeEditat != null) {
                produsRepository.sterge(produsDeEditat);
            }
            produsRepository.salveaza(produsNou);
            loadProducts();
        });
    }

    // =================================================================================
    //                            LOGICA UTILIZATORI
    // =================================================================================

    @FXML
    private void handleAddUser() {
        showUserDialog(null);
    }

    @FXML
    private void handleEditUser() {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Te rog selecteaza un utilizator.");
            return;
        }
        showUserDialog(selectedUser);
    }

    @FXML
    private void handleDeleteUser() {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Va rugam selectati un utilizator.");
            return;
        }
        if ("admin".equalsIgnoreCase(selectedUser.getUsername())) {
            showAlert(Alert.AlertType.ERROR, "Operatie Interzisa", "Utilizatorul 'admin' nu poate fi sters.");
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION, "Stergi utilizatorul " + selectedUser.getUsername() + "?", ButtonType.YES, ButtonType.NO);
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                userRepository.delete(selectedUser);
                loadUsers();
            }
        });
    }

    private void showUserDialog(User userDeEditat) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle(userDeEditat == null ? "Adauga Utilizator" : "Editeaza Utilizator");
        dialog.setHeaderText("Detalii de autentificare.");

        ButtonType saveButtonType = new ButtonType("Salveaza", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);

        TextField usernameField = new TextField(); usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField(); passwordField.setPromptText("Parola");
        ComboBox<User.UserRole> roleCombo = new ComboBox<>();
        roleCombo.getItems().setAll(User.UserRole.values());
        roleCombo.getSelectionModel().select(User.UserRole.STAFF);

        grid.add(new Label("Username:"), 0, 0); grid.add(usernameField, 1, 0);
        grid.add(new Label("Parola:"), 0, 1); grid.add(passwordField, 1, 1);
        grid.add(new Label("Rol:"), 0, 2); grid.add(roleCombo, 1, 2);

        if (userDeEditat != null) {
            usernameField.setText(userDeEditat.getUsername());
            passwordField.setText(userDeEditat.getPassword());
            roleCombo.setValue(userDeEditat.getRole());
            if ("admin".equalsIgnoreCase(userDeEditat.getUsername())) {
                usernameField.setDisable(true);
            }
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String u = usernameField.getText();
                String p = passwordField.getText();
                User.UserRole r = roleCombo.getValue();
                if (u.isEmpty() || p.isEmpty()) return null;
                return new User(u, p, r);
            }
            return null;
        });

        dialog.showAndWait().ifPresent(tempUser -> {
            if (userDeEditat != null) {
                userDeEditat.setUsername(tempUser.getUsername());
                userDeEditat.setPassword(tempUser.getPassword());
                userDeEditat.setRole(tempUser.getRole());
                userRepository.save(userDeEditat);
            } else {
                userRepository.save(tempUser);
            }
            loadUsers();
        });
    }

    // =================================================================================
    //                            LOGICA MESE
    // =================================================================================

    @FXML
    private void handleAddTable() {
        showMasaDialog(null);
    }

    @FXML
    private void handleEditTable() {
        Masa selectedMasa = tablesTable.getSelectionModel().getSelectedItem();
        if (selectedMasa == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Te rog selecteaza o masa.");
            return;
        }
        showMasaDialog(selectedMasa);
    }

    @FXML
    private void handleDeleteTable() {
        Masa selectedMasa = tablesTable.getSelectionModel().getSelectedItem();
        if (selectedMasa == null) {
            showAlert(Alert.AlertType.WARNING, "Selectie lipsa", "Te rog selecteaza o masa.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "Sigur vrei sa stergi Masa " + selectedMasa.getNumar() + "?",
                ButtonType.YES, ButtonType.NO);

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    masaRepository.delete(selectedMasa);
                    loadTables();
                } catch (Exception e) {
                    showAlert(Alert.AlertType.ERROR, "Eroare Stergere",
                            "Aceasta masa nu poate fi stearsa (posibil are comenzi active).");
                }
            }
        });
    }

    private void showMasaDialog(Masa masaDeEditat) {
        Dialog<Masa> dialog = new Dialog<>();
        dialog.setTitle(masaDeEditat == null ? "Adauga Masa" : "Editeaza Masa");

        ButtonType saveButtonType = new ButtonType("Salveaza", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);

        TextField numarField = new TextField(); numarField.setPromptText("Numar masa");
        TextField capacitateField = new TextField(); capacitateField.setPromptText("Capacitate");

        grid.add(new Label("Numar:"), 0, 0); grid.add(numarField, 1, 0);
        grid.add(new Label("Capacitate:"), 0, 1); grid.add(capacitateField, 1, 1);

        if (masaDeEditat != null) {
            numarField.setText(String.valueOf(masaDeEditat.getNumar()));
            capacitateField.setText(String.valueOf(masaDeEditat.getCapacitate()));
        }

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    int nr = Integer.parseInt(numarField.getText());
                    int cap = Integer.parseInt(capacitateField.getText());
                    return new Masa(nr, cap);
                } catch (NumberFormatException e) {
                    showAlert(Alert.AlertType.ERROR, "Eroare", "Te rog introdu doar numere intregi.");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(masaRezultata -> {
            if (masaDeEditat != null) {
                masaDeEditat.setNumar(masaRezultata.getNumar());
                masaDeEditat.setCapacitate(masaRezultata.getCapacitate());
                masaRepository.save(masaDeEditat);
            } else {
                masaRepository.save(masaRezultata);
            }
            loadTables();
        });
    }

    // =================================================================================
    //             LOGICA JSON (FIȘIERE SPECIFICE - FARA FILE CHOOSER)
    // =================================================================================

    @FXML
    private void handleExportJson() {
        File file = new File("export_db_final.json");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        try {
            List<Produs> produse = produsRepository.findAll();
            mapper.writeValue(file, produse);

            showAlert(Alert.AlertType.INFORMATION, "Export Reușit",
                    "Datele au fost salvate în:\n" + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Eroare Export",
                    "Nu s-a putut scrie în fișier: " + e.getMessage());
        }
    }

    @FXML
    private void handleImportJson() {
        File file = new File("menu-export.json");

        if (file.exists()) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                // 1. Citim fisierul JSON
                JsonNode rootNode = mapper.readTree(file);
                List<Produs> produseDinJson = new ArrayList<>();

                // Logica de citire (aceeasi ca inainte)
                if (rootNode.isArray()) {
                    List<Produs> lista = mapper.convertValue(rootNode, new TypeReference<List<Produs>>(){});
                    produseDinJson.addAll(lista);
                } else if (rootNode.isObject()) {
                    try {
                        Produs p = mapper.treeToValue(rootNode, Produs.class);
                        produseDinJson.add(p);
                    } catch (Exception e) {
                        rootNode.fields().forEachRemaining(entry -> {
                            if (entry.getValue().isArray()) {
                                try {
                                    produseDinJson.addAll(mapper.convertValue(entry.getValue(), new TypeReference<List<Produs>>(){}));
                                } catch (Exception ex) { }
                            }
                        });
                    }
                }

                // 2. LOGICA ANTI-DUPLICARE (Smart Merge)
                if (!produseDinJson.isEmpty()) {
                    // Încărcăm produsele existente din DB ca să comparăm
                    List<Produs> produseDinDb = produsRepository.findAll();
                    int actualizate = 0;
                    int noi = 0;

                    for (Produs pNou : produseDinJson) {
                        // Căutăm dacă există deja un produs cu același nume (ignorăm litere mari/mici)
                        java.util.Optional<Produs> existentOpt = produseDinDb.stream()
                                .filter(pDb -> pDb.getNume().equalsIgnoreCase(pNou.getNume()))
                                .findFirst();

                        if (existentOpt.isPresent()) {
                            // UPDATE: Dacă există, actualizăm datele celui vechi cu datele celui nou
                            Produs pVechi = existentOpt.get();
                            updateProdusExistent(pVechi, pNou);
                            produsRepository.salveaza(pVechi);
                            actualizate++;
                        } else {
                            // INSERT: Dacă nu există, îl salvăm ca nou
                            produsRepository.salveaza(pNou);
                            noi++;
                        }
                    }

                    loadProducts(); // Reimprospatam tabelul
                    showAlert(Alert.AlertType.INFORMATION, "Import Reușit",
                            "Import complet!\nProduse noi adăugate: " + noi + "\nProduse actualizate: " + actualizate);
                } else {
                    showAlert(Alert.AlertType.WARNING, "Atentie", "Nu s-au găsit produse valide în fișier.");
                }

            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Eroare Import", "Nu s-a putut citi fișierul: " + e.getMessage());
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Fișier Lipsă", "Nu am găsit fișierul 'menu-export.json'.");
        }
    }

    // --- METODĂ AJUTĂTOARE PENTRU UPDATE ---
    private void updateProdusExistent(Produs pVechi, Produs pNou) {
        // Actualizăm câmpurile comune
        pVechi.setPret(pNou.getPret());
        // Numele nu îl schimbăm că e același (baza de căutare)

        // Actualizăm câmpurile specifice în funcție de tip
        if (pVechi instanceof Pizza && pNou instanceof Pizza) {
            Pizza oldP = (Pizza) pVechi;
            Pizza newP = (Pizza) pNou;
            oldP.setGramaj(newP.getGramaj());
            oldP.setVegetarian(newP.isVegetarian());
            oldP.setBlat(newP.getBlat());
            oldP.setSos(newP.getSos());
            oldP.setToppinguri(newP.getToppinguri()); // Suprascrie lista veche
        }
        else if (pVechi instanceof PreparatCulinar && pNou instanceof PreparatCulinar) {
            // (Pizza intră și aici, dar e prinsă mai sus dacă e instanță de Pizza)
            // Aici intră preparatele care NU sunt Pizza (ex: Paste, Salate)
            if (!(pVechi instanceof Pizza)) {
                PreparatCulinar oldP = (PreparatCulinar) pVechi;
                PreparatCulinar newP = (PreparatCulinar) pNou;
                oldP.setGramaj(newP.getGramaj());
                oldP.setVegetarian(newP.isVegetarian());
            }
        }
        else if (pVechi instanceof Bautura && pNou instanceof Bautura) {
            Bautura oldB = (Bautura) pVechi;
            Bautura newB = (Bautura) pNou;
            oldB.setVolumMl(newB.getVolumMl());
            oldB.setAlcoolic(newB.isAlcoolic());
        }
    }
    // --- HELPER ---
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}