using System.Windows;
using RestaurantApp.Data;
using RestaurantApp.Models;
using System.Linq;
using System;
using Microsoft.EntityFrameworkCore;

namespace RestaurantApp
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            using var context = new RestaurantDbContext();
            context.Database.EnsureCreated();

            // Seed logic if less than 10 dishes exist
            if (context.Dishes.Count() < 10)
            {
                // Clear existing data to avoid conflicts for this demo seed
                context.Database.ExecuteSqlRaw("DELETE FROM OrderItems");
                context.Database.ExecuteSqlRaw("DELETE FROM Orders");
                context.Database.ExecuteSqlRaw("DELETE FROM MenuDishes");
                context.Database.ExecuteSqlRaw("DELETE FROM Menus");
                context.Database.ExecuteSqlRaw("DELETE FROM DishAllergens");
                context.Database.ExecuteSqlRaw("DELETE FROM Dishes");
                context.Database.ExecuteSqlRaw("DELETE FROM Categories");
                context.Database.ExecuteSqlRaw("DELETE FROM Allergens");

                // Categories
                var catPizza = new Category { Name = "Pizza" };
                var catBauturi = new Category { Name = "Bauturi" };
                var catSupe = new Category { Name = "Supe/Ciorbe" };
                var catAperitive = new Category { Name = "Aperitive" };
                var catDesert = new Category { Name = "Desert" };
                context.Categories.AddRange(catPizza, catBauturi, catSupe, catAperitive, catDesert);
                context.SaveChanges();

                // Allergens
                var algGluten = new Allergen { Name = "Gluten" };
                var algLactate = new Allergen { Name = "Lactate" };
                var algOua = new Allergen { Name = "Oua" };
                var algTelina = new Allergen { Name = "Telina" };
                context.Allergens.AddRange(algGluten, algLactate, algOua, algTelina);
                context.SaveChanges();

                // Dishes (Minim 10)
                var d1 = new Dish { Name = "Pizza Margherita", Price = 30, PortionQuantity = "400g", TotalQuantity = 50, CategoryId = catPizza.CategoryId };
                var d2 = new Dish { Name = "Pizza Quattro Formaggi", Price = 35, PortionQuantity = "450g", TotalQuantity = 30, CategoryId = catPizza.CategoryId };
                var d3 = new Dish { Name = "Ciorba de burta", Price = 20, PortionQuantity = "350g", TotalQuantity = 20, CategoryId = catSupe.CategoryId };
                var d4 = new Dish { Name = "Supa crema de ciuperci", Price = 18, PortionQuantity = "300g", TotalQuantity = 25, CategoryId = catSupe.CategoryId };
                var d5 = new Dish { Name = "Bruschete", Price = 15, PortionQuantity = "200g", TotalQuantity = 40, CategoryId = catAperitive.CategoryId };
                var d6 = new Dish { Name = "Salata Caprese", Price = 25, PortionQuantity = "250g", TotalQuantity = 15, CategoryId = catAperitive.CategoryId };
                var d7 = new Dish { Name = "Tiramisu", Price = 22, PortionQuantity = "150g", TotalQuantity = 12, CategoryId = catDesert.CategoryId };
                var d8 = new Dish { Name = "Coca Cola", Price = 8, PortionQuantity = "500ml", TotalQuantity = 100, CategoryId = catBauturi.CategoryId };
                var d9 = new Dish { Name = "Apa Plata", Price = 6, PortionQuantity = "500ml", TotalQuantity = 200, CategoryId = catBauturi.CategoryId };
                var d10 = new Dish { Name = "Limonada", Price = 15, PortionQuantity = "400ml", TotalQuantity = 30, CategoryId = catBauturi.CategoryId };
                
                context.Dishes.AddRange(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10);
                context.SaveChanges();

                // Assign Allergens
                context.DishAllergens.Add(new DishAllergen { DishId = d1.DishId, AllergenId = algGluten.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d1.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d2.DishId, AllergenId = algGluten.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d2.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d3.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d3.DishId, AllergenId = algOua.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d4.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d4.DishId, AllergenId = algTelina.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d5.DishId, AllergenId = algGluten.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d6.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d7.DishId, AllergenId = algGluten.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d7.DishId, AllergenId = algLactate.AllergenId });
                context.DishAllergens.Add(new DishAllergen { DishId = d7.DishId, AllergenId = algOua.AllergenId });
                context.SaveChanges();
            }

            // Ensure dummy users exist
            var clientUser = context.Users.FirstOrDefault(u => u.Email == "client@test.com");
            if (clientUser == null)
            {
                clientUser = new User 
                { 
                    Email = "client@test.com", 
                    Password = "123", 
                    Role = "Client", 
                    FirstName = "Ion", 
                    LastName = "Popescu",
                    Phone = "0712345678",
                    Address = "Strada Fericirii Nr 10, Bucuresti"
                };
                context.Users.Add(clientUser);
                context.SaveChanges();
            }

            // Generate an order for Employee View Demo if they don't have one
            if (!context.Orders.Any())
            {
                var o1 = new Order { UserId = clientUser.UserId, OrderDate = DateTime.Now.AddHours(-2), Status = "inregistrata", TotalPrice = 53 };
                context.Orders.Add(o1);
                context.SaveChanges();
                
                var firstDish = context.Dishes.FirstOrDefault();
                if (firstDish != null)
                {
                    context.OrderItems.Add(new OrderItem { OrderId = o1.OrderId, ItemId = firstDish.DishId, ItemType = "Dish", Quantity = 1, PricePerUnit = firstDish.Price });
                    context.SaveChanges();
                }
            }

            if (!context.Users.Any(u => u.Role == "Employee"))
            {
                var employee = new User { Email = "angajat@test.com", Password = "123", Role = "Employee", FirstName = "Test", LastName = "Angajat" };
                context.Users.Add(employee);
                context.SaveChanges();
            }
        }
    }
}
