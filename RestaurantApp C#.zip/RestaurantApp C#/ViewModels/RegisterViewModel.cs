using System.Windows.Input;
using RestaurantApp.Models;
using RestaurantApp.Data;
using System.Linq;
using System.Windows;

namespace RestaurantApp.ViewModels
{
    public class RegisterViewModel : ViewModelBase
    {
        private readonly MainViewModel _mainViewModel;

        private string _email = string.Empty;
        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        private string _password = string.Empty;
        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        private string _firstName = string.Empty;
        public string FirstName
        {
            get => _firstName;
            set { _firstName = value; OnPropertyChanged(); }
        }

        private string _lastName = string.Empty;
        public string LastName
        {
            get => _lastName;
            set { _lastName = value; OnPropertyChanged(); }
        }

        private string _phone = string.Empty;
        public string Phone
        {
            get => _phone;
            set { _phone = value; OnPropertyChanged(); }
        }

        private string _address = string.Empty;
        public string Address
        {
            get => _address;
            set { _address = value; OnPropertyChanged(); }
        }

        public ICommand RegisterCommand { get; }
        public ICommand GoBackCommand { get; }

        public RegisterViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            RegisterCommand = new RelayCommand(Register, CanRegister);
            GoBackCommand = new RelayCommand(o => _mainViewModel.CurrentViewModel = new LoginViewModel(_mainViewModel));
        }

        private bool CanRegister(object? parameter)
        {
            return !string.IsNullOrWhiteSpace(Email) &&
                   !string.IsNullOrWhiteSpace(Password) &&
                   !string.IsNullOrWhiteSpace(FirstName) &&
                   !string.IsNullOrWhiteSpace(LastName);
        }

        private void Register(object? parameter)
        {
            using var context = new RestaurantDbContext();
            
            if (context.Users.Any(u => u.Email == Email))
            {
                MessageBox.Show("Acest email este deja utilizat!");
                return;
            }

            var newUser = new User
            {
                Email = Email,
                Password = Password, 
                FirstName = FirstName,
                LastName = LastName,
                Phone = Phone,
                Address = Address,
                Role = "Client"
            };

            context.Users.Add(newUser);
            context.SaveChanges();

            MessageBox.Show("Cont creat cu succes!");
            _mainViewModel.CurrentViewModel = new LoginViewModel(_mainViewModel);
        }
    }
}
