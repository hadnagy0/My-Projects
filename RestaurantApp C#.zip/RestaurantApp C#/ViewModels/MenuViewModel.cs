using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RestaurantApp.Models;
using RestaurantApp.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System;
using System.Configuration;
using System.Windows.Data;
using System.ComponentModel;

namespace RestaurantApp.ViewModels
{
    public class MenuItemDisplay
    {
        public int Id { get; set; }
        public string Type { get; set; } = string.Empty; 
        public string Name { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty; 
        public decimal Price { get; set; }
        public string Allergens { get; set; } = string.Empty;
        public bool IsAvailable { get; set; }
        public string AvailabilityText => IsAvailable ? "disponibil" : "indisponibil";
        public List<string> Images { get; set; } = new();
    }

    public class MenuViewModel : ViewModelBase
    {
        private MainViewModel _mainViewModel;

        private ObservableCollection<MenuItemDisplay> _items = new();
        public ObservableCollection<MenuItemDisplay> Items
        {
            get => _items;
            set { _items = value; OnPropertyChanged(); }
        }

        private string _searchText = string.Empty;
        public string SearchText
        {
            get => _searchText;
            set 
            { 
                _searchText = value; 
                OnPropertyChanged();
                FilterItems();
            }
        }

        private MenuItemDisplay? _selectedMenuItem;
        public MenuItemDisplay? SelectedMenuItem
        {
            get => _selectedMenuItem;
            set
            {
                _selectedMenuItem = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasSelectedMenuItem));
            }
        }

        public bool HasSelectedMenuItem => SelectedMenuItem != null;

        private string _searchType = "Name"; 
        public string SearchType
        {
            get => _searchType;
            set { _searchType = value; OnPropertyChanged(); FilterItems(); }
        }

        private string _searchMode = "Contains"; 
        public string SearchMode
        {
            get => _searchMode;
            set { _searchMode = value; OnPropertyChanged(); FilterItems(); }
        }

        public ICommand AddToCartCommand { get; }

        public MenuViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            AddToCartCommand = new RelayCommand(AddToCart, CanAddToCart);
            LoadItems();
        }

        private void LoadItems()
        {
            FilterItems();
        }

        private List<string> GetImagesForItem(string type, string name, string category)
        {
            var images = new List<string>();
            string catLower = category.ToLower();
            string nameLower = name.ToLower();

            if (catLower.Contains("bautur") || catLower.Contains("drink") || nameLower.Contains("fanta") || nameLower.Contains("pepsi") || nameLower.Contains("suc") || nameLower.Contains("ceai"))
            {
                images.Add("https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80"); 
                images.Add("https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=500&q=80"); 
                images.Add("https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=500&q=80"); 
            }
            else if (catLower.Contains("desert") || catLower.Contains("dulce") || nameLower.Contains("tort") || nameLower.Contains("clatit") || nameLower.Contains("inghetat"))
            {
                images.Add("https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1587314168485-3236d6710814?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500&q=80");
            }
            else if (catLower.Contains("supe") || catLower.Contains("ciorb") || nameLower.Contains("supe") || nameLower.Contains("ciorba") || nameLower.Contains("crema"))
            {
                images.Add("https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=500&q=80"); 
                images.Add("https://images.unsplash.com/photo-1563245372-f21724e3856d?w=500&q=80"); 
                images.Add("https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?w=500&q=80");
            }
            else if (nameLower.Contains("pizza"))
            {
                images.Add("https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1590947132387-155cc02f3212?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=500&q=80");
            }
            else if (nameLower.Contains("burger"))
            {
                images.Add("https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1550547660-d9450f859349?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=500&q=80");
            }
            else if (nameLower.Contains("pui") || nameLower.Contains("pulpe") || nameLower.Contains("snitel"))
            {
                images.Add("https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1562967914-608f82629710?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=500&q=80");
            }
            else if (nameLower.Contains("paste") || nameLower.Contains("pasta") || nameLower.Contains("spaghete"))
            {
                images.Add("https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1555072956-7758afb20e8f?w=500&q=80");
            }
            else
            {
                images.Add("https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=500&q=80");
                images.Add("https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?w=500&q=80");
            }

            return images;
        }

        private void FilterItems()
        {
            using var context = new RestaurantDbContext();
            
            var activeDishes = context.Dishes
                .Include(d => d.Category)
                .Include(d => d.DishAllergens)
                .ThenInclude(da => da.Allergen)
                .Where(d => d.IsActive)
                .ToList();
                
            var activeMenus = context.Menus
                .Include(m => m.Category)
                .Include(m => m.MenuDishes)
                .ThenInclude(md => md.Dish)
                .ThenInclude(d => d.DishAllergens)
                .ThenInclude(da => da.Allergen)
                .Where(m => m.IsActive)
                .ToList();

 
            var pendingOrders = context.Orders
                .Include(o => o.OrderItems)
                .Where(o => o.Status == "inregistrata" || o.Status == "se pregateste" || o.Status == "a plecat la client")
                .ToList();

            var pendingQuantities = new Dictionary<int, decimal>();
            foreach (var order in pendingOrders)
            {
                foreach (var orderItem in order.OrderItems)
                {
                    if (orderItem.ItemType == "Dish")
                    {
                        if (!pendingQuantities.ContainsKey(orderItem.ItemId))
                            pendingQuantities[orderItem.ItemId] = 0;
                        pendingQuantities[orderItem.ItemId] += orderItem.Quantity;
                    }
                    else if (orderItem.ItemType == "Menu")
                    {
                        var menuDishes = context.MenuDishes.Where(md => md.MenuId == orderItem.ItemId).ToList();
                        foreach (var md in menuDishes)
                        {
                            if (!pendingQuantities.ContainsKey(md.DishId))
                                pendingQuantities[md.DishId] = 0;
                            pendingQuantities[md.DishId] += orderItem.Quantity;
                        }
                    }
                }
            }

            var displayItems = new List<MenuItemDisplay>();
            decimal menuDiscount = 10;
            if (decimal.TryParse(ConfigurationManager.AppSettings["MenuDiscountPercent"], out decimal parsedDiscount))
            {
                menuDiscount = parsedDiscount;
            }

            foreach (var d in activeDishes)
            {
                var allergens = string.Join(", ", d.DishAllergens.Select(da => da.Allergen.Name));
                
                var pendingQty = pendingQuantities.ContainsKey(d.DishId) ? pendingQuantities[d.DishId] : 0;
                var availableQty = d.TotalQuantity - pendingQty;

                displayItems.Add(new MenuItemDisplay
                {
                    Id = d.DishId,
                    Type = "Dish",
                    Name = d.Name,
                    CategoryName = d.Category.Name,
                    Description = d.PortionQuantity,
                    Price = d.Price,
                    Allergens = allergens,
                    IsAvailable = availableQty > 0,
                    Images = GetImagesForItem("Dish", d.Name, d.Category.Name)
                });
            }

            foreach (var m in activeMenus)
            {
                var allergensList = m.MenuDishes.SelectMany(md => md.Dish.DishAllergens.Select(da => da.Allergen.Name)).Distinct();
                var allergens = string.Join(", ", allergensList);
                
                var descriptionList = m.MenuDishes.Select(md => $"{md.Dish.Name} - {md.Dish.PortionQuantity}");
                var description = string.Join(", ", descriptionList);
                
                decimal rawPrice = m.MenuDishes.Sum(md => md.Dish.Price);
                decimal finalPrice = rawPrice - (rawPrice * (menuDiscount / 100));
                
                bool isAvailable = true;
                foreach (var md in m.MenuDishes)
                {
                    var pendingQty = pendingQuantities.ContainsKey(md.DishId) ? pendingQuantities[md.DishId] : 0;
                    var availableQty = md.Dish.TotalQuantity - pendingQty;
                    if (availableQty <= 0)
                    {
                        isAvailable = false;
                        break;
                    }
                }

                displayItems.Add(new MenuItemDisplay
                {
                    Id = m.MenuId,
                    Type = "Menu",
                    Name = m.Name,
                    CategoryName = m.Category.Name,
                    Description = description,
                    Price = finalPrice,
                    Allergens = allergens,
                    IsAvailable = isAvailable,
                    Images = GetImagesForItem("Menu", m.Name, m.Category.Name)
                });
            }

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var searchLower = SearchText.ToLower().Trim();
                
                if (searchLower.StartsWith("nu contin "))
                {
                    var allergen = searchLower.Substring("nu contin ".Length).Trim();
                    displayItems = displayItems.Where(i => !i.Allergens.ToLower().Contains(allergen)).ToList();
                }
                else if (searchLower.StartsWith("contin "))
                {
                    var allergen = searchLower.Substring("contin ".Length).Trim();
                    displayItems = displayItems.Where(i => i.Allergens.ToLower().Contains(allergen) || i.Name.ToLower().Contains(allergen)).ToList();
                }
                else
                {
                    if (SearchType == "Allergen")
                    {
                        if (SearchMode == "Contains")
                        {
                            displayItems = displayItems.Where(i => i.Allergens.ToLower().Contains(searchLower)).ToList();
                        }
                        else
                        {
                            displayItems = displayItems.Where(i => !i.Allergens.ToLower().Contains(searchLower)).ToList();
                        }
                    }
                    else
                    {
                        if (SearchMode == "Contains")
                        {
                            displayItems = displayItems.Where(i => i.Name.ToLower().Contains(searchLower) || i.CategoryName.ToLower().Contains(searchLower)).ToList();
                        }
                        else
                        {
                            displayItems = displayItems.Where(i => !i.Name.ToLower().Contains(searchLower) && !i.CategoryName.ToLower().Contains(searchLower)).ToList();
                        }
                    }
                }
            }

            Items = new ObservableCollection<MenuItemDisplay>(displayItems.OrderBy(i => i.CategoryName).ThenBy(i => i.Name));

            var view = CollectionViewSource.GetDefaultView(Items);
            if (view != null)
            {
                view.GroupDescriptions.Clear();
                view.GroupDescriptions.Add(new PropertyGroupDescription("CategoryName"));
            }
        }

        private bool CanAddToCart(object? parameter)
        {
            var item = parameter as MenuItemDisplay ?? SelectedMenuItem;
            return _mainViewModel.CurrentClientUserId != null && item != null && item.IsAvailable;
        }

        private void AddToCart(object? parameter)
        {
            var item = parameter as MenuItemDisplay ?? SelectedMenuItem;
            if (item != null && _mainViewModel.CurrentClientUserId.HasValue)
            {
                if (!item.IsAvailable)
                {
                    System.Windows.MessageBox.Show("Acest produs este indisponibil momentan.");
                    return;
                }
                
                _mainViewModel.Cart.AddItem(item.Id, item.Type, item.Name, item.Price);
                System.Windows.MessageBox.Show("Produs adaugat in cos!");
            }
            else
            {
                System.Windows.MessageBox.Show("Doar clientii autentificati pot face comenzi!");
            }
        }
    }
}
