using System.Windows.Input;
using System.Linq;
using RestaurantApp.Data;

namespace RestaurantApp.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private MainViewModel _mainViewModel;

        private string _email = string.Empty;
        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        private string _password = string.Empty;
        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }
        public ICommand GoToRegisterCommand { get; }

        public LoginViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            LoginCommand = new RelayCommand(o => Login());
            GoToRegisterCommand = new RelayCommand(o => _mainViewModel.CurrentViewModel = new RegisterViewModel(_mainViewModel));
        }

        private void Login()
        {
            using var context = new RestaurantDbContext();
            
            var dbUser = context.Users.FirstOrDefault(u => u.Email == Email && u.Password == Password);
            
            if (dbUser != null)
            {
                if (dbUser.Role == "Employee")
                {
                    _mainViewModel.CurrentClientUserId = null;
                    _mainViewModel.CurrentViewModel = new EmployeeViewModel();
                }
                else
                {
                    _mainViewModel.CurrentClientUserId = dbUser.UserId;
                    _mainViewModel.CurrentViewModel = new ClientViewModel(dbUser.UserId); 
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Email sau parola incorecta!");
            }
        }
    }
}
