using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RestaurantApp.Models;
using RestaurantApp.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Configuration;

namespace RestaurantApp.ViewModels
{
    public class ClientViewModel : ViewModelBase
    {
        private int _clientId;

        private ObservableCollection<Order> _myOrders = new();
        public ObservableCollection<Order> MyOrders
        {
            get => _myOrders;
            set { _myOrders = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Order> _myActiveOrders = new();
        public ObservableCollection<Order> MyActiveOrders
        {
            get => _myActiveOrders;
            set { _myActiveOrders = value; OnPropertyChanged(); }
        }

        private Order? _selectedOrder;
        public Order? SelectedOrder
        {
            get => _selectedOrder;
            set
            {
                _selectedOrder = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasSelectedOrder));
                LoadSelectedOrderDetails();
            }
        }

        public bool HasSelectedOrder => SelectedOrder != null;

        private ObservableCollection<OrderItemDisplay> _selectedOrderItems = new();
        public ObservableCollection<OrderItemDisplay> SelectedOrderItems
        {
            get => _selectedOrderItems;
            set { _selectedOrderItems = value; OnPropertyChanged(); }
        }

        private decimal _selectedSubtotal;
        public decimal SelectedSubtotal
        {
            get => _selectedSubtotal;
            set { _selectedSubtotal = value; OnPropertyChanged(); }
        }

        private decimal _selectedTransportFee;
        public decimal SelectedTransportFee
        {
            get => _selectedTransportFee;
            set { _selectedTransportFee = value; OnPropertyChanged(); }
        }

        private decimal _selectedDiscount;
        public decimal SelectedDiscount
        {
            get => _selectedDiscount;
            set { _selectedDiscount = value; OnPropertyChanged(); }
        }

        private decimal _selectedFinalTotal;
        public decimal SelectedFinalTotal
        {
            get => _selectedFinalTotal;
            set { _selectedFinalTotal = value; OnPropertyChanged(); }
        }

        public ICommand CancelOrderCommand { get; }

        public ClientViewModel(int clientId)
        {
            _clientId = clientId;
            CancelOrderCommand = new RelayCommand(CancelOrder);
            LoadOrders();
        }

        private void LoadOrders()
        {
            using var context = new RestaurantDbContext();
         
            var orders = context.Orders.FromSqlRaw("EXEC SelectOrdersByClient @UserId = {0}", _clientId).ToList();
            
            orders = orders.OrderByDescending(o => o.OrderDate).ToList();

            MyOrders = new ObservableCollection<Order>(orders);

            var active = orders.Where(o => o.Status != "livrata" && o.Status != "anulata").ToList();
            MyActiveOrders = new ObservableCollection<Order>(active);
        }

        private void LoadSelectedOrderDetails()
        {
            if (SelectedOrder == null)
            {
                SelectedOrderItems.Clear();
                SelectedSubtotal = 0;
                SelectedTransportFee = 0;
                SelectedDiscount = 0;
                SelectedFinalTotal = 0;
                return;
            }

            using var context = new RestaurantDbContext();
            var items = context.OrderItems.Where(oi => oi.OrderId == SelectedOrder.OrderId).ToList();

            var displayItems = new System.Collections.Generic.List<OrderItemDisplay>();
            decimal subtotal = 0;

            foreach (var item in items)
            {
                string name = "Necunoscut";
                if (item.ItemType == "Dish")
                {
                    var d = context.Dishes.Find(item.ItemId);
                    if (d != null) name = d.Name;
                }
                else
                {
                    var m = context.Menus.Find(item.ItemId);
                    if (m != null) name = m.Name + " (Meniu)";
                }

                displayItems.Add(new OrderItemDisplay
                {
                    ItemName = name,
                    Quantity = item.Quantity,
                    PricePerUnit = item.PricePerUnit
                });

                subtotal += item.Quantity * item.PricePerUnit;
            }

            SelectedOrderItems = new ObservableCollection<OrderItemDisplay>(displayItems);
            SelectedSubtotal = subtotal;

            decimal threshold = decimal.Parse(ConfigurationManager.AppSettings["DeliveryThreshold"] ?? "100");
            decimal deliveryCost = decimal.Parse(ConfigurationManager.AppSettings["DeliveryCost"] ?? "15");
            
            SelectedTransportFee = subtotal > 0 && subtotal < threshold ? deliveryCost : 0;
            
            decimal diff = SelectedSubtotal + SelectedTransportFee - SelectedOrder.TotalPrice;
            SelectedDiscount = diff > 0 ? diff : 0;
            SelectedFinalTotal = SelectedOrder.TotalPrice;
        }

        private void CancelOrder(object? parameter)
        {
            var order = parameter as Order ?? SelectedOrder;
            if (order != null)
            {
                if (order.Status == "inregistrata" || order.Status == "se pregateste")
                {
                    var result = System.Windows.MessageBox.Show($"Sigur doriți să anulați comanda #{order.OrderId}?", "Confirmare Anulare", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Question);
                    if (result != System.Windows.MessageBoxResult.Yes) return;

                    using var context = new RestaurantDbContext();
                    context.Database.ExecuteSqlRaw("EXEC UpdateOrderStatus @OrderId = {0}, @Status = {1}", order.OrderId, "anulata");
                    
                    int selectedId = order.OrderId;
                    LoadOrders();
                    
                    SelectedOrder = MyOrders.FirstOrDefault(o => o.OrderId == selectedId) ?? MyActiveOrders.FirstOrDefault(o => o.OrderId == selectedId);
                }
                else
                {
                    System.Windows.MessageBox.Show("Nu mai puteti anula aceasta comanda.");
                }
            }
        }
    }
}
