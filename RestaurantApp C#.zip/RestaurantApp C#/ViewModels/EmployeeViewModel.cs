using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RestaurantApp.Models;
using RestaurantApp.Data;
using Microsoft.EntityFrameworkCore;
using System.Configuration;
using System.Windows;

namespace RestaurantApp.ViewModels
{
    public class OrderItemDisplay
    {
        public string ItemName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal PricePerUnit { get; set; }
        public decimal Total => Quantity * PricePerUnit;
    }

    public class EmployeeViewModel : ViewModelBase
    {
        private ObservableCollection<Order> _orders = new();
        public ObservableCollection<Order> Orders
        {
            get => _orders;
            set { _orders = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Order> _activeOrders = new();
        public ObservableCollection<Order> ActiveOrders
        {
            get => _activeOrders;
            set { _activeOrders = value; OnPropertyChanged(); }
        }

        private Order? _selectedOrder;
        public Order? SelectedOrder
        {
            get => _selectedOrder;
            set 
            { 
                _selectedOrder = value; 
                OnPropertyChanged(); 
                OnPropertyChanged(nameof(HasSelectedOrder));
                LoadSelectedOrderItems();
            }
        }

        public bool HasSelectedOrder => SelectedOrder != null;

        private ObservableCollection<OrderItemDisplay> _selectedOrderItems = new();
        public ObservableCollection<OrderItemDisplay> SelectedOrderItems
        {
            get => _selectedOrderItems;
            set { _selectedOrderItems = value; OnPropertyChanged(); }
        }

        private decimal _selectedSubtotal;
        public decimal SelectedSubtotal
        {
            get => _selectedSubtotal;
            set { _selectedSubtotal = value; OnPropertyChanged(); }
        }

        private decimal _selectedTransportFee;
        public decimal SelectedTransportFee
        {
            get => _selectedTransportFee;
            set { _selectedTransportFee = value; OnPropertyChanged(); }
        }

        private decimal _selectedDiscount;
        public decimal SelectedDiscount
        {
            get => _selectedDiscount;
            set { _selectedDiscount = value; OnPropertyChanged(); }
        }

        private decimal _selectedFinalTotal;
        public decimal SelectedFinalTotal
        {
            get => _selectedFinalTotal;
            set { _selectedFinalTotal = value; OnPropertyChanged(); }
        }

        private void LoadSelectedOrderItems()
        {
            if (SelectedOrder == null)
            {
                SelectedOrderItems.Clear();
                SelectedSubtotal = 0;
                SelectedTransportFee = 0;
                SelectedDiscount = 0;
                SelectedFinalTotal = 0;
                return;
            }
            using var context = new RestaurantDbContext();
            
         
            if (SelectedOrder.User == null)
            {
                SelectedOrder.User = context.Users.Find(SelectedOrder.UserId) ?? new User { FirstName = "Client", LastName = "Anonim", Email = "anonim@test.com" };
            }
            var items = context.OrderItems.Where(oi => oi.OrderId == SelectedOrder.OrderId).ToList();
            
            var displayItems = new System.Collections.Generic.List<OrderItemDisplay>();
            decimal subtotal = 0;
            foreach(var item in items)
            {
                string name = "Unknown";
                if (item.ItemType == "Dish")
                {
                    var d = context.Dishes.Find(item.ItemId);
                    if (d != null) name = d.Name;
                }
                else
                {
                    var m = context.Menus.Find(item.ItemId);
                    if (m != null) name = m.Name + " (Meniu)";
                }

                displayItems.Add(new OrderItemDisplay
                {
                    ItemName = name,
                    Quantity = item.Quantity,
                    PricePerUnit = item.PricePerUnit
                });

                subtotal += item.Quantity * item.PricePerUnit;
            }
            
            SelectedOrderItems = new ObservableCollection<OrderItemDisplay>(displayItems);
            SelectedSubtotal = subtotal;

            decimal threshold = decimal.Parse(ConfigurationManager.AppSettings["DeliveryThreshold"] ?? "100");
            decimal deliveryCost = decimal.Parse(ConfigurationManager.AppSettings["DeliveryCost"] ?? "15");
            SelectedTransportFee = subtotal > 0 && subtotal < threshold ? deliveryCost : 0;
            
            decimal diff = SelectedSubtotal + SelectedTransportFee - SelectedOrder.TotalPrice;
            SelectedDiscount = diff > 0 ? diff : 0;
            SelectedFinalTotal = SelectedOrder.TotalPrice;
        }

        private ObservableCollection<Dish> _lowStockDishes = new();
        public ObservableCollection<Dish> LowStockDishes
        {
            get => _lowStockDishes;
            set { _lowStockDishes = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Category> _categories = new();
        public ObservableCollection<Category> Categories
        {
            get => _categories;
            set { _categories = value; OnPropertyChanged(); }
        }

        private string _newCategoryName = string.Empty;
        public string NewCategoryName
        {
            get => _newCategoryName;
            set { _newCategoryName = value; OnPropertyChanged(); }
        }

        private Category? _selectedCategory;
        public Category? SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Allergen> _allergens = new();
        public ObservableCollection<Allergen> Allergens
        {
            get => _allergens;
            set { _allergens = value; OnPropertyChanged(); }
        }

        private string _newAllergenName = string.Empty;
        public string NewAllergenName
        {
            get => _newAllergenName;
            set { _newAllergenName = value; OnPropertyChanged(); }
        }

        private Allergen? _selectedAllergen;
        public Allergen? SelectedAllergen
        {
            get => _selectedAllergen;
            set { _selectedAllergen = value; OnPropertyChanged(); }
        }

        public ICommand LoadDataCommand { get; }
        public ICommand AddCategoryCommand { get; }
        public ICommand UpdateCategoryCommand { get; }
        public ICommand DeleteCategoryCommand { get; }
        
        public ICommand AddAllergenCommand { get; }
        public ICommand UpdateAllergenCommand { get; }
        public ICommand DeleteAllergenCommand { get; }

        public ICommand ChangeOrderStatusCommand { get; }
        public ICommand DeleteOrderCommand { get; }

        public EmployeeViewModel()
        {
            LoadDataCommand = new RelayCommand(o => LoadData());
            AddCategoryCommand = new RelayCommand(o => AddCategory(), o => !string.IsNullOrWhiteSpace(NewCategoryName));
            UpdateCategoryCommand = new RelayCommand(o => UpdateCategory(), o => SelectedCategory != null);
            DeleteCategoryCommand = new RelayCommand(o => DeleteCategory(), o => SelectedCategory != null);
            
            AddAllergenCommand = new RelayCommand(o => AddAllergen(), o => !string.IsNullOrWhiteSpace(NewAllergenName));
            UpdateAllergenCommand = new RelayCommand(o => UpdateAllergen(), o => SelectedAllergen != null);
            DeleteAllergenCommand = new RelayCommand(o => DeleteAllergen(), o => SelectedAllergen != null);

            ChangeOrderStatusCommand = new RelayCommand(ChangeOrderStatus);
            DeleteOrderCommand = new RelayCommand(DeleteOrder, CanDeleteOrder);
            LoadData();
        }

        private void LoadData()
        {
            using var context = new RestaurantDbContext();
         
            var allOrders = context.Orders.Include(o => o.User).OrderByDescending(o => o.OrderDate).ToList();
            Orders = new ObservableCollection<Order>(allOrders);

            var active = allOrders.Where(o => o.Status != "livrata" && o.Status != "anulata").ToList();
            ActiveOrders = new ObservableCollection<Order>(active);

            decimal threshold = 10;
            if (decimal.TryParse(ConfigurationManager.AppSettings["LowStockThreshold"], out decimal parsed))
            {
                threshold = parsed;
            }

            var dishes = context.Dishes.FromSqlRaw("EXEC SelectLowStockDishes @Threshold = {0}", threshold).ToList();
            LowStockDishes = new ObservableCollection<Dish>(dishes);

            Categories = new ObservableCollection<Category>(context.Categories.FromSqlRaw("EXEC SelectAllCategories").ToList());

            Allergens = new ObservableCollection<Allergen>(context.Allergens.ToList());
        }

        private void AddCategory()
        {
            using var context = new RestaurantDbContext();
            context.Database.ExecuteSqlRaw("EXEC InsertCategory @Name = {0}", NewCategoryName);
            NewCategoryName = string.Empty;
            LoadData();
        }

        private void UpdateCategory()
        {
            if (SelectedCategory == null) return;
            using var context = new RestaurantDbContext();
            context.Database.ExecuteSqlRaw("EXEC UpdateCategory @CategoryId = {0}, @Name = {1}", SelectedCategory.CategoryId, SelectedCategory.Name);
            LoadData();
        }

        private void DeleteCategory()
        {
            if (SelectedCategory == null) return;
            using var context = new RestaurantDbContext();
            var cat = context.Categories.Find(SelectedCategory.CategoryId);
            if (cat != null)
            {
                context.Categories.Remove(cat);
                context.SaveChanges();
                LoadData();
            }
        }

        private void AddAllergen()
        {
            using var context = new RestaurantDbContext();
            context.Allergens.Add(new Allergen { Name = NewAllergenName });
            context.SaveChanges();
            NewAllergenName = string.Empty;
            LoadData();
        }

        private void UpdateAllergen()
        {
            if (SelectedAllergen == null) return;
            using var context = new RestaurantDbContext();
            context.Allergens.Update(SelectedAllergen);
            context.SaveChanges();
            LoadData();
        }

        private void DeleteAllergen()
        {
            if (SelectedAllergen == null) return;
            using var context = new RestaurantDbContext();
            var alg = context.Allergens.Find(SelectedAllergen.AllergenId);
            if (alg != null)
            {
                context.Allergens.Remove(alg);
                context.SaveChanges();
                LoadData();
            }
        }

        private void ChangeOrderStatus(object? parameter)
        {
            var order = parameter as Order ?? SelectedOrder;
            if (order == null) return;

            if (order.Status == "livrata" || order.Status == "anulata")
            {
                MessageBox.Show("Comenzile finalizate (livrate sau anulate) nu mai pot fi modificate!", "Eroare", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int selectedId = order.OrderId;
            string nextStatus = order.Status switch
            {
                "inregistrata" => "se pregateste",
                "se pregateste" => "a plecat la client",
                "a plecat la client" => "livrata",
                _ => order.Status
            };

            if (nextStatus == order.Status) return;

            using var context = new RestaurantDbContext();
            context.Database.ExecuteSqlRaw("EXEC UpdateOrderStatus @OrderId = {0}, @Status = {1}", order.OrderId, nextStatus);
            
            if (nextStatus == "livrata")
            {
                var items = context.OrderItems.Where(oi => oi.OrderId == order.OrderId).ToList();
                foreach (var item in items)
                {
                    if (item.ItemType == "Dish")
                    {
                        var dish = context.Dishes.Find(item.ItemId);
                        if (dish != null)
                        {
                            dish.TotalQuantity -= item.Quantity;
                            if (dish.TotalQuantity < 0) dish.TotalQuantity = 0;
                        }
                    }
                    else if (item.ItemType == "Menu")
                    {
                        var menuDishes = context.MenuDishes.Where(md => md.MenuId == item.ItemId).Include(md => md.Dish).ToList();
                        foreach (var md in menuDishes)
                        {
                            md.Dish.TotalQuantity -= item.Quantity;
                            if (md.Dish.TotalQuantity < 0) md.Dish.TotalQuantity = 0;
                        }
                    }
                }
                context.SaveChanges();
            }

            LoadData();
            SelectedOrder = Orders.FirstOrDefault(o => o.OrderId == selectedId) ?? ActiveOrders.FirstOrDefault(o => o.OrderId == selectedId);
        }

        private bool CanDeleteOrder(object? parameter)
        {
            var order = parameter as Order ?? SelectedOrder;
            return order != null && order.Status == "livrata";
        }

        private void DeleteOrder(object? parameter)
        {
            var order = parameter as Order ?? SelectedOrder;
            if (order == null || order.Status != "livrata") return;

            var result = MessageBox.Show($"Sigur doriți să ștergeți comanda #{order.OrderId}?", "Confirmare Ștergere", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result != MessageBoxResult.Yes) return;

            using var context = new RestaurantDbContext();
            
            var items = context.OrderItems.Where(oi => oi.OrderId == order.OrderId).ToList();
            context.OrderItems.RemoveRange(items);
            
            var dbOrder = context.Orders.Find(order.OrderId);
            if (dbOrder != null)
            {
                context.Orders.Remove(dbOrder);
                context.SaveChanges();
            }

            SelectedOrder = null;
            LoadData();
        }
    }
}
