using System;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Windows.Input;
using RestaurantApp.Models;
using RestaurantApp.Data;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace RestaurantApp.ViewModels
{
    public class CartItem : ViewModelBase
    {
        public int ItemId { get; set; }
        public string ItemType { get; set; } = string.Empty; 
        public string Name { get; set; } = string.Empty;
        public decimal PricePerUnit { get; set; }

        private int _quantity = 1;
        public int Quantity
        {
            get => _quantity;
            set 
            { 
                _quantity = value; 
                OnPropertyChanged();
                OnPropertyChanged(nameof(TotalPrice));
            }
        }

        public decimal TotalPrice => PricePerUnit * Quantity;
    }

    public class CartViewModel : ViewModelBase
    {
        private readonly MainViewModel _mainViewModel;

        public ObservableCollection<CartItem> Items { get; } = new ObservableCollection<CartItem>();

        public decimal Subtotal => Items.Sum(i => i.TotalPrice);
        
        public decimal TransportFee 
        {
            get 
            {
                if (Subtotal == 0) return 0;
                
                decimal a = decimal.Parse(ConfigurationManager.AppSettings["DeliveryThreshold"] ?? "100");
                decimal b = decimal.Parse(ConfigurationManager.AppSettings["DeliveryCost"] ?? "15");
                return Subtotal < a ? b : 0;
            }
        }

        public decimal Discount
        {
            get
            {
                if (Subtotal == 0 || !_mainViewModel.CurrentClientUserId.HasValue) return 0;
                
                decimal y = decimal.Parse(ConfigurationManager.AppSettings["DiscountSumThreshold"] ?? "200");
                decimal w = decimal.Parse(ConfigurationManager.AppSettings["DiscountPercent"] ?? "15");
                
                bool applyDiscount = Subtotal > y;

                if (!applyDiscount)
                {
                    int z = int.Parse(ConfigurationManager.AppSettings["DiscountOrdersCountThreshold"] ?? "5");
                    int t = int.Parse(ConfigurationManager.AppSettings["DiscountOrdersIntervalDays"] ?? "30");
                    
                    using var context = new RestaurantDbContext();
                    var recentOrdersCount = context.Orders.Count(o => o.UserId == _mainViewModel.CurrentClientUserId.Value && o.OrderDate >= DateTime.Now.AddDays(-t));
                    if (recentOrdersCount > z)
                    {
                        applyDiscount = true;
                    }
                }

                if (applyDiscount)
                {
                    return Subtotal * (w / 100);
                }
                
                return 0;
            }
        }

        public decimal FinalTotal => Subtotal + TransportFee - Discount;

        public ICommand PlaceOrderCommand { get; }
        public ICommand RemoveItemCommand { get; }
        public ICommand GoBackCommand { get; }

        public CartViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            
            Items.CollectionChanged += (s, e) => NotifyTotals();

            PlaceOrderCommand = new RelayCommand(PlaceOrder, o => Items.Any());
            RemoveItemCommand = new RelayCommand(RemoveItem);
            GoBackCommand = new RelayCommand(o => _mainViewModel.CurrentViewModel = new MenuViewModel(_mainViewModel));
        }

        public void AddItem(int id, string type, string name, decimal price)
        {
            var existing = Items.FirstOrDefault(i => i.ItemId == id && i.ItemType == type);
            if (existing != null)
            {
                existing.Quantity++;
            }
            else
            {
                var item = new CartItem { ItemId = id, ItemType = type, Name = name, PricePerUnit = price };
                item.PropertyChanged += (s, e) => NotifyTotals();
                Items.Add(item);
            }
            NotifyTotals();
        }

        private void RemoveItem(object? parameter)
        {
            if (parameter is CartItem item)
            {
                Items.Remove(item);
            }
        }

        private void NotifyTotals()
        {
            OnPropertyChanged(nameof(Subtotal));
            OnPropertyChanged(nameof(TransportFee));
            OnPropertyChanged(nameof(Discount));
            OnPropertyChanged(nameof(FinalTotal));
        }

        private void PlaceOrder(object? parameter)
        {
            if (!_mainViewModel.CurrentClientUserId.HasValue)
            {
                MessageBox.Show("Trebuie sa fii logat pentru a comanda.");
                return;
            }

            using var context = new RestaurantDbContext();

            var pendingOrders = context.Orders
                .Include(o => o.OrderItems)
                .Where(o => o.Status == "inregistrata" || o.Status == "se pregateste" || o.Status == "a plecat la client")
                .ToList();

            var pendingQuantities = new System.Collections.Generic.Dictionary<int, decimal>();
            foreach (var order in pendingOrders)
            {
                foreach (var orderItem in order.OrderItems)
                {
                    if (orderItem.ItemType == "Dish")
                    {
                        if (!pendingQuantities.ContainsKey(orderItem.ItemId))
                            pendingQuantities[orderItem.ItemId] = 0;
                        pendingQuantities[orderItem.ItemId] += orderItem.Quantity;
                    }
                    else if (orderItem.ItemType == "Menu")
                    {
                        var menuDishes = context.MenuDishes.Where(md => md.MenuId == orderItem.ItemId).ToList();
                        foreach (var md in menuDishes)
                        {
                            if (!pendingQuantities.ContainsKey(md.DishId))
                                pendingQuantities[md.DishId] = 0;
                            pendingQuantities[md.DishId] += orderItem.Quantity;
                        }
                    }
                }
            }

            foreach (var item in Items)
            {
                if (item.ItemType == "Dish")
                {
                    var dish = context.Dishes.Find(item.ItemId);
                    if (dish == null)
                    {
                        MessageBox.Show($"Produsul '{item.Name}' nu mai există în baza de date.");
                        return;
                    }
                    var pendingQty = pendingQuantities.ContainsKey(dish.DishId) ? pendingQuantities[dish.DishId] : 0;
                    var availableQty = dish.TotalQuantity - pendingQty;
                    if (availableQty < item.Quantity)
                    {
                        MessageBox.Show($"Stoc insuficient pentru '{item.Name}'. Stoc disponibil: {availableQty:0}.");
                        return;
                    }
                }
                else if (item.ItemType == "Menu")
                {
                    var menu = context.Menus.Include(m => m.MenuDishes).ThenInclude(md => md.Dish).FirstOrDefault(m => m.MenuId == item.ItemId);
                    if (menu == null)
                    {
                        MessageBox.Show($"Meniul '{item.Name}' nu mai există în baza de date.");
                        return;
                    }
                    foreach (var md in menu.MenuDishes)
                    {
                        var pendingQty = pendingQuantities.ContainsKey(md.DishId) ? pendingQuantities[md.DishId] : 0;
                        var availableQty = md.Dish.TotalQuantity - pendingQty;
                        if (availableQty < item.Quantity)
                        {
                            MessageBox.Show($"Stoc insuficient pentru ingredientul '{md.Dish.Name}' din meniul '{item.Name}'. Stoc disponibil: {availableQty:0}.");
                            return;
                        }
                    }
                }
            }

            var orderObj = new Order 
            { 
                UserId = _mainViewModel.CurrentClientUserId.Value,
                OrderDate = DateTime.Now,
                Status = "inregistrata",
                TotalPrice = FinalTotal,
                EstimatedDelivery = DateTime.Now.AddMinutes(45)
            };

            context.Orders.Add(orderObj);
            context.SaveChanges(); 

            foreach (var item in Items)
            {
                context.OrderItems.Add(new OrderItem
                {
                    OrderId = orderObj.OrderId,
                    ItemId = item.ItemId,
                    ItemType = item.ItemType,
                    Quantity = item.Quantity,
                    PricePerUnit = item.PricePerUnit
                });
            }
            context.SaveChanges();

            Items.Clear();
            MessageBox.Show("Comanda a fost plasata cu succes!");
            _mainViewModel.CurrentViewModel = new ClientViewModel(_mainViewModel.CurrentClientUserId.Value);
        }
    }
}
