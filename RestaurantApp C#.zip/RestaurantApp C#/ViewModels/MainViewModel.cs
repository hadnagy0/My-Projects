using System.Windows.Input;

namespace RestaurantApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private ViewModelBase _currentViewModel = null!;
        public ViewModelBase CurrentViewModel
        {
            get => _currentViewModel;
            set
            {
                _currentViewModel = value;
                OnPropertyChanged();
            }
        }

        public ICommand ShowMenuCommand { get; }
        public ICommand ShowLoginCommand { get; }
        public ICommand ShowEmployeeCommand { get; }
        public ICommand ShowRegisterCommand { get; }
        public ICommand ShowCartCommand { get; }

        public int? CurrentClientUserId { get; set; } = null;
        public CartViewModel Cart { get; }

        public MainViewModel()
        {
            Cart = new CartViewModel(this);
            ShowMenuCommand = new RelayCommand(o => CurrentViewModel = new MenuViewModel(this));
            ShowLoginCommand = new RelayCommand(o => CurrentViewModel = new LoginViewModel(this));
            ShowEmployeeCommand = new RelayCommand(o => CurrentViewModel = new EmployeeViewModel());
            ShowRegisterCommand = new RelayCommand(o => CurrentViewModel = new RegisterViewModel(this));
            ShowCartCommand = new RelayCommand(o => CurrentViewModel = Cart);

            CurrentViewModel = new MenuViewModel(this);
        }
    }
}
