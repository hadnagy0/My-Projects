using System.Windows.Controls;

namespace RestaurantApp.Views
{
    public partial class ClientView : UserControl
    {
        public ClientView()
        {
            InitializeComponent();
        }
    }
}
