using System.Windows.Controls;

namespace RestaurantApp.Views
{
    public partial class CartView : UserControl
    {
        public CartView()
        {
            InitializeComponent();
        }
    }
}
