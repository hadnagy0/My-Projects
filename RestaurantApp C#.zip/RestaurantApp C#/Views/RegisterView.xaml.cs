using System.Windows.Controls;

namespace RestaurantApp.Views
{
    public partial class RegisterView : UserControl
    {
        public RegisterView()
        {
            InitializeComponent();
        }
    }
}
