using System.Windows.Controls;

namespace RestaurantApp.Views
{
    public partial class EmployeeView : UserControl
    {
        public EmployeeView()
        {
            InitializeComponent();
        }
    }
}
