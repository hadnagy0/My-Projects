using System.Windows.Controls;

namespace RestaurantApp.Views
{
    public partial class MenuView : UserControl
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}
