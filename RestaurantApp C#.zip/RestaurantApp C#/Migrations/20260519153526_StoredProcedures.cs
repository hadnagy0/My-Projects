using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RestaurantApp.Migrations
{
    
    public partial class StoredProcedures : Migration
    {
        
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
CREATE PROCEDURE InsertCategory
    @Name VARCHAR(255)
AS
BEGIN
    INSERT INTO Categories (Name) VALUES (@Name);
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE InsertDish
    @Name VARCHAR(255),
    @Price DECIMAL(18,2),
    @PortionQuantity VARCHAR(255),
    @TotalQuantity DECIMAL(18,2),
    @CategoryId INT
AS
BEGIN
    INSERT INTO Dishes (Name, Price, PortionQuantity, TotalQuantity, CategoryId, IsActive) 
    VALUES (@Name, @Price, @PortionQuantity, @TotalQuantity, @CategoryId, 1);
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE UpdateCategory
    @CategoryId INT,
    @Name VARCHAR(255)
AS
BEGIN
    UPDATE Categories SET Name = @Name WHERE CategoryId = @CategoryId;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE UpdateDishQuantity
    @DishId INT,
    @Quantity DECIMAL(18,2)
AS
BEGIN
    UPDATE Dishes SET TotalQuantity = @Quantity WHERE DishId = @DishId;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE SelectAllCategories
AS
BEGIN
    SELECT * FROM Categories;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE SelectActiveDishes
AS
BEGIN
    SELECT * FROM Dishes WHERE IsActive = 1;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE SelectLowStockDishes
    @Threshold DECIMAL(18,2)
AS
BEGIN
    SELECT * FROM Dishes WHERE TotalQuantity <= @Threshold AND IsActive = 1;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE SelectOrdersByClient
    @UserId INT
AS
BEGIN
    SELECT * FROM Orders WHERE UserId = @UserId;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE UpdateOrderStatus
    @OrderId INT,
    @Status VARCHAR(255)
AS
BEGIN
    UPDATE Orders SET Status = @Status WHERE OrderId = @OrderId;
END;");

            migrationBuilder.Sql(@"
CREATE PROCEDURE InsertOrder
    @UserId INT,
    @OrderDate DATETIME,
    @Status VARCHAR(255),
    @TotalPrice DECIMAL(18,2),
    @EstimatedDelivery DATETIME
AS
BEGIN
    INSERT INTO Orders (UserId, OrderDate, Status, TotalPrice, EstimatedDelivery)
    VALUES (@UserId, @OrderDate, @Status, @TotalPrice, @EstimatedDelivery);
    SELECT SCOPE_IDENTITY() AS OrderId;
END;");
        }

        
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS InsertCategory;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS InsertDish;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS UpdateCategory;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS UpdateDishQuantity;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS SelectAllCategories;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS SelectActiveDishes;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS SelectLowStockDishes;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS SelectOrdersByClient;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS UpdateOrderStatus;");
            migrationBuilder.Sql("DROP PROCEDURE IF EXISTS InsertOrder;");
        }
    }
}
