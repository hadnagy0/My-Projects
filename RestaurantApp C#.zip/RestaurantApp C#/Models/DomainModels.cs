using System;
using System.Collections.Generic;

namespace RestaurantApp.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty; 
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty; 

        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }

    public class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; } = string.Empty;

        public ICollection<Dish> Dishes { get; set; } = new List<Dish>();
        public ICollection<Menu> Menus { get; set; } = new List<Menu>();
    }

    public class Allergen
    {
        public int AllergenId { get; set; }
        public string Name { get; set; } = string.Empty;

        public ICollection<DishAllergen> DishAllergens { get; set; } = new List<DishAllergen>();
    }

    public class Dish
    {
        public int DishId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string PortionQuantity { get; set; } = string.Empty; 
        public decimal TotalQuantity { get; set; } 
        public int CategoryId { get; set; }
        public bool IsActive { get; set; } = true;

        public Category Category { get; set; } = null!;
        public ICollection<DishAllergen> DishAllergens { get; set; } = new List<DishAllergen>();
        public ICollection<MenuDish> MenuDishes { get; set; } = new List<MenuDish>();
    }

    public class DishAllergen
    {
        public int DishId { get; set; }
        public Dish Dish { get; set; } = null!;
        public int AllergenId { get; set; }
        public Allergen Allergen { get; set; } = null!;
    }

    public class Menu
    {
        public int MenuId { get; set; }
        public string Name { get; set; } = string.Empty;
        public int CategoryId { get; set; }
        public bool IsActive { get; set; } = true;

        public Category Category { get; set; } = null!;
        public ICollection<MenuDish> MenuDishes { get; set; } = new List<MenuDish>();
    }

    public class MenuDish
    {
        public int MenuId { get; set; }
        public Menu Menu { get; set; } = null!;
        public int DishId { get; set; }
        public Dish Dish { get; set; } = null!;
    }

    public class Order
    {
        public int OrderId { get; set; }
        public int UserId { get; set; }
        public User User { get; set; } = null!;
        public DateTime OrderDate { get; set; }
        public string Status { get; set; } = string.Empty; 
        public decimal TotalPrice { get; set; }
        public DateTime? EstimatedDelivery { get; set; }

        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }

    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public Order Order { get; set; } = null!;
        public int ItemId { get; set; } 
        public string ItemType { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal PricePerUnit { get; set; }
    }
}
