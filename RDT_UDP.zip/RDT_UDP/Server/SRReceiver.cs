using System.Net;
using System.Net.Sockets;
using RDT_UDP.Common;

namespace RDT_UDP.Server
{
    public class SRReceiver
    {
        private readonly UdpClient  _udp;
        private readonly IPEndPoint _clientEp;
        private readonly int        _windowSize;

        private int _rcvBase = 0;

        private readonly Dictionary<int, byte[]> _buffer = new();
        private readonly Dictionary<int, bool>   _received = new();

        private readonly List<byte[]> _assembled = new();
        private bool _transferComplete = false;
        private int  _lastSeq = int.MaxValue;

        public SRReceiver(UdpClient udp, IPEndPoint clientEp, int windowSize)
        {
            _udp        = udp;
            _clientEp   = clientEp;
            _windowSize = windowSize;
        }
        
        public byte[] Receive()
        {
            Logger.Info("RECEIVER", $"Waiting for DATA (window={_windowSize})...");

            while (!_transferComplete)
            {
                try
                {
                    IPEndPoint? ep   = null;
                    byte[]      raw  = _udp.Receive(ref ep);

                    if (ep == null || !ep.Equals(_clientEp))
                    {
                        Logger.Info("RECEIVER", $"Received packet from foreign endpoint {ep}, expected {_clientEp}. Ignoring.");
                        continue;
                    }
                    
                    if (NetworkSimulator.ShouldDrop())
                    {
                        var tmp = Packet.Deserialize(raw);
                        Logger.Drop("RECEIVER", $"[SIMULATED LOSS] DATA seq={tmp.SequenceNumber} dropped at receiver");
                        continue; 
                    }

                    var pkt = Packet.Deserialize(raw);
                    if (pkt.Type != PacketType.DATA) continue;

                    int seq = pkt.SequenceNumber;
                    Logger.Recv("RECEIVER", $"Received DATA seq={seq}{(pkt.IsLastPacket ? " [LAST]" : "")}");

                    if (pkt.IsLastPacket) _lastSeq = seq;
                    
                    if (seq >= _rcvBase && seq < _rcvBase + _windowSize)
                    {
                        if (!_received.GetValueOrDefault(seq))
                        {
                            _buffer[seq]   = pkt.Data ?? Array.Empty<byte>();
                            _received[seq] = true;
                        }
                        SendAck(seq);

                        DeliverInOrder();
                    }
                    else if (seq >= _rcvBase - _windowSize && seq < _rcvBase)
                    {
                        Logger.Info("RECEIVER", $"Duplicate seq={seq}, re-sending ACK");
                        SendAck(seq);
                    }
                    else
                    {
                        Logger.Info("RECEIVER", $"seq={seq} outside window [{_rcvBase},{_rcvBase + _windowSize}), ignored");
                    }
                }
                catch (SocketException ex) when (ex.SocketErrorCode == SocketError.Interrupted)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Logger.Info("RECEIVER", $"Receive error: {ex.Message}");
                }
            }
            
            return _assembled.SelectMany(b => b).ToArray();
        }
        
        private void DeliverInOrder()
        {
            while (_received.GetValueOrDefault(_rcvBase))
            {
                byte[] payload = _buffer[_rcvBase];
                _assembled.Add(payload);
                Logger.Info("RECEIVER", $"Delivered seq={_rcvBase} to application layer");
                _received.Remove(_rcvBase);
                _buffer.Remove(_rcvBase);

                if (_rcvBase == _lastSeq)
                {
                    _transferComplete = true;
                    Logger.Done("RECEIVER", "Last segment delivered. Transfer complete.");
                    return;
                }
                _rcvBase++;
            }
        }

        private void SendAck(int seq)
        {
            if (NetworkSimulator.ShouldDrop())
            {
                Logger.Drop("RECEIVER", $"[SIMULATED LOSS] ACK for seq={seq} dropped");
                return;
            }

            var ack = new Packet { Type = PacketType.ACK, AckNumber = seq };
            byte[] bytes = ack.Serialize();
            _udp.Send(bytes, bytes.Length, _clientEp);
            Logger.Send("RECEIVER", $"Sent ACK seq={seq}");
        }
    }
}
