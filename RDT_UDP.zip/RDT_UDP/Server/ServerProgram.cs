using System.Net;
using System.Net.Sockets;
using System.Text;
using RDT_UDP.Common;
using RDT_UDP.Server;

namespace RDT_UDP
{
    class ServerProgram
    {
        static void Main(string[] args)
        {
            const int    SERVER_PORT  = 9000;
            const int    MAX_WINDOW   = 8;     
            const double LOSS_RATE    = 0.15;  

            NetworkSimulator.LossRate = LOSS_RATE;

            Console.Title = "RDT Server – Selective Repeat";
            Logger.Info("SERVER", "=== Reliable Data Transfer Server (Selective Repeat) ===");
            Logger.Info("SERVER", $"Listening on port {SERVER_PORT}  |  Loss rate: {LOSS_RATE * 100}%");

            var serverEp = new IPEndPoint(IPAddress.Any, SERVER_PORT);
            using var udp = new UdpClient(serverEp);

            while (true)
            {
                Logger.Info("SERVER", "Waiting for new client connection...\n");
                
                IPEndPoint? clientEp = null;
                int negotiatedWindow = PerformHandshake(udp, ref clientEp, MAX_WINDOW);

                if (negotiatedWindow <= 0 || clientEp == null)
                {
                    Logger.Info("SERVER", "Handshake failed, waiting for next client.");
                    continue;
                }

                Logger.Done("SERVER", $"Connection with {clientEp} established. Window = {negotiatedWindow}");
                
                var receiver = new SRReceiver(udp, clientEp, negotiatedWindow);
                byte[] received = receiver.Receive();
                
                string text = Encoding.UTF8.GetString(received);
                Logger.Done("SERVER", $"\n===== REASSEMBLED MESSAGE ({received.Length} bytes) =====");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(text[..Math.Min(text.Length, 500)] + (text.Length > 500 ? "\n...[truncated]" : ""));
                Console.ResetColor();
                
                string outFile = $"received_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
                File.WriteAllText(outFile, text);
                Logger.Done("SERVER", $"Full content saved to: {outFile}");
                
                WaitForFin(udp, clientEp);
            }
        }
        
        static int PerformHandshake(UdpClient udp, ref IPEndPoint? clientEp, int maxWindow)
        {
            try
            {
                byte[] synData = udp.Receive(ref clientEp);
                var    synPkt  = Packet.Deserialize(synData);

                if (synPkt.Type != PacketType.SYN)
                {
                    Logger.Info("SERVER", $"Expected SYN, got {synPkt.Type}. Ignoring.");
                    return -1;
                }

                int requested = synPkt.WindowSize;
                int agreed    = Math.Min(requested, maxWindow);   
                Logger.Recv("SERVER", $"[Handshake] Received SYN (requested window={requested})");
                Logger.Info("SERVER", $"[Handshake] Negotiated window={agreed} (server max={maxWindow})");
                
                var synAck = new Packet { Type = PacketType.SYN_ACK, WindowSize = agreed };
                byte[] synAckBytes = synAck.Serialize();
                udp.Send(synAckBytes, synAckBytes.Length, clientEp);
                Logger.Send("SERVER", $"[Handshake] Sent SYN-ACK (window={agreed})");
                
                udp.Client.ReceiveTimeout = 5000;
                Packet? ackPkt = null;
                while (true)
                {
                    IPEndPoint? fromEp = null;
                    byte[] ackData = udp.Receive(ref fromEp);

                    if (fromEp == null || !fromEp.Equals(clientEp))
                    {
                        Logger.Info("SERVER", $"[Handshake] Received packet from foreign endpoint {fromEp} while waiting for ACK from {clientEp}. Ignoring.");
                        continue;
                    }

                    ackPkt = Packet.Deserialize(ackData);
                    break;
                }
                udp.Client.ReceiveTimeout = 0;

                if (ackPkt.Type != PacketType.ACK)
                {
                    Logger.Info("SERVER", "Expected ACK in handshake, got something else.");
                    return -1;
                }

                Logger.Recv("SERVER", "[Handshake] Received ACK. Handshake complete.");
                return agreed;
            }
            catch (Exception ex)
            {
                Logger.Info("SERVER", $"Handshake error: {ex.Message}");
                return -1;
            }
        }
        
        static void WaitForFin(UdpClient udp, IPEndPoint clientEp)
        {
            try
            {
                udp.Client.ReceiveTimeout = 3000;
                while (true)
                {
                    IPEndPoint? ep   = null;
                    byte[]      data = udp.Receive(ref ep);

                    if (ep == null || !ep.Equals(clientEp))
                    {
                        Logger.Info("SERVER", $"Received packet from foreign endpoint {ep} during teardown, expected {clientEp}. Ignoring.");
                        continue;
                    }

                    var pkt = Packet.Deserialize(data);

                    if (pkt.Type == PacketType.FIN)
                    {
                        Logger.Recv("SERVER", "Received FIN");
                        var finAck = new Packet { Type = PacketType.FIN_ACK };
                        byte[] finAckBytes = finAck.Serialize();
                        udp.Send(finAckBytes, finAckBytes.Length, clientEp);
                        Logger.Send("SERVER", "Sent FIN-ACK. Connection closed.\n");
                        break;
                    }
                    else if (pkt.Type == PacketType.DATA)
                    {
                        Logger.Info("SERVER", $"Received duplicate DATA seq={pkt.SequenceNumber} during teardown. Re-sending ACK.");
                        var ack = new Packet { Type = PacketType.ACK, AckNumber = pkt.SequenceNumber };
                        byte[] ackBytes = ack.Serialize();
                        udp.Send(ackBytes, ackBytes.Length, clientEp);
                    }
                    else
                    {
                        Logger.Info("SERVER", $"Received packet of type {pkt.Type} during teardown, expected FIN. Ignoring.");
                    }
                }
                udp.Client.ReceiveTimeout = 0;
            }
            catch { /* timeout */ }
        }
    }
}
