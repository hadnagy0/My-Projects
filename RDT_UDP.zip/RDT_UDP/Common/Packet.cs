using System.Text;
using System.Text.Json;

namespace RDT_UDP.Common
{
    public enum PacketType
    {
        SYN,
        SYN_ACK,
        ACK,
        DATA,
        FIN,
        FIN_ACK
    }

    public class Packet
    {
        public PacketType Type { get; set; }
        public int SequenceNumber { get; set; }
        public int AckNumber { get; set; }
        public int WindowSize { get; set; }
        public bool IsLastPacket { get; set; }
        public byte[]? Data { get; set; }
        
        public byte[] Serialize()
        {
            var dto = new PacketDto
            {
                Type = Type.ToString(),
                SequenceNumber = SequenceNumber,
                AckNumber = AckNumber,
                WindowSize = WindowSize,
                IsLastPacket = IsLastPacket,
                Data = Data != null ? Convert.ToBase64String(Data) : null
            };
            string json = JsonSerializer.Serialize(dto);
            byte[] jsonBytes = Encoding.UTF8.GetBytes(json);
            return jsonBytes;
        }

        public static Packet Deserialize(byte[] bytes)
        {
            string json = Encoding.UTF8.GetString(bytes);
            var dto = JsonSerializer.Deserialize<PacketDto>(json)!;
            return new Packet
            {
                Type = Enum.Parse<PacketType>(dto.Type!),
                SequenceNumber = dto.SequenceNumber,
                AckNumber = dto.AckNumber,
                WindowSize = dto.WindowSize,
                IsLastPacket = dto.IsLastPacket,
                Data = dto.Data != null ? Convert.FromBase64String(dto.Data) : null
            };
        }
        
        private class PacketDto
        {
            public string? Type { get; set; }
            public int SequenceNumber { get; set; }
            public int AckNumber { get; set; }
            public int WindowSize { get; set; }
            public bool IsLastPacket { get; set; }
            public string? Data { get; set; }
        }
    }
}
