namespace RDT_UDP.Common
{
    public static class Logger
    {
        private static readonly object _lock = new object();

        public static void Info(string role, string msg)    => Print(role, msg, ConsoleColor.Cyan);
        public static void Send(string role, string msg)    => Print(role, msg, ConsoleColor.Green);
        public static void Recv(string role, string msg)    => Print(role, msg, ConsoleColor.Yellow);
        public static void Drop(string role, string msg)    => Print(role, msg, ConsoleColor.Red);
        public static void Retx(string role, string msg)    => Print(role, msg, ConsoleColor.Magenta);
        public static void Done(string role, string msg)    => Print(role, msg, ConsoleColor.White);

        private static void Print(string role, string msg, ConsoleColor color)
        {
            lock (_lock)
            {
                Console.ForegroundColor = color;
                Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] [{role}] {msg}");
                Console.ResetColor();
            }
        }
    }
}
