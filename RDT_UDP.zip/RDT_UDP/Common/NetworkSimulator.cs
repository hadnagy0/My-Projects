namespace RDT_UDP.Common
{
    public static class NetworkSimulator
    {
        private static readonly Random _rng = new Random();
        
        public static double LossRate { get; set; } = 0.15; 
        
        public static bool ShouldDrop()
        {
            return _rng.NextDouble() < LossRate;
        }
    }
}
