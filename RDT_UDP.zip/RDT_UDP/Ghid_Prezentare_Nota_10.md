# Ghid de Prezentare – Nota 10 Absolută (Bareme & Explicații)
## Rețele de Calculatoare | Semestrul II, 2025-2026
**Tema 3: Transport Fiabil UDP (Selective Repeat)**
**Student:** Universitatea Transilvania din Brașov

Acest document reprezintă o **hartă completă de corespondență** între baremul oficial al temei și codul sursă implementat în proiectul tău, completat cu explicații teoretice și diagrame pentru a te asigura că obții **nota 10.00** la ambele probe (scrisă și practică).

---

## 1. Mapare Bareme vs. Cod Sursă (Unde este implementat?)

| Cerință din Barem | Locație în Cod (Fișier & Linie) | Explicație Funcțională |
| :--- | :--- | :--- |
| **1. Header Customizat** | [`Common/Packet.cs`](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Common/Packet.cs) | Clasa `Packet` serializează datele și metadatele în format JSON (folosind un `PacketDto` intern) și le transformă în `byte[]`. Conține câmpurile obligatorii: `Type` (enum SYN, SYN-ACK, ACK, DATA, FIN, FIN-ACK), `SequenceNumber`, `WindowSize`, plus câmpuri ajutătoare ca `AckNumber`, `IsLastPacket` și `Data` (Base64). |
| **2. Three-Way Handshake** | **Client:** [`ClientProgram.cs` - L57-93](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/ClientProgram.cs#L57-L93)<br>**Server:** [`ServerProgram.cs` - L67-112](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Server/ServerProgram.cs#L67-L112) | **Negocierea ferestrei**: Clientul trimite `SYN` propunând `W = 8`. Serverul primește `SYN` și face `Math.Min(requested, maxWindow)`, întorcând `SYN-ACK` cu dimensiunea ferestrei aliniate (ex: `W = 8`). Clientul confirmă cu `ACK`, iar transferul începe folosind această dimensiune aliniată. |
| **3. Simularea Pierderilor** | [`Common/NetworkSimulator.cs`](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Common/NetworkSimulator.cs)<br>Apelat în `SRSender` (L101, L159) și `SRReceiver` (L53, L135) | Generează o probabilitate controlată (implicit `15%`) folosind `Random.NextDouble() < LossRate`. Dacă se decide pierderea unui pachet (DATA sau ACK), acesta este ignorat și nu este trimis în rețea sau nu este procesat la receptor, forțând declanșarea timerelor. |
| **4. Selective Repeat (SR)** | **Emițător:** [`Client/SRSender.cs`](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs)<br>**Receptor:** [`Server/SRReceiver.cs`](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Server/SRReceiver.cs) | **Varianta 3 (Nota 10)**: Fereastră glisantă de ambele părți. Receptorul stochează out-of-order în `_buffer` și trimite ACK-uri selective (individuale). La expirarea timer-ului, emițătorul trimite **strict** pachetul pierdut (nu întreaga fereastră). Când pachetul lipsă sosește, receptorul asamblează datele și le livrează aplicației. |
| **5. Corectitudinea Concurenței** | [`Client/SRSender.cs` - L115-143](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L115-L143) | Folosește timere asincrone bazate pe evenimente (`System.Timers.Timer`), care rulează pe fire de execuție din ThreadPool. Toată starea critică (`_sendBase`, `_nextSeqNum`, `_acked`, `_timers`) este protejată concurent prin `lock (_wndLock)`. |

---

## 2. Ghid pentru PROBA SCRISĂ (Săptămâna 12)

În cadrul testului scris de 30 de minute, trebuie să fii capabil să explici și să desenezi scenariul ales.

### A. Diagrama de Secvență (Time-Space Diagram)
Iată diagrama exactă a scenariului în care pachetul `DATA seq=1` se pierde, receptorul stochează `seq=2` out-of-order în buffer, iar emițătorul face retransmitere selectivă după expirarea timer-ului asociat pachetului `seq=1`.

```mermaid
sequenceDiagram
    autonumber
    Participant Client as Client (Emițător)
    Participant Server as Server (Receptor)

    Note over Client, Server: Phase 1: Three-Way Handshake
    Client->>Server: SYN (Window=8)
    Server->>Client: SYN-ACK (Window=8)
    Client->>Server: ACK (Window=8)

    Note over Client, Server: Phase 2: Data Transfer (Window Size = 8)
    Client->>Server: DATA seq=0 (Timer 0 pornit)
    Server->>Client: ACK 0
    Note over Client: Primește ACK 0: oprește Timer 0, slides window base 0->1

    Client->>Server: DATA seq=1 (Timer 1 pornit)
    Note over Server: [PIERDUT/DROP SIMULAT] DATA seq=1 nu ajunge la server!

    Client->>Server: DATA seq=2 (Timer 2 pornit)
    Note over Server: Primește DATA seq=2 (out of order). Îl stochează în BUFFER!
    Server->>Client: ACK 2
    Note over Client: Primește ACK 2: oprește Timer 2. Păstrează starea ACKed pentru seq=2. (Nu glisează!)

    Note over Client: [TIMEOUT] Expiră Timer 1 pentru seq=1!
    Client->>Server: Retransmite DATA seq=1 (Timer 1 repornit)
    Note over Server: Primește DATA seq=1 (pachetul lipsă!).
    Note over Server: Asamblează seq=1 și seq=2 (din buffer) și le livrează aplicației!
    Server->>Client: ACK 1

    Note over Client: Primește ACK 1: oprește Timer 1, slides window base 1->3
```

### B. Avantajele și Dezavantajele Selective Repeat (SR)

| Protocol | Descriere scurtă | Avantaje | Dezavantaje |
| :--- | :--- | :--- | :--- |
| **Stop-and-Wait (SAW)** *(Nota max: 6.00)* | Fereastra $W=1$. Trimite un pachet, așteaptă ACK-ul, abia apoi trimite următorul. | Extrem de simplu de implementat; nu necesită buffere complexe sau ordonare la receptor. | Eficiență catastrofală pe conexiuni cu latență mare (Rtt mare), canalul fiind subutilizat. |
| **Go-Back-N (GBN)** *(Nota max: 8.00)* | Fereastra $W > 1$ la emițător, dar $W=1$ la receptor. Receptorul acceptă doar pachete consecutive, ignorând pachetele sosite out-of-order. | Simplitatea receptorului (nu necesită buffer pentru pachete viitoare). | Dacă se pierde un singur pachet, se retransmite **întreaga fereastră** de pachete (risipă masivă de lățime de bandă). |
| **Selective Repeat (SR)** *(Nota max: 10.00)* | Fereastra $W > 1$ la ambele capete. Receptorul stochează out-of-order și trimite ACK individual per pachet. | **Eficiență maximă a canalului**. Se retransmite **strict** pachetul pierdut (nu întreaga fereastră), economisind masiv bandă. | Complexitate ridicată: necesită buffer de reordonare la receptor și timere independente/paralele la emițător. |

### C. Funcționarea Timer-ului (Când pornește și când se oprește?)
În **Selective Repeat**, fiecare pachet aflat în zbor (in-flight) are propriul său timer independent.
1. **Când pornește?**
   - În momentul în care pachetul `DATA` este trimis inițial în rețea ([`SRSender.cs` - L73](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L73)).
   - În momentul în care pachetul este retransmis ca urmare a unui timeout ([`SRSender.cs` - L141](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L141)).
2. **Când se oprește (și se distruge)?**
   - Atunci când clientul primește pachetul de tip `ACK` corespunzător acelui număr de secvență (`ackSeq`) ([`SRSender.cs` - L176](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L176)).
3. **Ce se întâmplă la expirare (Timeout)?**
   - Se apelează callback-ul de timeout `OnTimeout(seq)` pe un thread din ThreadPool. Emițătorul retransmite strict pachetul asociat numărului de secvență expirate și repornește imediat timer-ul pentru acel segment ([`SRSender.cs` - L133-143](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L133-L143)).

---

## 3. Ghid pentru PREZENTAREA PRACTICĂ (Săptămâna 13)

Profesorul te va pune să rulezi aplicația și îți va face un Code Review pe implementare. Iată ce trebuie să îi arăți și cum să explici concurența.

### A. Funcționalitatea de Bază (UDP & Handshake)
* **Conexiunea UDP**: Folosește clasa standard `UdpClient` din C#. Serverul ascultă pe portul 9000 (bind la `Any`), iar Clientul face bind pe portul 9001 (pentru a evita coliziunea de porturi pe aceeași mașină) și trimite către portul 9000.
* **Serializarea**: Se realizează prin conversia clasei `Packet` în format JSON utilizând `System.Text.Json` (metoda `Serialize()`), iar string-ul rezultat este codificat în bytes UTF-8 ([`Packet.cs` - L26-40](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Common/Packet.cs#L26-L40)).
* **Three-Way Handshake**: Demonstrează cum clientul trimite `SYN` (cu fereastra propusă), serverul răspunde cu `SYN-ACK` (aprobând sau modificând fereastra) și clientul confirmă prin `ACK`.

### B. Validarea Protocolului Selective Repeat pe loguri
* Pornește Serverul, apoi Clientul.
* Arată în consolă mesajele colorate generice (`Logger.cs`):
  - `[SENDER] Sent DATA seq=X` (Verde)
  - `[RECEIVER] Received DATA seq=X` (Galben)
  - `[SENDER] Received ACK for seq=X` (Galben)
  - `[SENDER] TIMEOUT for seq=X → retransmitting` (Magenta - demonstrează retransmisia selectivă!)
  - `[RECEIVER] [SIMULATED LOSS] DATA seq=X dropped` (Roșu - demonstrează drop-ul controlat de 15%).
* **Demonstrează livrarea ordonată**: Subliniază în log-ul serverului cum pachetele sosite în afara ordinii sunt salvate în buffer (Receiver-ul afișează `Duplicate/Out-of-order ... ignored/buffered`) și cum, în momentul în care sosește pachetul lipsă, serverul afișează `Delivered seq=... to application layer` pentru mai multe pachete consecutive deodată.

### C. Tratarea Erorilor Avansate (Corner Cases - Nota 10 garantată!)
Explică profesorului cele două optimizări masive pe care le-am implementat suplimentar față de o temă simplă:
1. **Re-ACK în caz de pierdere a ultimului ACK**: Explică cum, în cazul în care ultimul ACK se pierde în rețea, serverul aflat în `WaitForFin` va trimite din nou ACK la recepționarea oricărui `DATA` duplicat, prevenind blocarea clientului într-o buclă infinită de retransmisie.
2. **Filtrarea Endpoint-urilor străine**: Explică cum atât receptorul cât și emițătorul filtrează pachetele sosite folosind `.Equals(clientEp)` / `.Equals(serverEp)` pentru a preveni atacuri sau interceptări din rețea și amestecarea fluxurilor de date.

### D. Concurența și Multithreading (Code Review)
Aceasta este partea cea mai sensibilă unde mulți studenți eșuează. Fii pregătit să răspunzi astfel:
1. **Cum funcționează ascultarea de ACKs la Emițător?**
   - Ascultarea rulează asincron pe un thread separat creat prin `Task.Run(() => ListenForAcks(total))` ([`SRSender.cs` - L53](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L53)). Aceasta permite clientului să recepționeze ACKs în paralel cu trimiterea de noi pachete DATA sau cu declanșarea timerelor.
2. **Cum funcționează Timerele?**
   - Fiecare segment din fereastră are o instanță independentă de `System.Timers.Timer`. Evenimentul `Elapsed` rulează asincron pe un thread din ThreadPool administrat de sistem ([`SRSender.cs` - L115-121](file:///c:/Users/hadna/OneDrive/Desktop/Egyetem/Sem%202/RC/RDT_UDP/Client/SRSender.cs#L115-L121)).
3. **Cum este asigurată Thread-Safety (Siguranța la execuție concurentă)?**
   - Deoarece structurile de date (`_timers`, `_acked`, `_sendBase`, `_nextSeqNum`) sunt accesate de trei entități diferite în paralel (Firul principal de trimitere, Firul de ascultare ACKs și Firele de declanșare a timerelor), am folosit un mecanism de excludere mutuală: `lock (_wndLock)`. Orice modificare sau citire a acestor colecții se face doar sub protecția acestui lacăt, prevenind complet condițiile de cursă (Race Conditions) și coruperea memoriei.
