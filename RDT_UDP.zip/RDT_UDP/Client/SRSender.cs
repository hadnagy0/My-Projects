using System.Net;
using System.Net.Sockets;
using RDT_UDP.Common;

namespace RDT_UDP.Client
{
    public class SRSender
    {
        private const int TIMEOUT_MS  = 1000;   
        private const int SEGMENT_SIZE = 512;   

        private readonly UdpClient   _udp;
        private readonly IPEndPoint  _serverEp;
        private readonly int         _windowSize;
        
        private int  _sendBase   = 0;  
        private int  _nextSeqNum = 0;  
        private readonly object _wndLock = new object();
        
        private readonly Dictionary<int, byte[]>               _packetBuffer  = new();
        private readonly Dictionary<int, bool>                 _acked          = new();
        private readonly Dictionary<int, System.Timers.Timer>  _timers         = new();
        private readonly Dictionary<int, bool>                 _isLast         = new();

        private TaskCompletionSource<bool> _allAcked = new(TaskCreationOptions.RunContinuationsAsynchronously);

        public SRSender(UdpClient udp, IPEndPoint serverEp, int windowSize)
        {
            _udp        = udp;
            _serverEp   = serverEp;
            _windowSize = windowSize;
        }

        public async Task SendDataAsync(byte[] data)
        {
            var segments = Segment(data);
            int total    = segments.Count;
            Logger.Info("SENDER", $"Total segments to send: {total}, window size: {_windowSize}");

            var listenerTask = Task.Run(() => ListenForAcks(total));

            int idx = 0;
            while (idx < total)
            {
                lock (_wndLock)
                {
                    while (_nextSeqNum < _sendBase + _windowSize && _nextSeqNum < total)
                    {
                        int seq  = _nextSeqNum;
                        byte[] payload = segments[seq];
                        bool isLast    = (seq == total - 1);

                        _packetBuffer[seq] = payload;
                        _acked[seq]        = false;
                        _isLast[seq]       = isLast;

                        SendPacket(seq, payload, isLast);
                        StartTimer(seq);

                        _nextSeqNum++;
                        idx++;
                    }
                }
                await Task.Delay(10); 
            }

            await _allAcked.Task;
            Logger.Done("SENDER", "All segments acknowledged. Transfer complete.");
        }
        
        private void SendPacket(int seq, byte[] payload, bool isLast)
        {
            var pkt = new Packet
            {
                Type           = PacketType.DATA,
                SequenceNumber = seq,
                WindowSize     = _windowSize,
                IsLastPacket   = isLast,
                Data           = payload
            };

            if (NetworkSimulator.ShouldDrop())
            {
                Logger.Drop("SENDER", $"[SIMULATED LOSS] DATA seq={seq} dropped before sending");
                return; 
            }

            byte[] bytes = pkt.Serialize();
            _udp.Send(bytes, bytes.Length, _serverEp);
            Logger.Send("SENDER", $"Sent DATA seq={seq} ({payload.Length} bytes){(isLast ? " [LAST]" : "")}");
        }
        
        private void StartTimer(int seq)
        {
            var timer = new System.Timers.Timer(TIMEOUT_MS) { AutoReset = false };
            timer.Elapsed += (_, __) => OnTimeout(seq);
            _timers[seq]   = timer;
            timer.Start();
        }

        private void StopTimer(int seq)
        {
            if (_timers.TryGetValue(seq, out var t))
            {
                t.Stop();
                t.Dispose();
                _timers.Remove(seq);
            }
        }

        private void OnTimeout(int seq)
        {
            lock (_wndLock)
            {
                if (_acked.TryGetValue(seq, out bool isAcked) && isAcked) return;

                Logger.Retx("SENDER", $"TIMEOUT for seq={seq} → retransmitting");
                SendPacket(seq, _packetBuffer[seq], _isLast.GetValueOrDefault(seq));
                StartTimer(seq);  
            }
        }

        private void ListenForAcks(int total)
        {
            int ackedCount = 0;
            while (ackedCount < total)
            {
                try
                {
                    IPEndPoint? ep   = null;
                    byte[]      data = _udp.Receive(ref ep);

                    if (ep == null || !ep.Equals(_serverEp))
                    {
                        Logger.Info("SENDER", $"Received packet from foreign endpoint {ep}, expected {_serverEp}. Ignoring.");
                        continue;
                    }
                    
                    if (NetworkSimulator.ShouldDrop())
                    {
                        Logger.Drop("SENDER", "[SIMULATED LOSS] ACK dropped");
                        continue;
                    }

                    var pkt = Packet.Deserialize(data);
                    if (pkt.Type != PacketType.ACK) continue;

                    int ackSeq = pkt.AckNumber;
                    Logger.Recv("SENDER", $"Received ACK for seq={ackSeq}");

                    lock (_wndLock)
                    {
                        if (_acked.TryGetValue(ackSeq, out bool already) && !already)
                        {
                            _acked[ackSeq] = true;
                            StopTimer(ackSeq);
                            ackedCount++;
                            
                            while (_acked.TryGetValue(_sendBase, out bool ok) && ok)
                            {
                                Logger.Info("SENDER", $"Window slides: base {_sendBase} → {_sendBase + 1}");
                                _sendBase++;
                            }

                        }
                    }
                }
                catch (SocketException ex) when (ex.SocketErrorCode == SocketError.Interrupted)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Logger.Info("SENDER", $"ACK listener exception: {ex.Message}");
                }
            }
            _allAcked.TrySetResult(true);
        }

        private static List<byte[]> Segment(byte[] data)
        {
            var list = new List<byte[]>();
            for (int offset = 0; offset < data.Length; offset += SEGMENT_SIZE)
            {
                int len = Math.Min(SEGMENT_SIZE, data.Length - offset);
                var seg = new byte[len];
                Buffer.BlockCopy(data, offset, seg, 0, len);
                list.Add(seg);
            }
            
            if (list.Count == 0) list.Add(Array.Empty<byte>());
            return list;
        }
    }
}
