using System.Net;
using System.Net.Sockets;
using System.Text;
using RDT_UDP.Common;
using RDT_UDP.Client;

namespace RDT_UDP
{
    class ClientProgram
    {
        static async Task Main(string[] args)
        {
            const string SERVER_IP   = "127.0.0.1";
            const int    SERVER_PORT = 9000;
            const int    CLIENT_PORT = 9001;
            const int    DESIRED_WIN = 8;
            const double LOSS_RATE   = 0.15;

            NetworkSimulator.LossRate = LOSS_RATE;

            Console.Title = "RDT Client – Selective Repeat";
            Logger.Info("CLIENT", "=== Reliable Data Transfer Client (Selective Repeat) ===");
            Logger.Info("CLIENT", $"Server: {SERVER_IP}:{SERVER_PORT}  |  Loss rate: {LOSS_RATE * 100}%");

            var serverEp = new IPEndPoint(IPAddress.Parse(SERVER_IP), SERVER_PORT);
            var clientEp = new IPEndPoint(IPAddress.Any, CLIENT_PORT);
            using var udp = new UdpClient(clientEp);
            udp.Client.ReceiveTimeout = 5000;
            
            int negotiatedWindow = await PerformHandshakeAsync(udp, serverEp, DESIRED_WIN);
            if (negotiatedWindow <= 0)
            {
                Logger.Info("CLIENT", "Handshake failed. Exiting.");
                return;
            }

            Logger.Done("CLIENT", $"Connection established. Negotiated window size = {negotiatedWindow}");

            string message = BuildTestMessage(5000);
            byte[] data    = Encoding.UTF8.GetBytes(message);
            Logger.Info("CLIENT", $"Sending {data.Length} bytes...");

            udp.Client.ReceiveTimeout = 0;

            var sender = new SRSender(udp, serverEp, negotiatedWindow);
            await sender.SendDataAsync(data);
            
            SendFin(udp, serverEp);

            if (!Console.IsInputRedirected)
            {
                Logger.Done("CLIENT", "Done. Press any key to exit.");
                Console.ReadKey();
            }
            else
            {
                Logger.Done("CLIENT", "Done. Exiting (non-interactive mode).");
            }
        }

        static async Task<int> PerformHandshakeAsync(UdpClient udp, IPEndPoint serverEp, int desiredWindow)
        {
            var syn = new Packet { Type = PacketType.SYN, WindowSize = desiredWindow };
            byte[] synBytes = syn.Serialize();

            for (int attempt = 1; attempt <= 3; attempt++)
            {
                Logger.Send("CLIENT", $"[Handshake] Sending SYN (window={desiredWindow}), attempt {attempt}");
                udp.Send(synBytes, synBytes.Length, serverEp);

                try
                {
                    IPEndPoint? ep   = null;
                    byte[]      data = udp.Receive(ref ep);

                    if (ep == null || !ep.Equals(serverEp))
                    {
                        Logger.Info("CLIENT", $"[Handshake] Received packet from foreign endpoint {ep}, expected {serverEp}. Ignoring.");
                        attempt--; 
                        continue;
                    }

                    var         pkt  = Packet.Deserialize(data);

                    if (pkt.Type == PacketType.SYN_ACK)
                    {
                        int agreedWin = pkt.WindowSize;
                        Logger.Recv("CLIENT", $"[Handshake] Received SYN-ACK (negotiated window={agreedWin})");

                        var ack = new Packet { Type = PacketType.ACK, WindowSize = agreedWin };
                        byte[] ackBytes = ack.Serialize();
                        udp.Send(ackBytes, ackBytes.Length, serverEp);
                        Logger.Send("CLIENT", "[Handshake] Sent ACK. Handshake complete.");

                        return agreedWin;
                    }
                }
                catch (SocketException ex)
                {
                    if (ex.SocketErrorCode == SocketError.TimedOut)
                    {
                        Logger.Info("CLIENT", $"[Handshake] Timeout waiting for SYN-ACK (attempt {attempt})");
                    }
                    else if (ex.SocketErrorCode == SocketError.ConnectionReset || ex.SocketErrorCode == SocketError.ConnectionRefused)
                    {
                        Logger.Info("CLIENT", $"[Handshake] Conexiunea a fost respinsa (Serverul NU este pornit pe portul {serverEp.Port}!). Incercare {attempt}");
                        Thread.Sleep(1000); // Așteaptă 1 secundă înainte de reîncercare
                    }
                    else
                    {
                        Logger.Info("CLIENT", $"[Handshake] Eroare Socket ({ex.SocketErrorCode}): {ex.Message} (attempt {attempt})");
                        Thread.Sleep(1000);
                    }
                }
            }
            await Task.CompletedTask; 
            return -1;
        }

        static void SendFin(UdpClient udp, IPEndPoint serverEp)
        {
            var fin = new Packet { Type = PacketType.FIN };
            byte[] finBytes = fin.Serialize();
            udp.Send(finBytes, finBytes.Length, serverEp);
            Logger.Send("CLIENT", "Sent FIN");

            try
            {
                udp.Client.ReceiveTimeout = 3000;
                IPEndPoint? ep = null;
                byte[]      d  = udp.Receive(ref ep);
                var         p  = Packet.Deserialize(d);
                if (p.Type == PacketType.FIN_ACK)
                    Logger.Recv("CLIENT", "Received FIN-ACK. Connection closed.");
            }
            catch { /* ignore */ }
        }

        static string BuildTestMessage(int targetBytes)
        {
            var sb = new StringBuilder();
            int i  = 0;
            while (sb.Length < targetBytes)
                sb.AppendLine($"[Linia {++i:D4}] Aceasta este o linie de test pentru transferul fiabil RDT prin Selective Repeat peste UDP.");
            return sb.ToString()[..Math.Min(sb.Length, targetBytes)];
        }
    }
}
