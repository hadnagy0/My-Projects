# SecureChat - Varianta 3 (Nota 10)
## Rețele de Calculatoare | Tema 4: Comunicații Securizate
### Universitatea Transilvania din Brașov | 2025-2026

---

## Structura Proiectului

```
SecureChat/
├── Common/
│   ├── SecurePacket.cs    — Clasa pachetului securizat (serializare JSON + prefix lungime)
│   ├── CryptoHelper.cs    — Toate operațiile criptografice (DH, AES, SHA-256)
│   └── DHHandshake.cs     — Logica de handshake Diffie-Hellman peste TCP
├── Server/
│   ├── Program.cs         — Server TCP (TcpListener, port 8080)
│   └── SecureChat.Server.csproj
└── Client/
    ├── Program.cs         — Client TCP (TcpClient)
    └── SecureChat.Client.csproj
```

---

## Cum Rulezi Aplicația

### Cerințe
- .NET 8 SDK instalat (https://dotnet.microsoft.com/download)

### Pași
1. **Pornești Serverul** (primul):
   ```bash
   cd Server
   dotnet run
   ```

2. **Pornești Clientul** (în altă fereastră):
   ```bash
   cd Client
   dotnet run
   ```

3. Ambele console vor afișa **handshake-ul DH**, după care poți scrie mesaje.
4. Scrie `/exit` pentru a închide.

---

## Arhitectura Securității (Varianta 3)

### 1. SecurePacket — Clasa de pachete

Nu se trimit string-uri brute pe `NetworkStream`. Fiecare mesaj este împachetat într-un `SecurePacket`:

```csharp
public class SecurePacket {
    byte[] IV         // Initialization Vector AES (aleatoriu, 16 bytes, trimis în clar)
    byte[] Ciphertext // Mesajul criptat cu AES-256-CBC
    byte[] Hash       // SHA-256 al Ciphertext (pentru integritate)
    string Sender     // Identificatorul expeditorului
}
```

Pachetul este serializat ca **JSON** și precedat de un prefix de 4 bytes cu lungimea,
pentru a delimita mesajele pe stream-ul TCP.

---

### 2. Handshake Diffie-Hellman

#### Cum funcționează matematic

Parametri comuni (cunoscuți public):
- `p` = număr prim mare (~512 biți, grup DH standard)
- `g` = 2 (rădăcină primitivă modulo p)

Pașii handshake-ului:

| Pas | Server | Client |
|-----|--------|--------|
| 1   | Generează secret `a` (aleatoriu) | Generează secret `b` (aleatoriu) |
| 2   | Calculează `A = g^a mod p` | Calculează `B = g^b mod p` |
| 3   | Trimite `A` → | ← Trimite `B` |
| 4   | Calculează `S = B^a mod p` | Calculează `S = A^b mod p` |
| 5   | Derivează cheie AES: `Key = SHA256(S)` | Derivează cheie AES: `Key = SHA256(S)` |

**De ce funcționează?** Deoarece: `B^a mod p = (g^b)^a mod p = g^(ab) mod p = (g^a)^b mod p = A^b mod p`

**Securitate**: Un atacator vede `A` și `B`, dar nu poate calcula `a` sau `b` (problema logaritmului discret).

#### Implementare (CryptoHelper.cs)

```csharp
// Cheie privată: număr aleatoriu mare
BigInteger privateKey = GenerateDHPrivateKey();

// Cheie publică: g^a mod p
BigInteger publicKey = BigInteger.ModPow(G, privateKey, P);

// Secret comun: B^a mod p
BigInteger sharedSecret = BigInteger.ModPow(otherPublicKey, privateKey, P);

// Derivare cheie AES (32 bytes = 256 biți)
byte[] aesKey = SHA256.HashData(sharedSecret.ToByteArray());
```

---

### 3. Confidențialitate — AES-256-CBC

- **Algoritm**: AES (Advanced Encryption Standard), cheie 256 biți
- **Mod**: CBC (Cipher Block Chaining) — fiecare bloc depinde de precedentul
- **IV**: Generat aleatoriu pentru **fiecare mesaj** (esențial! același plaintext → ciphertext diferit)
- **Padding**: PKCS7

```csharp
using var aes = Aes.Create();
aes.KeySize = 256;
aes.Mode = CipherMode.CBC;
aes.Padding = PaddingMode.PKCS7;
aes.Key = key;       // Cheia derivată din DH
aes.GenerateIV();    // IV nou pentru fiecare mesaj!
```

**IV-ul se trimite în clar** alături de ciphertext (este necesar la decriptare, nu este secret).

---

### 4. Integritate — SHA-256

- Se calculează `Hash = SHA256(Ciphertext)` și se atașează pachetului
- Receptorul recalculează hash-ul după recepție
- Dacă hash-urile diferă → pachetul a fost **alterat în tranzit** → **RESPINS**

```csharp
// Sender: calculează și atașează hash-ul
byte[] hash = SHA256.HashData(ciphertext);

// Receiver: verifică integritatea (comparație în timp constant)
bool ok = CryptographicOperations.FixedTimeEquals(
    SHA256.HashData(receivedCiphertext),
    receivedHash
);
if (!ok) throw new Exception("INTEGRITATE COMPROMISĂ!");
```

**De ce criptarea singură nu este suficientă?**
AES-CBC este maleabil: un atacator poate modifica biți din ciphertext și produce modificări
controlate în plaintext, fără a cunoaște cheia. Hash-ul SHA-256 detectează orice modificare.

---

### 5. Logging în Consolă

Conform cerințelor, consola afișează explicit toate stările interne:

```
[DH HANDSHAKE] Cheie privată DH generată: 3F8A...
[DH HANDSHAKE] Cheie publică trimisă: A1B2...
[DH HANDSHAKE] Cheie publică primită: C3D4...
[DH HANDSHAKE] Secret comun calculat: E5F6...
[DH HANDSHAKE] ✓ Cheie AES derivată: 7890ABCD...

[Trimis - TEXT CLAR]: Hello World
[Trimis - IV (hex)]:  A3F2...
[Trimis - CRIPTAT (Base64)]: x9Kp...
[Trimis - HASH SHA-256]: 2CF2...

[Primit de la: CLIENT]
[Primit - CRIPTAT (Base64)]: x9Kp...
[INTEGRITATE] ✓ Hash verificat cu succes.
[Primit - DECRIPTAT]: Hello World
```

---

## Concepte Teoretice (pentru Proba Scrisă)

### Criptare Simetrică vs. Asimetrică

| Criteriu | Simetrică (AES) | Asimetrică (RSA) |
|----------|----------------|------------------|
| Chei | Aceeași cheie pt. criptare/decriptare | Cheie publică + cheie privată |
| Viteză | Foarte rapidă | De ~1000x mai lentă |
| Distribuție cheie | Problemă (cum transmiți cheia?) | Rezolvată (trimiti cheia publică liber) |
| Utilizare | Date în tranzit/repaus | Schimb de chei, semnături digitale |

**Soluția noastră**: DH rezolvă distribuția cheii simetrice → AES criptează datele rapid.

### Rolul Hash-urilor (Integritate)

- **SHA-256** = funcție de dispersie criptografică (one-way)
- Orice modificare a datelor → hash complet diferit (efect avalanșă)
- Nu se poate reconstitui datele din hash (ireversibil)
- Folosit pentru: integritate mesaje, parole, semnături digitale, certificate SSL/TLS

### De ce DH este sigur?

Atacatorul vede `A = g^a mod p` și `B = g^b mod p`, dar nu poate calcula `a` sau `b`
— aceasta este **Problema Logaritmului Discret**, considerată computațional infezabilă
pentru numere de 2048+ biți (ar dura mai mult decât vârsta Universului cu hardware actual).
