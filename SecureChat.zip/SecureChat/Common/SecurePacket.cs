using System.Text.Json;
using System.Text.Json.Serialization;

namespace SecureChat.Common
{
    /// <summary>
    /// Pachetul securizat trimis prin rețea.
    /// Conține: IV (pentru AES), Ciphertext (mesajul criptat), Hash (SHA-256 pentru integritate).
    /// </summary>
    public class SecurePacket
    {
        [JsonPropertyName("iv")]
        public byte[] IV { get; set; } = Array.Empty<byte>();

        [JsonPropertyName("ciphertext")]
        public byte[] Ciphertext { get; set; } = Array.Empty<byte>();

        [JsonPropertyName("hash")]
        public byte[] Hash { get; set; } = Array.Empty<byte>();

        [JsonPropertyName("sender")]
        public string Sender { get; set; } = string.Empty;

        /// <summary>Serializează pachetul în JSON (bytes).</summary>
        public byte[] Serialize()
        {
            string json = JsonSerializer.Serialize(this);
            byte[] jsonBytes = System.Text.Encoding.UTF8.GetBytes(json);

            // Prefixăm cu lungimea (4 bytes) pentru a ști câți bytes să citim
            byte[] lengthPrefix = BitConverter.GetBytes(jsonBytes.Length);
            byte[] result = new byte[4 + jsonBytes.Length];
            Buffer.BlockCopy(lengthPrefix, 0, result, 0, 4);
            Buffer.BlockCopy(jsonBytes, 0, result, 4, jsonBytes.Length);
            return result;
        }

        /// <summary>Deserializează un pachet din stream-ul TCP.</summary>
        public static SecurePacket Deserialize(System.IO.Stream stream)
        {
            // Citim primii 4 bytes pentru lungime
            byte[] lengthBuffer = new byte[4];
            int totalRead = 0;
            while (totalRead < 4)
            {
                int read = stream.Read(lengthBuffer, totalRead, 4 - totalRead);
                if (read == 0) throw new Exception("Conexiunea a fost închisă.");
                totalRead += read;
            }

            int length = BitConverter.ToInt32(lengthBuffer, 0);
            byte[] jsonBuffer = new byte[length];
            totalRead = 0;
            while (totalRead < length)
            {
                int read = stream.Read(jsonBuffer, totalRead, length - totalRead);
                if (read == 0) throw new Exception("Conexiunea a fost închisă.");
                totalRead += read;
            }

            string json = System.Text.Encoding.UTF8.GetString(jsonBuffer);
            return JsonSerializer.Deserialize<SecurePacket>(json)
                ?? throw new Exception("Pachetul deserializat este null.");
        }
    }
}
