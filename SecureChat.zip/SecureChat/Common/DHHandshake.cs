using System.Numerics;
using System.Net.Sockets;
using System.Text;

namespace SecureChat.Common
{
    /// <summary>
    /// Gestionează schimbul de chei Diffie-Hellman prin stream-ul TCP.
    /// Protocolul de handshake:
    ///   1. Fiecare parte generează o cheie privată secretă (a sau b).
    ///   2. Calculează cheia publică: A = g^a mod p  /  B = g^b mod p.
    ///   3. Trimite cheia publică celeilalte părți (ca string hex).
    ///   4. Primește cheia publică a celeilalte părți.
    ///   5. Calculează secretul comun: S = B^a mod p = A^b mod p.
    ///   6. Derivă cheia AES din S folosind SHA-256.
    /// </summary>
    public static class DHHandshake
    {
        /// <summary>
        /// Execută handshake-ul DH complet.
        /// Returnează cheia AES derivată (32 bytes) și informații pentru logging.
        /// </summary>
        public static byte[] Execute(NetworkStream stream, string roleName, out string logInfo)
        {
            var sb = new StringBuilder();

            // Pas 1: Generăm cheia privată
            BigInteger privateKey = CryptoHelper.GenerateDHPrivateKey();
            sb.AppendLine($"  [{roleName}] Cheie privată DH generată (primii 32 hex): " +
                          CryptoHelper.ToHex(privateKey.ToByteArray()).Substring(0, Math.Min(32,
                          CryptoHelper.ToHex(privateKey.ToByteArray()).Length)) + "...");

            // Pas 2: Calculăm cheia publică
            BigInteger publicKey = CryptoHelper.ComputeDHPublicKey(privateKey);
            string publicKeyHex = CryptoHelper.ToHex(publicKey.ToByteArray());
            sb.AppendLine($"  [{roleName}] Cheie publică DH (A sau B): {publicKeyHex.Substring(0, Math.Min(64, publicKeyHex.Length))}...");

            // Pas 3: Trimitem cheia publică (prefixată cu lungimea)
            byte[] publicKeyBytes = Encoding.UTF8.GetBytes(publicKeyHex);
            byte[] lengthBytes = BitConverter.GetBytes(publicKeyBytes.Length);
            stream.Write(lengthBytes, 0, 4);
            stream.Write(publicKeyBytes, 0, publicKeyBytes.Length);
            stream.Flush();
            sb.AppendLine($"  [{roleName}] Cheie publică trimisă ({publicKeyBytes.Length} bytes).");

            // Pas 4: Primim cheia publică a celeilalte părți
            byte[] recvLength = new byte[4];
            ReadExact(stream, recvLength, 4);
            int recvLen = BitConverter.ToInt32(recvLength, 0);
            byte[] recvKeyBytes = new byte[recvLen];
            ReadExact(stream, recvKeyBytes, recvLen);
            string otherPublicKeyHex = Encoding.UTF8.GetString(recvKeyBytes);
            BigInteger otherPublicKey = ParseHexBigInteger(otherPublicKeyHex);
            sb.AppendLine($"  [{roleName}] Cheie publică primită ({recvLen} bytes): {otherPublicKeyHex.Substring(0, Math.Min(64, otherPublicKeyHex.Length))}...");

            // Pas 5: Calculăm secretul comun
            BigInteger sharedSecret = CryptoHelper.ComputeSharedSecret(otherPublicKey, privateKey);
            string secretHex = CryptoHelper.ToHex(sharedSecret.ToByteArray());
            sb.AppendLine($"  [{roleName}] Secret comun DH calculat: {secretHex.Substring(0, Math.Min(64, secretHex.Length))}...");

            // Pas 6: Derivăm cheia AES
            byte[] aesKey = CryptoHelper.DeriveAESKey(sharedSecret);
            sb.AppendLine($"  [{roleName}] Cheie AES derivată (SHA-256 al secretului): {CryptoHelper.ToHex(aesKey)}");

            logInfo = sb.ToString();
            return aesKey;
        }

        private static void ReadExact(NetworkStream stream, byte[] buffer, int count)
        {
            int totalRead = 0;
            while (totalRead < count)
            {
                int read = stream.Read(buffer, totalRead, count - totalRead);
                if (read == 0) throw new Exception("Conexiunea a fost închisă în timpul handshake-ului DH.");
                totalRead += read;
            }
        }

        private static BigInteger ParseHexBigInteger(string hex)
        {
            byte[] bytes = Convert.FromHexString(hex);
            // Asigurăm că e interpretat ca număr pozitiv
            if (bytes[bytes.Length - 1] >= 0x80)
            {
                Array.Resize(ref bytes, bytes.Length + 1);
                bytes[bytes.Length - 1] = 0;
            }
            return new BigInteger(bytes);
        }
    }
}
