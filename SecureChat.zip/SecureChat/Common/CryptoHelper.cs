using System.Security.Cryptography;
using System.Text;

namespace SecureChat.Common
{
    /// <summary>
    /// Clasă helper pentru toate operațiile criptografice:
    ///  - Schimb de chei Diffie-Hellman (DH)
    ///  - Criptare/Decriptare AES-256-CBC
    ///  - Calcul și verificare Hash SHA-256
    /// </summary>
    public static class CryptoHelper
    {
        // ─────────────────────────────────────────────────────────────────────
        // PARAMETRI DIFFIE-HELLMAN (publici, conveniți dinainte)
        // p = număr prim (folosim un număr prim sigur de 2048 biți recunoscut)
        // g = rădăcină primitivă modulo p
        // ─────────────────────────────────────────────────────────────────────

        // Folosim un grup DH de 512 biți pentru demonstrație (mai rapid, vizibil în consolă).
        // În producție se folosesc cel puțin 2048 biți.
        private static readonly System.Numerics.BigInteger P = System.Numerics.BigInteger.Parse(
            "00FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
            "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
            "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
            "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
            "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
            "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
            "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
            "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
            "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
            "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
            "15728E5A8AACAA68FFFFFFFFFFFFFFFF",
            System.Globalization.NumberStyles.HexNumber);

        private static readonly System.Numerics.BigInteger G = new System.Numerics.BigInteger(2);

        // ─────────────────────────────────────────────────────────────────────
        // DIFFIE-HELLMAN
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Generează o cheie privată DH aleatorie (număr aleatoriu între 2 și p-2).
        /// </summary>
        public static System.Numerics.BigInteger GenerateDHPrivateKey()
        {
            byte[] bytes = new byte[64]; // 512 biți
            RandomNumberGenerator.Fill(bytes);
            // Asigurăm că numărul este pozitiv
            bytes[bytes.Length - 1] &= 0x7F;
            var privateKey = new System.Numerics.BigInteger(bytes);
            // Asigurăm că e în intervalul [2, p-2]
            privateKey = System.Numerics.BigInteger.Abs(privateKey) % (P - 4) + 2;
            return privateKey;
        }

        /// <summary>
        /// Calculează cheia publică DH: A = g^a mod p
        /// </summary>
        public static System.Numerics.BigInteger ComputeDHPublicKey(System.Numerics.BigInteger privateKey)
        {
            return System.Numerics.BigInteger.ModPow(G, privateKey, P);
        }

        /// <summary>
        /// Calculează secretul comun DH: S = B^a mod p (sau A^b mod p)
        /// </summary>
        public static System.Numerics.BigInteger ComputeSharedSecret(
            System.Numerics.BigInteger otherPublicKey,
            System.Numerics.BigInteger myPrivateKey)
        {
            return System.Numerics.BigInteger.ModPow(otherPublicKey, myPrivateKey, P);
        }

        /// <summary>
        /// Derivă o cheie AES de 256 biți din secretul comun DH folosind SHA-256.
        /// Secretul brut poate fi oricât de mare, SHA-256 îl aduce la exact 32 bytes.
        /// </summary>
        public static byte[] DeriveAESKey(System.Numerics.BigInteger sharedSecret)
        {
            byte[] secretBytes = sharedSecret.ToByteArray();
            // SHA-256 al secretului => 32 bytes = 256 biți (cheia AES perfectă)
            return SHA256.HashData(secretBytes);
        }

        // ─────────────────────────────────────────────────────────────────────
        // AES-256-CBC
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Criptează textul clar cu AES-256-CBC.
        /// Generează un IV aleatoriu nou pentru fiecare mesaj (esențial pentru securitate!).
        /// Returnează (ciphertext, IV).
        /// </summary>
        public static (byte[] Ciphertext, byte[] IV) EncryptAES(string plaintext, byte[] key)
        {
            using var aes = Aes.Create();
            aes.KeySize = 256;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = key;
            aes.GenerateIV(); // IV aleatoriu pentru fiecare mesaj!

            using var encryptor = aes.CreateEncryptor();
            byte[] plaintextBytes = Encoding.UTF8.GetBytes(plaintext);
            byte[] ciphertext = encryptor.TransformFinalBlock(plaintextBytes, 0, plaintextBytes.Length);

            return (ciphertext, aes.IV);
        }

        /// <summary>
        /// Decriptează ciphertext-ul cu AES-256-CBC folosind cheia și IV-ul primit.
        /// </summary>
        public static string DecryptAES(byte[] ciphertext, byte[] key, byte[] iv)
        {
            using var aes = Aes.Create();
            aes.KeySize = 256;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            aes.Key = key;
            aes.IV = iv;

            using var decryptor = aes.CreateDecryptor();
            byte[] plaintextBytes = decryptor.TransformFinalBlock(ciphertext, 0, ciphertext.Length);

            return Encoding.UTF8.GetString(plaintextBytes);
        }

        // ─────────────────────────────────────────────────────────────────────
        // SHA-256 INTEGRITATE
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Calculează hash SHA-256 al ciphertext-ului.
        /// Acesta este atașat pachetului pentru verificarea integrității.
        /// </summary>
        public static byte[] ComputeHash(byte[] data)
        {
            return SHA256.HashData(data);
        }

        /// <summary>
        /// Verifică integritatea pachetului: recalculează hash-ul și îl compară cu cel primit.
        /// Folosim comparație în timp constant pentru a preveni timing attacks.
        /// </summary>
        public static bool VerifyHash(byte[] data, byte[] receivedHash)
        {
            byte[] computedHash = SHA256.HashData(data);
            return CryptographicOperations.FixedTimeEquals(computedHash, receivedHash);
        }

        // ─────────────────────────────────────────────────────────────────────
        // UTILITĂȚI AFIȘARE
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>Convertește bytes în hex string pentru afișare în consolă.</summary>
        public static string ToHex(byte[] bytes) => Convert.ToHexString(bytes);

        /// <summary>Convertește bytes în Base64 string pentru afișare în consolă.</summary>
        public static string ToBase64(byte[] bytes) => Convert.ToBase64String(bytes);
    }
}
