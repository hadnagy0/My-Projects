using System;
using System.Net.Sockets;
using System.Threading;
using SecureChat.Common;

namespace SecureChat.Client
{
    class Program
    {
        static byte[]? aesKey = null;
        static NetworkStream? stream = null;
        static readonly object consoleLock = new object();

        static void Main(string[] args)
        {
            Console.Title = "SecureChat - CLIENT";
            PrintBanner();

            string serverHost = "127.0.0.1";
            int serverPort = 8080;

            ColorLog($"\n[CLIENT] Mă conectez la {serverHost}:{serverPort}...", ConsoleColor.Cyan);

            TcpClient client;
            try
            {
                client = new TcpClient(serverHost, serverPort);
                stream = client.GetStream();
                ColorLog("[CLIENT] ✓ Conectat la server!", ConsoleColor.Green);
            }
            catch (Exception ex)
            {
                ColorLog($"[EROARE] Nu mă pot conecta: {ex.Message}", ConsoleColor.Red);
                ColorLog("Asigurați-vă că serverul rulează înainte de a porni clientul.", ConsoleColor.Yellow);
                Console.ReadKey();
                return;
            }

            ColorLog("─────────────────────────────────────────────────────────", ConsoleColor.DarkGray);

            // ──────────────── HANDSHAKE DIFFIE-HELLMAN ────────────────
            ColorLog("\n[DH HANDSHAKE] Inițiez schimbul de chei Diffie-Hellman...", ConsoleColor.Yellow);
            aesKey = DHHandshake.Execute(stream, "CLIENT", out string dhLog);
            ColorLog(dhLog, ConsoleColor.DarkYellow);
            ColorLog("[DH HANDSHAKE] ✓ Cheie AES negociată cu succes!\n", ConsoleColor.Green);
            ColorLog("─────────────────────────────────────────────────────────", ConsoleColor.DarkGray);
            ColorLog("[CLIENT] Sesiune securizată activă. Poți scrie mesaje. (/exit pentru ieșire)\n", ConsoleColor.Cyan);

            // Thread pentru recepție mesaje
            var receiveThread = new Thread(ReceiveMessages);
            receiveThread.IsBackground = true;
            receiveThread.Start();

            // Thread principal: trimitere mesaje
            while (true)
            {
                string? input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input)) continue;
                if (input.Equals("/exit", StringComparison.OrdinalIgnoreCase)) break;

                SendMessage(input, "CLIENT");
            }

            ColorLog("[CLIENT] Sesiune încheiată.", ConsoleColor.Red);
            client.Close();
        }

        static void SendMessage(string plaintext, string sender)
        {
            if (stream == null || aesKey == null) return;

            try
            {
                // 1. Criptare AES (IV aleatoriu nou pentru fiecare mesaj)
                var (ciphertext, iv) = CryptoHelper.EncryptAES(plaintext, aesKey);

                // 2. Calcul Hash SHA-256 pentru integritate
                byte[] hash = CryptoHelper.ComputeHash(ciphertext);

                // 3. Construim pachetul securizat
                var packet = new SecurePacket
                {
                    IV = iv,
                    Ciphertext = ciphertext,
                    Hash = hash,
                    Sender = sender
                };

                // 4. Serializăm și trimitem
                byte[] data = packet.Serialize();
                stream.Write(data, 0, data.Length);
                stream.Flush();

                // 5. Logging explicit conform cerințelor
                lock (consoleLock)
                {
                    ColorLog($"\n[Trimis - TEXT CLAR]: {plaintext}", ConsoleColor.White);
                    ColorLog($"[Trimis - IV (hex)]:  {CryptoHelper.ToHex(iv)}", ConsoleColor.DarkCyan);
                    ColorLog($"[Trimis - CRIPTAT (Base64)]: {CryptoHelper.ToBase64(ciphertext)}", ConsoleColor.DarkYellow);
                    ColorLog($"[Trimis - HASH SHA-256]: {CryptoHelper.ToHex(hash)}", ConsoleColor.DarkMagenta);
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {
                ColorLog($"[EROARE] Trimitere eșuată: {ex.Message}", ConsoleColor.Red);
            }
        }

        static void ReceiveMessages()
        {
            if (stream == null || aesKey == null) return;

            try
            {
                while (true)
                {
                    // 1. Deserializăm pachetul
                    SecurePacket packet = SecurePacket.Deserialize(stream);

                    // 2. VERIFICARE INTEGRITATE SHA-256
                    bool integrityOk = CryptoHelper.VerifyHash(packet.Ciphertext, packet.Hash);

                    lock (consoleLock)
                    {
                        ColorLog($"\n[Primit de la: {packet.Sender}]", ConsoleColor.Cyan);
                        ColorLog($"[Primit - IV (hex)]:  {CryptoHelper.ToHex(packet.IV)}", ConsoleColor.DarkCyan);
                        ColorLog($"[Primit - CRIPTAT (Base64)]: {CryptoHelper.ToBase64(packet.Ciphertext)}", ConsoleColor.DarkYellow);
                        ColorLog($"[Primit - HASH SHA-256]: {CryptoHelper.ToHex(packet.Hash)}", ConsoleColor.DarkMagenta);

                        if (!integrityOk)
                        {
                            ColorLog("[EROARE INTEGRITATE] ✗ Hash-ul nu corespunde! Pachetul a fost RESPINS.", ConsoleColor.Red);
                            continue;
                        }

                        ColorLog($"[INTEGRITATE] ✓ Hash verificat cu succes.", ConsoleColor.Green);

                        // 3. Decriptare AES
                        string plaintext = CryptoHelper.DecryptAES(packet.Ciphertext, aesKey, packet.IV);
                        ColorLog($"[Primit - DECRIPTAT]: {plaintext}", ConsoleColor.White);
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                ColorLog($"\n[CLIENT] Conexiunea serverului a fost închisă: {ex.Message}", ConsoleColor.Red);
            }
        }

        static void ColorLog(string message, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        static void PrintBanner()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("╔══════════════════════════════════════════════════════╗");
            Console.WriteLine("║          SecureChat CLIENT - Varianta 3              ║");
            Console.WriteLine("║   DH Key Exchange + AES-256-CBC + SHA-256 Integritate║");
            Console.WriteLine("╚══════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }
    }
}
