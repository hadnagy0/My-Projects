using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using SecureChat.Common;

namespace SecureChat.Server
{
    class Program
    {
        static byte[]? aesKey = null;
        static NetworkStream? stream = null;
        static readonly object consoleLock = new object();

        static void Main(string[] args)
        {
            Console.Title = "SecureChat - SERVER";
            PrintBanner();

            int port = 8080;
            var listener = new TcpListener(IPAddress.Any, port);
            listener.Start();

            ColorLog($"\n[SERVER] Ascult conexiuni pe portul {port}...\n", ConsoleColor.Cyan);

            // Așteptăm un client
            TcpClient client = listener.AcceptTcpClient();
            stream = client.GetStream();
            string clientAddress = ((IPEndPoint)client.Client.RemoteEndPoint!).ToString();

            ColorLog($"[SERVER] Client conectat: {clientAddress}", ConsoleColor.Green);
            ColorLog("─────────────────────────────────────────────────────────", ConsoleColor.DarkGray);

            // ──────────────── HANDSHAKE DIFFIE-HELLMAN ────────────────
            ColorLog("\n[DH HANDSHAKE] Inițiez schimbul de chei Diffie-Hellman...", ConsoleColor.Yellow);
            aesKey = DHHandshake.Execute(stream, "SERVER", out string dhLog);
            ColorLog(dhLog, ConsoleColor.DarkYellow);
            ColorLog("[DH HANDSHAKE] ✓ Cheie AES negociată cu succes!\n", ConsoleColor.Green);
            ColorLog("─────────────────────────────────────────────────────────", ConsoleColor.DarkGray);
            ColorLog("[SERVER] Sesiune securizată activă. Poți scrie mesaje.\n", ConsoleColor.Cyan);

            // Thread pentru recepție mesaje
            var receiveThread = new Thread(ReceiveMessages);
            receiveThread.IsBackground = true;
            receiveThread.Start();

            // Thread principal: trimitere mesaje
            while (true)
            {
                string? input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input)) continue;
                if (input.Equals("/exit", StringComparison.OrdinalIgnoreCase)) break;

                SendMessage(input, "SERVER");
            }

            ColorLog("[SERVER] Sesiune încheiată.", ConsoleColor.Red);
        }

        static void SendMessage(string plaintext, string sender)
        {
            if (stream == null || aesKey == null) return;

            try
            {
                // 1. Criptare AES (IV aleatoriu nou pentru fiecare mesaj)
                var (ciphertext, iv) = CryptoHelper.EncryptAES(plaintext, aesKey);

                // 2. Calcul Hash SHA-256 pentru integritate
                byte[] hash = CryptoHelper.ComputeHash(ciphertext);

                // 3. Construim pachetul securizat
                var packet = new SecurePacket
                {
                    IV = iv,
                    Ciphertext = ciphertext,
                    Hash = hash,
                    Sender = sender
                };

                // 4. Serializăm și trimitem
                byte[] data = packet.Serialize();
                stream.Write(data, 0, data.Length);
                stream.Flush();

                // 5. Logging explicit conform cerințelor
                lock (consoleLock)
                {
                    ColorLog($"\n[Trimis - TEXT CLAR]: {plaintext}", ConsoleColor.White);
                    ColorLog($"[Trimis - IV (hex)]:  {CryptoHelper.ToHex(iv)}", ConsoleColor.DarkCyan);
                    ColorLog($"[Trimis - CRIPTAT (Base64)]: {CryptoHelper.ToBase64(ciphertext)}", ConsoleColor.DarkYellow);
                    ColorLog($"[Trimis - HASH SHA-256]: {CryptoHelper.ToHex(hash)}", ConsoleColor.DarkMagenta);
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {
                ColorLog($"[EROARE] Trimitere eșuată: {ex.Message}", ConsoleColor.Red);
            }
        }

        static void ReceiveMessages()
        {
            if (stream == null || aesKey == null) return;

            try
            {
                while (true)
                {
                    // 1. Deserializăm pachetul
                    SecurePacket packet = SecurePacket.Deserialize(stream);

                    // 2. VERIFICARE INTEGRITATE SHA-256
                    bool integrityOk = CryptoHelper.VerifyHash(packet.Ciphertext, packet.Hash);

                    lock (consoleLock)
                    {
                        ColorLog($"\n[Primit de la: {packet.Sender}]", ConsoleColor.Cyan);
                        ColorLog($"[Primit - IV (hex)]:  {CryptoHelper.ToHex(packet.IV)}", ConsoleColor.DarkCyan);
                        ColorLog($"[Primit - CRIPTAT (Base64)]: {CryptoHelper.ToBase64(packet.Ciphertext)}", ConsoleColor.DarkYellow);
                        ColorLog($"[Primit - HASH SHA-256]: {CryptoHelper.ToHex(packet.Hash)}", ConsoleColor.DarkMagenta);

                        if (!integrityOk)
                        {
                            // Pachetul a fost alterat în tranzit!
                            ColorLog("[EROARE INTEGRITATE] ✗ Hash-ul nu corespunde! Pachetul a fost RESPINS.", ConsoleColor.Red);
                            continue;
                        }

                        ColorLog($"[INTEGRITATE] ✓ Hash verificat cu succes.", ConsoleColor.Green);

                        // 3. Decriptare AES
                        string plaintext = CryptoHelper.DecryptAES(packet.Ciphertext, aesKey, packet.IV);
                        ColorLog($"[Primit - DECRIPTAT]: {plaintext}", ConsoleColor.White);
                        Console.WriteLine();
                    }
                }
            }
            catch (Exception ex)
            {
                ColorLog($"\n[SERVER] Conexiunea clientului a fost închisă: {ex.Message}", ConsoleColor.Red);
            }
        }

        static void ColorLog(string message, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        static void PrintBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════════╗");
            Console.WriteLine("║          SecureChat SERVER - Varianta 3              ║");
            Console.WriteLine("║   DH Key Exchange + AES-256-CBC + SHA-256 Integritate║");
            Console.WriteLine("╚══════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }
    }
}
