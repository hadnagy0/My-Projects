package org.example;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.SwingUtilities;

public class Graf
{
    private static void initUI() {
        JFrame f = new JFrame("Algoritmica Grafurilor");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MyPanel panel = new MyPanel();

        f.add(panel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton primButton = new JButton("Prim");
        primButton.addActionListener(e -> panel.runPrim());
        buttonPanel.add(primButton);

        JButton kruskalButton = new JButton("Kruskal");
        kruskalButton.addActionListener(e -> panel.runKruskal());
        buttonPanel.add(kruskalButton);

        f.add(buttonPanel, BorderLayout.SOUTH);

        f.setSize(500, 500);
        f.setVisible(true);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try{
                    panel.saveMatrixFile("graf.txt");
                    System.out.println("Matrica de adiacenta s-a salvat!");
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args)
    {
        //pornesc firul de executie grafic
        //fie prin implementarea interfetei Runnable, fie printr-un obiect
        //al clasei Thread
        SwingUtilities.invokeLater(new Runnable() //new Thread()
        {
            public void run()
            {
                initUI();
            }
        });
    }
}
