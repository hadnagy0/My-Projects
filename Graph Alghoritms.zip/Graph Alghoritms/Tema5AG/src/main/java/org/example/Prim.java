package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class Prim {
    public static List<Arc> run(Vector<Node> nodes, Vector<Arc> arcs) {
        List<Arc> mst = new ArrayList<>();
        int n = nodes.size();

        if (n == 0) {
            return mst;
        }

        Map<Node, Integer> idx = new HashMap<>();
        for (int i = 0; i < n; i++) {
            idx.put(nodes.get(i), i);
        }

        //lista de adiacenta
        List<List<Arc>> adj = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            adj.add(new ArrayList<>());
        }

        for (Arc arc : arcs) {

            Integer u = idx.get(arc.getStartNode());
            Integer v = idx.get(arc.getEndNode());

            if (u == null || v == null)
                continue;

            adj.get(u).add(arc);
            adj.get(v).add(arc);
        }

        int[] vCost = new int[n]; //cost min de conectare la MST
        Arc[] e = new Arc[n];     //arcul real care da costul
        boolean[] inMST = new boolean[n];//daca nodul e in MST

        final int INF = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            vCost[i] = INF;
            inMST[i] = false;
            e[i] = null;
        }

        vCost[0] = 0;

        for (int count = 0; count < n; count++) {

            int y = -1;
            int min = INF;

            //se selecteaza nodul cu costul minim de conectare la MST
            for (int i = 0; i < n; i++) {
                if (!inMST[i] && vCost[i] < min) {
                    min = vCost[i];
                    y = i;
                }
            }

            if (y == -1)
                break;

            inMST[y] = true;

            if (y != 0 && e[y] != null) {
                mst.add(e[y]);
            }

            //relaxare
            for (Arc arc : adj.get(y)) {

                Integer uIdx = idx.get(arc.getStartNode());
                Integer vIdx = idx.get(arc.getEndNode());

                if (uIdx == null || vIdx == null)
                    continue;

                //verificam vecinul nodului y este start sau end
                int neighbor = (uIdx == y) ? vIdx : uIdx;

                if (!inMST[neighbor] && arc.getCost() < vCost[neighbor]) {
                    vCost[neighbor] = arc.getCost();
                    e[neighbor] = arc;
                }
            }
        }

        return mst;
    }
}
