package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class Kruskal {
    public static List<Arc> run(Vector<Node> nodes, Vector<Arc> arcs) {
        List<Arc> mst = new ArrayList<>();
        int n = nodes.size();
        if (n == 0) {
            return mst;
        }

        Map<Node, Integer> idx = new HashMap<>();
        for (int i = 0; i < n; i++) {
            idx.put(nodes.get(i), i);
        }

        List<Arc> sortedArcs = Sortare.sorteazaArce(arcs);

        //Disjoint Set Union (DSU) / structura pentru union si find
        int[] parent = new int[n];
        int[] rank = new int[n];


        for (int i = 0; i < n; i++) {
            parent[i] = i;
            rank[i] = 0;
        }


        java.util.function.IntUnaryOperator find = new java.util.function.IntUnaryOperator() {
            @Override
            public int applyAsInt(int x) {
                int root = x;
                //cauata radacina
                while (parent[root] != root) {
                    root = parent[root];
                }
                //compresia drumului: toate nodurile de pe drumul initial sun re-legate la radacina
                while (parent[x] != root) {
                    int next = parent[x];
                    parent[x] = root;
                    x = next;
                }
                return root;
            }
        };

        java.util.function.BiConsumer<Integer, Integer> union = new java.util.function.BiConsumer<Integer, Integer>() {
            @Override
            public void accept(Integer a, Integer b) {
                int ra = find.applyAsInt(a);
                int rb = find.applyAsInt(b);

                if (ra == rb)
                    return;//seturile sunt deja unite

                //uneste seturile dupa rang, ala cu rang mai mic devine aubarbore
                if (rank[ra] < rank[rb]) {
                    parent[ra] = rb;
                } else if (rank[ra] > rank[rb]) {
                    parent[rb] = ra;
                } else {
                    parent[rb] = ra;
                    rank[ra]++;
                }
            }
        };

        for (Arc arc : sortedArcs) {

            //nodurile arcului
            Integer uIdx = idx.get(arc.getStartNode());
            Integer vIdx = idx.get(arc.getEndNode());

            if (uIdx == null || vIdx == null)
                continue;

            //radicini
            int ru = find.applyAsInt(uIdx);
            int rv = find.applyAsInt(vIdx);

            if (ru != rv) {
                mst.add(arc);
                union.accept(ru, rv);
            }
        }

        return mst;
    }
}