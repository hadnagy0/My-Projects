package org.example;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.io.FileWriter;
import java.io.IOException;

public class MyPanel extends JPanel
{
    private int nodeNr = 1;
    private int node_diam = 30;
    private Vector<Node> listaNoduri;
    private Vector<Arc> listaArce;

    private Node selectedNode = null;
    private Point offset=null;

    private Node arcStartNode = null;
    private Point arcTempEnd = null;

    boolean isDragging = false;

    public MyPanel()
    {
        listaNoduri = new Vector<Node>();
        listaArce = new Vector<Arc>();

        // borderul panel-ului
        setBorder(BorderFactory.createLineBorder(Color.black));

        addMouseListener(new MouseAdapter() {
            //evenimentul care se produce la apasarea mousse-ului
            public void mousePressed(MouseEvent e) {
                boolean shiftDown = (e.getModifiersEx() & MouseEvent.SHIFT_DOWN_MASK) != 0;
                Node clickedNode = getNodeAt(e.getPoint());

                if(shiftDown && clickedNode != null){
                    selectedNode = clickedNode;
                    offset = new Point(e.getX() - selectedNode.getCoordX(), e.getY()- selectedNode.getCoordY());
                }else{
                    arcStartNode=clickedNode;
                }

            }

            //evenimentul care se produce la eliberarea mousse-ului
            public void mouseReleased(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode = null;
                    offset = null;
                } else if (arcStartNode != null) {
                    Node arcEndNode = getNodeAt(e.getPoint());
                    if (arcEndNode != null && arcEndNode != arcStartNode) {
                        String costStr = JOptionPane.showInputDialog("Introduceti costul arcului:");
                        try {
                            int cost = Integer.parseInt(costStr);
                            Arc arc = new Arc(arcStartNode, arcEndNode, cost);
                            listaArce.add(arc);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Cost invalid. Introduceti un numar intreg.");
                        }
                    }

                } else {
                    addNode(e.getX(), e.getY());
                }
                arcStartNode = null;
                arcTempEnd = null;
                repaint();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            //evenimentul care se produce la drag&drop pe mousse
            public void mouseDragged(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode.setCoordX(e.getX()-offset.x);
                    selectedNode.setCoordY(e.getY()-offset.y);
                    repaint();
                }else if(arcStartNode != null){
                    arcTempEnd=e.getPoint();
                    repaint();
                }
            }
        });
    }

    private Node getNodeAt(Point p) {
        for (Node n : listaNoduri) {
            int dx = n.getCoordX() + node_diam / 2 - p.x;
            int dy = n.getCoordY() + node_diam / 2 - p.y;
            int radius = node_diam / 2;
            if (dx * dx + dy * dy <= radius * radius) {
                return n;
            }
        }
        return null;
    }

    private Point getNodeCenterAt(Point p) {
        for (Node n : listaNoduri) {
            int centerX = n.getCoordX() + node_diam / 2;
            int centerY = n.getCoordY() + node_diam / 2;
            int dx = centerX - p.x;
            int dy = centerY - p.y;
            int radius = node_diam / 2;
            if (dx * dx + dy * dy <= radius * radius) {
                return new Point(centerX, centerY);
            }
        }
        return null;
    }

    //metoda care se apeleaza la eliberarea mouse-ului
    private void addNode(int x, int y) {
        int distMin=node_diam;
        for(Node n:listaNoduri){
            int dx=n.getCoordX()-x;
            int dy=n.getCoordY()-y;
            if(dx*dx+dy*dy<distMin*distMin)
                return;
        }

        //Daca nu este suprapunere
        Node node = new Node(x, y, nodeNr);
        listaNoduri.add(node);
        nodeNr++;
        repaint();
    }

    //se executa atunci cand apelam repaint()
    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);//apelez metoda paintComponent din clasa de baza
        //deseneaza arcele existente in lista
        for (Arc a : listaArce)
        {
            a.drawArc(g,node_diam);
        }
        //deseneaza arcul curent; cel care e in curs de desenare
        if (arcStartNode != null && arcTempEnd != null){
            Point start = new Point(arcStartNode.getCoordX() + node_diam / 2,
                    arcStartNode.getCoordY() + node_diam / 2);

            g.setColor(Color.RED);
            g.drawLine(start.x, start.y, arcTempEnd.x, arcTempEnd.y);

        }
        //deseneaza lista de noduri
        for (Node n : listaNoduri)
        {
            n.drawNode(g,node_diam);
        }
    }

    public void saveMatrixFile(String filename) throws IOException
    {
        int n=listaNoduri.size();
        int[][] matrix=new int[n][n];

        for(Arc a:listaArce)
        {
            int startIndex = listaNoduri.indexOf(a.getStartNode());
            int endIndex = listaNoduri.indexOf(a.getEndNode());

            if(startIndex!=-1 && endIndex!=-1) {
                matrix[startIndex][endIndex] = a.getCost();
                matrix[endIndex][startIndex] = a.getCost();
            }
        }

        FileWriter fw=new FileWriter(filename);
        fw.write(n+"\n");

        for(int i=0;i<n;i++) {
            for(int j=0;j<n;j++) {
                fw.write(matrix[i][j]+" ");
            }
            fw.write("\n");
        }
        fw.close();

    }

    public void runPrim() {
        resetArcColors();
        List<Arc> mst = Prim.run(listaNoduri, listaArce);
        int totalCost = 0;
        for (Arc arc : mst) {
            arc.setColor(Color.BLUE);
            totalCost += arc.getCost();
        }
        repaint();
        JOptionPane.showMessageDialog(this, "Algoritmul lui Prim a fost executat.\nCost total: " + totalCost);
    }

    public void runKruskal() {
        resetArcColors();
        List<Arc> mst = Kruskal.run(listaNoduri, listaArce);
        int totalCost = 0;
        for (Arc arc : mst) {
            arc.setColor(Color.BLUE);
            totalCost += arc.getCost();
        }
        repaint();
        JOptionPane.showMessageDialog(this, "Algoritmul lui Kruskal a fost executat.\nCost total: " + totalCost);
    }

    private void resetArcColors() {
        for (Arc arc : listaArce) {
            arc.setColor(Color.RED);
        }
        repaint();
    }
}
