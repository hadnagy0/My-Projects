package org.example;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

public class Sortare {
    public static List<Arc> sorteazaArce(Vector<Arc> arcs) {
        List<Arc> sortedArcs = new ArrayList<>(arcs);
        sortedArcs.sort(Comparator.comparingInt(Arc::getCost));
        return sortedArcs;
    }
}

