package org.example;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Arc
{
    private Node startN;
    private Node endN;
    private int cost;
    private Color color = Color.RED;

    public Arc(Node startN, Node endN, int cost)
    {
        this.startN = startN;
        this.endN = endN;
        this.cost = cost;
    }

    public void drawArc(Graphics g,int node_diam)
    {
        Point start = getNodeCenter(startN,node_diam);
        Point end = getNodeCenter(endN,node_diam);

        g.setColor(color);
        g.drawLine(start.x, start.y, end.x, end.y );

        // Display cost
        g.setColor(Color.BLACK);
        int midX = (start.x + end.x) / 2;
        int midY = (start.y + end.y) / 2;
        g.drawString(String.valueOf(cost), midX, midY);
    }
    private Point getNodeCenter(Node n,int node_diam) {
        return new Point(n.getCoordX()+node_diam/2,n.getCoordY()+node_diam/2);
    }

    public Point getStart(int node_diam) {
        return new Point(startN.getCoordX()+node_diam/2,startN.getCoordY()+node_diam/2);
    }

    public Point getEnd(int node_diam) {
        return new Point(endN.getCoordX() + node_diam / 2, endN.getCoordY() + node_diam / 2);
    }

    public Node getStartNode() {
        return startN;
    }

    public Node getEndNode() {
        return endN;
    }

    public int getCost() {
        return cost;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
