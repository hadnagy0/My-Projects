package org.example;

import java.util.List;
import javax.swing.Timer;
import java.awt.event.*;

public class ColorTimer {

    private MyPanel panel;
    private List<List<int[]>> paths;
    private int index = 0;

    public ColorTimer(MyPanel panel, List<List<int[]>> paths) {
        this.panel = panel;
        this.paths = paths;
    }

    public void start() {
        Timer t = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel.nextPath();
                index++;
                if (index == paths.size()) {
                    ((Timer) e.getSource()).stop();
                    javax.swing.JOptionPane.showMessageDialog(null, "Toate drumurile au fost afisate!");
                }
            }
        });
        t.setInitialDelay(2000);
        t.start();
    }
}
