package org.example;
import java.io.*;
import java.util.*;

public class MazeReader {

    private int rows;
    private int cols;
    private int[][] maze;
    private int startRow, startCol;
    private List<int[]> exits = new ArrayList<>();

    public MazeReader(String fileName) throws Exception {
        loadMaze(fileName);
        findExits();
    }

    private void loadMaze(String fileName) throws Exception {
        List<String> lines = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;

        while ((line = br.readLine()) != null) {
            lines.add(line.trim());
        }
        br.close();

        rows = lines.size();
        cols = lines.get(0).split(" ").length;
        maze = new int[rows][cols];

        for (int r = 0; r < rows; r++) {
            String[] tok = lines.get(r).split(" ");
            for (int c = 0; c < cols; c++) {
                if (tok[c].equals("$")) {
                    startRow = r;
                    startCol = c;
                    maze[r][c] = 1;
                } else {
                    maze[r][c] = Integer.parseInt(tok[c]);
                }
            }
        }
    }

    private void findExits() {
        for (int c = 0; c < cols; c++) {
            if (maze[0][c] == 1) exits.add(new int[]{0, c});
            if (maze[rows - 1][c] == 1) exits.add(new int[]{rows - 1, c});
        }
        for (int r = 0; r < rows; r++) {
            if (maze[r][0] == 1) exits.add(new int[]{r, 0});
            if (maze[r][cols - 1] == 1) exits.add(new int[]{r, cols - 1});
        }
    }

    public int[][] getMaze() { return maze; }
    public int getStartRow() { return startRow; }
    public int getStartCol() { return startCol; }
    public List<int[]> getExits() { return exits; }
    public int getRows() { return rows; }
    public int getCols() { return cols; }
}
