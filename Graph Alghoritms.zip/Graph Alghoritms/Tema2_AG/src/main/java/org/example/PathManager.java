package org.example;

import java.util.*;

public class PathManager {

    private BFS bfs;
    private MazeReader reader;

    public PathManager(BFS bfs, MazeReader reader) {
        this.bfs = bfs;
        this.reader = reader;
    }

    public List<List<int[]>> getAllPaths() {
        List<List<int[]>> res = new ArrayList<>();

        for (int[] ex : reader.getExits()) {
            if (hasPath(ex)) {
                res.add( reconstructPath(ex[0], ex[1]) );
            }
        }

        return res;
    }

    public boolean hasPath(int[] ex) {
        return bfs.predRow[ex[0]][ex[1]] != -1
                || (ex[0] == reader.getStartRow() && ex[1] == reader.getStartCol());
    }

    public List<int[]> reconstructPath(int r, int c) {
        List<int[]> path = new ArrayList<>();
        while (!(r == reader.getStartRow() && c == reader.getStartCol())) {
            path.add(new int[]{r, c});
            int pr = bfs.predRow[r][c];
            int pc = bfs.predCol[r][c];
            r = pr;
            c = pc;
        }
        path.add(new int[]{reader.getStartRow(), reader.getStartCol()});
        return path;
    }
}
