package org.example;

import java.util.*;

public class BFS {

    private int rows, cols;
    private int[][] maze;

    public int[][] predRow;
    public int[][] predCol;

    public BFS(int[][] maze) {
        this.maze = maze;
        this.rows = maze.length;
        this.cols = maze[0].length;
        predRow = new int[rows][cols];
        predCol = new int[rows][cols];

        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++) {
                predRow[r][c] = -1;
                predCol[r][c] = -1;
            }
    }

    public void process(int sr, int sc) {
        boolean[][] vis = new boolean[rows][cols];
        Queue<int[]> q = new LinkedList<>();

        q.add(new int[]{sr, sc});
        vis[sr][sc] = true;

        int[] dr = {-1, 1, 0, 0};
        int[] dc = {0, 0, -1, 1};

        while (!q.isEmpty()) {
            int[] v = q.poll();
            int r = v[0];
            int c = v[1];

            for (int d = 0; d < 4; d++) {
                int nr = r + dr[d];
                int nc = c + dc[d];

                if (nr >= 0 && nr < rows && nc >= 0 && nc < cols
                        && maze[nr][nc] == 1 && !vis[nr][nc]) {

                    vis[nr][nc] = true;
                    predRow[nr][nc] = r;
                    predCol[nr][nc] = c;
                    q.add(new int[]{nr, nc});
                }
            }
        }
    }
}
