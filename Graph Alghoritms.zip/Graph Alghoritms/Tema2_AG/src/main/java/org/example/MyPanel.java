package org.example;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;


public class MyPanel extends JPanel {

    private MazeReader reader;
    private BFS bfs;
    private PathManager pathManager;

    private int cellSize=40;
    private int [][] maze;
    private List<int[]>exits;
    private List<List<int[]>>paths;
    private int currentPathIndex=0;

    public MyPanel() {
        try {
            reader = new MazeReader("src/main/java/org/example/input.txt");
            maze = reader.getMaze();
            exits = reader.getExits();

            System.out.println("Start: "+reader.getStartRow()+","+reader.getStartCol());


            bfs = new BFS(maze);
            bfs.process(reader.getStartRow(), reader.getStartCol());

            pathManager = new PathManager(bfs, reader);
            paths = pathManager.getAllPaths();

            new ColorTimer(this, paths).start();

        } catch (Exception e) {
            System.out.println("Eroare: " + e);
        }

        setBorder(BorderFactory.createLineBorder(Color.black));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if(maze==null){return ;}

        for (int r = 0; r < reader.getRows(); r++) {
            for (int c = 0; c < reader.getCols(); c++) {

                if (maze[r][c] == 0) g.setColor(Color.BLACK);
                else g.setColor(Color.WHITE);

                g.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
                g.setColor(Color.GRAY);
                g.drawRect(c * cellSize, r * cellSize, cellSize, cellSize);
            }
        }

        // START
        g.setColor(Color.BLUE);
        g.fillRect(reader.getStartCol() * cellSize, reader.getStartRow() * cellSize, cellSize, cellSize);

        //Afiseaza dooar drumul curent
        if (currentPathIndex > 0) {
            List<int[]> path = paths.get(currentPathIndex - 1);
            for (int[] node : path) {
                g.setColor(Color.GREEN);
                g.fillRect(node[1] * cellSize, node[0] * cellSize, cellSize, cellSize);
            }
        }

        // marchez exit-uri care nu au drum
        for (int[] ex : exits) {
            if (!pathManager.hasPath(ex)) {
                g.setColor(Color.RED);
                g.fillRect(ex[1] * cellSize, ex[0] * cellSize, cellSize, cellSize);
            }
        }
    }

    public void nextPath() {
        if (currentPathIndex < paths.size()) {
            currentPathIndex++;
            repaint();
        }
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(reader.getCols()*cellSize, reader.getRows()*cellSize);
    }
}





