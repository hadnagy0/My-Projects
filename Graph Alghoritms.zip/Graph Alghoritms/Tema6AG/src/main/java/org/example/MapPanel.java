package org.example;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class MapPanel extends JPanel {
    private List<Node> nodes = new ArrayList<>();
    private List<Arc> arcs = new ArrayList<>();
    private List<List<Dijkstra.Edge>> adj = new ArrayList<>();
    private Map<Node, Integer> nodeToIndex = new HashMap<>();
    private Map<String, Arc> arcMap = new HashMap<>();
    private Node srcNode = null, dstNode = null;

    public MapPanel(String xmlFile) {
        try {
            long start = System.currentTimeMillis();
            MapLoader.MapData md = MapLoader.load(xmlFile);
            if (md.nodes.isEmpty())
                return;

            double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE, minLon = Double.MAX_VALUE, maxLon = -Double.MAX_VALUE;
            for (MapLoader.LNode ln : md.nodes) {
                minLat = Math.min(minLat, ln.lat); maxLat = Math.max(maxLat, ln.lat);
                minLon = Math.min(minLon, ln.lon); maxLon = Math.max(maxLon, ln.lon);
            }

            double latSpan = maxLat - minLat, lonSpan = maxLon - minLon;

            Map<Long, Node> idToObj = new HashMap<>(md.nodes.size());

            for (int i = 0; i < md.nodes.size(); i++) {
                MapLoader.LNode ln = md.nodes.get(i);
                //transformare coordonate geografice in pixeli
                int x = (int) ((ln.lon - minLon) / lonSpan * 900) + 50;
                int y = (int) ((maxLat - ln.lat) / latSpan * 700) + 50;

                Node n = new Node(x, y, i);
                nodes.add(n);
                nodeToIndex.put(n, i);
                idToObj.put(ln.id, n);
                adj.add(new ArrayList<>());
            }

            for (MapLoader.LEdge e : md.edges) {
                Node u = idToObj.get(e.from), v = idToObj.get(e.to);
                if (u != null && v != null) {
                    Arc a = new Arc(u, v, (int)Math.max(1, e.cost));
                    arcs.add(a);

                    int uIdx = nodeToIndex.get(u), vIdx = nodeToIndex.get(v);
                    adj.get(uIdx).add(new Dijkstra.Edge(vIdx, e.cost));
                    adj.get(vIdx).add(new Dijkstra.Edge(uIdx, e.cost));

                    arcMap.put(uIdx + "-" + vIdx, a);
                    arcMap.put(vIdx + "-" + uIdx, a);
                }
            }
            System.out.println("Incarcare si construire: " + (System.currentTimeMillis() - start) + " ms");
        } catch (Exception ex) { ex.printStackTrace(); }

        setBackground(Color.WHITE);
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Node nearest = findNearestNode(e.getPoint());
                if (nearest == null)
                    return;
                if (srcNode == null) {
                    srcNode = nearest;
                    repaint();
                }
                else if (dstNode == null) {
                    dstNode = nearest;
                    new Thread(() -> runAndShowPath()).start(); // rulăm în thread separat pentru a nu bloca UI-ul
                }
                else {
                    srcNode = null;
                    dstNode = null;

                    for (Arc a : arcs)
                        a.setColor(Color.GRAY); repaint(); }
            }
        });
    }

    private Node findNearestNode(Point p) {
        Node best = null;
        double minD2 = Double.MAX_VALUE;
        int px = p.x, py = p.y;
        for (Node n : nodes) {
            int dx = n.getCoordX() - px, dy = n.getCoordY() - py;
            double d2 = (double)dx*dx + (double)dy*dy;
            if (d2 < minD2) {
                minD2 = d2;
                best = n;
            }
        }
        return best;
    }

    private void runAndShowPath() {
        if (srcNode == null || dstNode == null)
            return;
        long start = System.currentTimeMillis();
        for (Arc a : arcs)
            a.setColor(Color.GRAY);

        Dijkstra.DijkstraResult res = Dijkstra.run(nodes.size(), adj, nodeToIndex.get(srcNode));

        // Reconstruim drumul de la destinatie la sursa
        int curr = nodeToIndex.get(dstNode);
        while (curr != -1 && res.prev[curr] != -1) {
            int p = res.prev[curr];
            Arc a = arcMap.get(p + "-" + curr);
            if (a != null)
                a.setColor(Color.RED);
            curr = p;
        }
        System.out.println("Drum calculat in: " + (System.currentTimeMillis() - start) + " ms");
        repaint();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Arc arc : arcs)
            arc.drawArc(g, 2);
        if (srcNode != null) {
            g.setColor(Color.BLUE); g.fillOval(srcNode.getCoordX()-6, srcNode.getCoordY()-6, 12, 12);
        }
        if (dstNode != null) {
            g.setColor(Color.MAGENTA); g.fillOval(dstNode.getCoordX()-6, dstNode.getCoordY()-6, 12, 12);
        }
    }
}