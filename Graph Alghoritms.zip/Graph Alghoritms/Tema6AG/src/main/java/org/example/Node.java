package org.example;
import java.awt.*;

public class Node {
    private int coordX, coordY, number;

    public Node(int coordX, int coordY, int number) {
        this.coordX = coordX;
        this.coordY = coordY;
        this.number = number;
    }

    public int getCoordX() { return coordX; }
    public int getCoordY() { return coordY; }
    public int getNumber() { return number; }

    public void setCoordX(int coordX) { this.coordX = coordX; }
    public void setCoordY(int coordY) { this.coordY = coordY; }

    public void drawNode(Graphics g, int node_diam) {
        g.fillOval(coordX, coordY, node_diam, node_diam);
    }
}