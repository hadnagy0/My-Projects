package org.example;
import java.awt.*;

public class Arc {
    private Node startN, endN;
    private Color color = Color.GRAY;
    private int cost;

    public Arc(Node startN, Node endN) {
        this.startN = startN; this.endN = endN; this.cost = 1;
    }

    public Arc(Node startN, Node endN, int cost) {
        this.startN = startN; this.endN = endN; this.cost = cost;
    }

    public int getCost() { return cost; }
    public Node getStartNode() { return startN; }
    public Node getEndNode() { return endN; }
    public void setColor(Color color) { this.color = color; }

    public void drawArc(Graphics g, int node_diam) {
        Graphics2D g2d = (Graphics2D) g;
        // Dezactivăm netezirea liniilor pentru performanță masivă
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setColor(color);
        g2d.drawLine(startN.getCoordX() + node_diam/2, startN.getCoordY() + node_diam/2,
                endN.getCoordX() + node_diam/2, endN.getCoordY() + node_diam/2);
    }
}