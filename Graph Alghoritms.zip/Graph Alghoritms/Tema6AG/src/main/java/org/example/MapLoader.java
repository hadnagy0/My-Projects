package org.example;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.File;
import java.io.FileInputStream;
import java.util.*;

public class MapLoader {
    public static class LNode {
        public final long id;
        public final double lat, lon;
        public LNode(long id, double lat, double lon) { this.id = id; this.lat = lat; this.lon = lon; }
    }
    public static class LEdge {
        public final long from, to;
        public final double cost;
        public LEdge(long from, long to, double cost) { this.from = from; this.to = to; this.cost = cost; }
    }
    public static class MapData {
        public final List<LNode> nodes;
        public final List<LEdge> edges;
        public MapData(List<LNode> nodes, List<LEdge> edges) { this.nodes = nodes; this.edges = edges; }
    }

    public static MapData load(String filename) throws Exception {
        File f = new File(filename);

        HashMap<Long, LNode> nodeMap = new HashMap<>(40000);
        List<LEdge> edges = new ArrayList<>(80000);

        //StAX
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        XMLEventReader reader = xmlInputFactory.createXMLEventReader(new FileInputStream(f));

        while (reader.hasNext()) {
            XMLEvent nextEvent = reader.nextEvent();

            if (nextEvent.isStartElement()) {
                StartElement startElement = nextEvent.asStartElement();
                String name = startElement.getName().getLocalPart();

                if ("node".equals(name)) {
                    long id = -1;
                    double lat = 0, lon = 0;
                    Iterator<Attribute> attributes = startElement.getAttributes();
                    while (attributes.hasNext()) {
                        Attribute attr = attributes.next();
                        String attrName = attr.getName().toString();
                        String attrValue = attr.getValue();

                        if ("id".equals(attrName))
                            id = Long.parseLong(attrValue);
                        else if ("latitude".equals(attrName))
                            lat = Double.parseDouble(attrValue);
                        else if ("longitude".equals(attrName))
                            lon = Double.parseDouble(attrValue);
                    }
                    if (id != -1)
                        nodeMap.put(id, new LNode(id, lat, lon));

                } else if ("arc".equals(name) || "edge".equals(name)) {
                    long from = -1, to = -1;
                    Iterator<Attribute> attributes = startElement.getAttributes();
                    while (attributes.hasNext()) {
                        Attribute attr = attributes.next();
                        String attrName = attr.getName().toString();
                        String attrValue = attr.getValue();

                        if ("from".equals(attrName))
                            from = Long.parseLong(attrValue);
                        else if ("to".equals(attrName))
                            to = Long.parseLong(attrValue);
                    }
                    if (from != -1 && to != -1) {
                        LNode n1 = nodeMap.get(from);
                        LNode n2 = nodeMap.get(to);

                        if (n1 != null && n2 != null) {
                            double cost = Math.sqrt(Math.pow(n1.lon - n2.lon, 2) + Math.pow(n1.lat - n2.lat, 2));
                            edges.add(new LEdge(from, to, cost));
                        }
                    }
                }
            }
        }
        reader.close();
        return new MapData(new ArrayList<>(nodeMap.values()), edges);
    }
}