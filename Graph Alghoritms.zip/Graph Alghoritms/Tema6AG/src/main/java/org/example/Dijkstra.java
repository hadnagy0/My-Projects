package org.example;
import java.util.*;

public class Dijkstra {
    public static class DijkstraResult {
        public final double[] dist;
        public final int[] prev;
        public DijkstraResult(double[] dist, int[] prev) { this.dist = dist; this.prev = prev; }
    }

    public static class NodeDist implements Comparable<NodeDist> {
        int id; double d;
        NodeDist(int id, double d) { this.id = id; this.d = d; }
        public int compareTo(NodeDist o) { return Double.compare(this.d, o.d); }
    }

    public static class Edge {
        int to; double cost;
        Edge(int to, double cost) { this.to = to; this.cost = cost; }
    }

    public static DijkstraResult run(int n, List<List<Edge>> adj, int startIdx) {
        double[] dist = new double[n];
        int[] prev = new int[n];

        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        Arrays.fill(prev, -1);
        dist[startIdx] = 0;

        PriorityQueue<NodeDist> pq = new PriorityQueue<>();
        pq.add(new NodeDist(startIdx, 0));

        while (!pq.isEmpty()) {
            NodeDist current = pq.poll();
            int u = current.id;

            if (current.d > dist[u])
                continue;

            for (Edge e : adj.get(u)) {
                if (dist[u] + e.cost < dist[e.to]) {
                    dist[e.to] = dist[u] + e.cost;
                    prev[e.to] = u;
                    pq.add(new NodeDist(e.to, dist[e.to]));
                }
            }
        }
        return new DijkstraResult(dist, prev);
    }
}