package org.example;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;

public class Graf
{
    private static void initUI() {
        JFrame f = new JFrame("Algoritmica Grafurilor - Harta");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MapPanel panel = new MapPanel("hartaLuxembourg.xml");

        f.add(panel, BorderLayout.CENTER);

        f.setSize(1000, 800);
        f.setVisible(true);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                // Nu salvăm matricea pentru harta Luxembourg (prea mare)
                System.out.println("Inchidere aplicatie...");
            }
        });
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                initUI();
            }
        });
    }
}
