package org.example;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Arc
{
    private Node startN;
    private Node endN;

    private boolean isDirected = true;
    public void setDirected(boolean directed){
        this.isDirected = directed;
    }

    public Arc(Node startN, Node endN)
    {
        this.startN = startN;
        this.endN = endN;
    }

    public void drawArc(Graphics g,int node_diam)
    {
        Point start = getNodeCenter(startN,node_diam);
        Point end = getNodeCenter(endN,node_diam);

            g.setColor(Color.RED);
            g.drawLine(start.x, start.y, end.x, end.y );

            if(isDirected) {

                int dx = end.x - start.x;
                int dy = end.y - start.y;
                double length = Math.sqrt(dx * dx + dy * dy);

                //sageata la marginea nodului
                double scale = (length - node_diam / 2.0) / length;
                int ModifEndX = (int) (start.x + dx * scale);
                int ModifEndY = (int) (start.y + dy * scale);

                double angle = Math.atan2(dy, dx);
                int arrowSize = Math.min(20, (int) length - node_diam / 2);
                int x1= (int) (ModifEndX - arrowSize * Math.cos(angle - Math.PI / 6));
                int y1 = (int) (ModifEndY - arrowSize * Math.sin(angle - Math.PI / 6));
                int x2 = (int) (ModifEndX - arrowSize * Math.cos(angle + Math.PI / 6));
                int y2 = (int) (ModifEndY - arrowSize * Math.sin(angle + Math.PI / 6));

                g.drawLine(end.x, end.y, x1, y1);
                g.drawLine(end.x, end.y, x2, y2);
            }

    }
    private Point getNodeCenter(Node n,int node_diam) {
         return new Point(n.getCoordX()+node_diam/2,n.getCoordY()+node_diam/2);
    }

    public Point getStart(int node_diam) {
        return new Point(startN.getCoordX()+node_diam/2,startN.getCoordY()+node_diam/2);
    }

    public Point getEnd(int node_diam) {
        return new Point(endN.getCoordX() + node_diam / 2, endN.getCoordY() + node_diam / 2);
    }
}
