package org.example;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Graf
{
    private static void choosegraphType(MyPanel panel) {
        int choice=javax.swing.JOptionPane.showOptionDialog(null,
                "Alege tipul grafului",
                "Tip graf",
                javax.swing.JOptionPane.YES_NO_OPTION,
                javax.swing.JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Orientat", "Neorientat"},
                "Orientat");

        if(choice==0){
            panel.setDirected(true);
            System.out.println("Graf orientat");
        }else{
            panel.setDirected(false);
            System.out.println("Graf neorientat");
        }

    }


    private static void initUI() {
        JFrame f = new JFrame("Algoritmica Grafurilor");
        //sa se inchida aplicatia atunci cand inchid fereastra
        MyPanel panel = new MyPanel();
        choosegraphType(panel);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add( panel);
        f.setSize(500, 500);
        f.setVisible(true);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try{
                    panel.saveMatrixFile("graf.txt");
                    System.out.println("Matrica de adiacenta s-a salvat!");
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args)
    {
        //pornesc firul de executie grafic
        //fie prin implementarea interfetei Runnable, fie printr-un obiect
        //al clasei Thread
        SwingUtilities.invokeLater(new Runnable() //new Thread()
        {
            public void run()
            {
                initUI();
            }
        });
    }
}
