package org.example;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Arc {
    private Node startN;
    private Node endN;
    private boolean isDirected;

    public Arc(Node startN, Node endN, boolean isDirected) {
        this.startN = startN;
        this.endN = endN;
        this.isDirected = isDirected;
    }

    public Node getStartNode() {
        return startN;
    }

    public Node getEndNode() {
        return endN;
    }

    public void drawArc(Graphics g, int node_diam) {
        Point start = getNodeCenter(startN);
        Point end = getNodeCenter(endN);

        int dx = end.x - start.x;
        int dy = end.y - start.y;
        double length = Math.sqrt(dx * dx + dy * dy);

        int ModifEndX;
        int ModifEndY;

        if (length > node_diam / 2.0) {
            double scale = (length - node_diam / 2.0) / length;
            ModifEndX = (int) (start.x + dx * scale);
            ModifEndY = (int) (start.y + dy * scale);
        } else {
            ModifEndX = end.x;
            ModifEndY = end.y;
        }

        if (isDirected) {
            g.setColor(Color.RED);
            g.drawLine(start.x, start.y, ModifEndX, ModifEndY);

            double angle = Math.atan2(dy, dx);
            int arrowSize = Math.min(20, (int) length - node_diam / 2);
            if (arrowSize < 0) arrowSize = 0;

            int x1 = (int) (ModifEndX - arrowSize * Math.cos(angle - Math.PI / 6));
            int y1 = (int) (ModifEndY - arrowSize * Math.sin(angle - Math.PI / 6));
            int x2 = (int) (ModifEndX - arrowSize * Math.cos(angle + Math.PI / 6));
            int y2 = (int) (ModifEndY - arrowSize * Math.sin(angle + Math.PI / 6));

            int[] xpoints = {ModifEndX, x1, x2};
            int[] ypoints = {ModifEndY, y1, y2};

            g.fillPolygon(xpoints, ypoints, 3);

        } else {
            g.setColor(Color.BLACK);
            g.drawLine(start.x, start.y, ModifEndX, ModifEndY);
        }
    }

    private Point getNodeCenter(Node n) {
        return new Point(n.getCoordX() + n.getWidth() / 2, n.getCoordY() + n.getHeight() / 2);
    }

    public Point getStart() {
        return getNodeCenter(startN);
    }

    public Point getEnd() {
        return getNodeCenter(endN);
    }
}