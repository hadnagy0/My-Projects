package org.example;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.BasicStroke;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.Collectors;

public class MyPanel extends JPanel
{
    private int nodeNr = 1;
    private int node_diam = 30;
    private Vector<Node> listaNoduri;
    private Vector<Arc> listaArce;

    private Node selectedNode = null;
    private Point offset=null;

    private Node arcStartNode = null;
    private Point arcTempEnd = null;

    boolean isDragging = false;

    private boolean isDirected;
    private JButton ccButton;
    private JButton ctcButton;
    private JButton topSortButton;
    private JButton shortestPathsButton;

    private final List<int[]> highlightedEdges = new ArrayList<>(); // pairs [u,v] indices
    private final Map<Integer, Color> originalNodeColors = new HashMap<>();


    private List<Color> componentColors;

    public MyPanel(boolean isDirected)
    {
        this.isDirected = isDirected;
        listaNoduri = new Vector<Node>();
        listaArce = new Vector<Arc>();

        // borderul panel-ului
        setBorder(BorderFactory.createLineBorder(Color.black));
        setLayout(null);

        ccButton = new JButton("Componente Conexe");
        ccButton.setBounds(10, 5, 150, 25);
        add(ccButton);
        ccButton.setEnabled(!isDirected);

        ctcButton = new JButton("Componente Tare Conexe");
        ctcButton.setBounds(170, 5, 200, 25);
        add(ctcButton);
        ctcButton.setEnabled(isDirected);

        topSortButton = new JButton("Sortare Topologica");
        topSortButton.setBounds(380, 5, 170, 25);
        add(topSortButton);
        topSortButton.setEnabled(isDirected);

        shortestPathsButton = new JButton("Drumuri din S");
        shortestPathsButton.setBounds(560, 5, 120, 25);
        add(shortestPathsButton);
        shortestPathsButton.setEnabled(isDirected);

        componentColors = new ArrayList<>();
        componentColors.add(Color.BLUE);
        componentColors.add(Color.GREEN);
        componentColors.add(Color.MAGENTA);
        componentColors.add(Color.CYAN);
        componentColors.add(Color.ORANGE);
        componentColors.add(Color.PINK);
        componentColors.add(Color.YELLOW);

        ccButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findConnectedComponents();
            }
        });

        ctcButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findStronglyConnectedComponents();
            }
        });

        topSortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performTopologicalSort();
            }
        });

        shortestPathsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performShortestPathsFromS();
            }
        });

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                boolean shiftDown = (e.getModifiersEx() & MouseEvent.SHIFT_DOWN_MASK) != 0;
                Node clickedNode = getNodeAt(e.getPoint());

                if(shiftDown && clickedNode != null){
                    selectedNode = clickedNode;
                    offset = new Point(e.getX() - selectedNode.getCoordX(), e.getY()- selectedNode.getCoordY());
                }else{
                    arcStartNode=clickedNode;
                }

            }

            public void mouseReleased(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode = null;
                    offset = null;
                } else if (arcStartNode != null) {
                    Node arcEndNode = getNodeAt(e.getPoint());
                    if (arcEndNode != null && arcEndNode != arcStartNode) {
                        Arc arc = new Arc(arcStartNode, arcEndNode, isDirected);
                        listaArce.add(arc);
                     }

            } else {
                    addNode(e.getX(), e.getY());
                }
                arcStartNode = null;
                arcTempEnd = null;
                repaint();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            //evenimentul care se produce la drag&drop pe mousse
            public void mouseDragged(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode.setCoordX(e.getX()-offset.x);
                    selectedNode.setCoordY(e.getY()-offset.y);
                    repaint();
                }else if(arcStartNode != null){
                    arcTempEnd=e.getPoint();
                    repaint();
                }
            }
        });
    }

    private Node getNodeAt(Point p) {
        for (Node n : listaNoduri) {
            int dx = n.getCoordX() + n.getWidth() / 2 - p.x;
            int dy = n.getCoordY() + n.getHeight() / 2 - p.y;
            int radiusX = n.getWidth() / 2;
            int radiusY = n.getHeight() / 2;
            if ((double)(dx*dx)/(radiusX*radiusX) + (double)(dy*dy)/(radiusY*radiusY) <= 1) {
                return n;
            }
        }
        return null;
    }

    private Point getNodeCenterAt(Point p) {
        for (Node n : listaNoduri) {
            int centerX = n.getCoordX() + n.getWidth() / 2;
            int centerY = n.getCoordY() + n.getHeight() / 2;
            int dx = centerX - p.x;
            int dy = centerY - p.y;
            int radiusX = n.getWidth() / 2;
            int radiusY = n.getHeight() / 2;
            if ((double)(dx*dx)/(radiusX*radiusX) + (double)(dy*dy)/(radiusY*radiusY) <= 1) {
                return new Point(centerX, centerY);
            }
        }
        return null;
    }

    private void addNode(int x, int y) {
        int distMin=node_diam;
        for(Node n:listaNoduri){
            int dx=n.getCoordX()-x;
            int dy=n.getCoordY()-y;
            if(dx*dx+dy*dy<distMin*distMin)
                return;
        }

        //Daca nu este suprapunere
        Node node = new Node(x, y, String.valueOf(nodeNr));
        listaNoduri.add(node);
        nodeNr++;
        repaint();
    }

    //se executa atunci cand apelam repaint()
    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);//apelez metoda paintComponent din clasa de baza
        g.drawString("Graf " + (isDirected ? "Orientat" : "Neorientat"), 380, 20);
        //deseneaza arcele existente in lista
        for (Arc a : listaArce)
        {
            a.drawArc(g,node_diam);
        }

        if (!highlightedEdges.isEmpty()) {
            Graphics2D g2 = (Graphics2D) g;
            Color oldColor = g2.getColor();
            Stroke oldStroke = g2.getStroke();

            try {
                g2.setColor(Color.GREEN);
                g2.setStroke(new BasicStroke(2.0f));

                for (int[] e : highlightedEdges) {
                    int u = e[0], v = e[1];

                    Node startN = listaNoduri.get(u);
                    Node endN   = listaNoduri.get(v);

                    Point start = getNodeCenter(startN);
                    Point end   = getNodeCenter(endN);

                    int dx = end.x - start.x;
                    int dy = end.y - start.y;
                    double length = Math.sqrt(dx*dx + dy*dy);

                    int ModifEndX, ModifEndY;

                    if (length > node_diam / 2.0) {
                        double scale = (length - node_diam / 2.0) / length;
                        ModifEndX = (int) (start.x + dx * scale);
                        ModifEndY = (int) (start.y + dy * scale);
                    } else {
                        ModifEndX = end.x;
                        ModifEndY = end.y;
                    }

                    g2.drawLine(start.x, start.y, ModifEndX, ModifEndY);

                    double angle = Math.atan2(dy, dx);
                    int arrowSize = Math.min(20, (int) length - node_diam / 2);
                    if (arrowSize < 0) arrowSize = 0;

                    int x1 = (int) (ModifEndX - arrowSize * Math.cos(angle - Math.PI / 6));
                    int y1 = (int) (ModifEndY - arrowSize * Math.sin(angle - Math.PI / 6));
                    int x2 = (int) (ModifEndX - arrowSize * Math.cos(angle + Math.PI / 6));
                    int y2 = (int) (ModifEndY - arrowSize * Math.sin(angle + Math.PI / 6));

                    int[] xpoints = { ModifEndX, x1, x2 };
                    int[] ypoints = { ModifEndY, y1, y2 };

                    g2.fillPolygon(xpoints, ypoints, 3);
                }
            }
            finally {
                g2.setColor(oldColor);
                g2.setStroke(oldStroke);
            }
        }

        //deseneaza arcul curent; cel care e in curs de desenare
        if (arcStartNode != null && arcTempEnd != null){
            Point start = new Point(arcStartNode.getCoordX() + arcStartNode.getWidth() / 2,
                    arcStartNode.getCoordY() + arcStartNode.getHeight() / 2);

            g.setColor(Color.RED);
            g.drawLine(start.x, start.y, arcTempEnd.x, arcTempEnd.y);

        }
        //deseneaza lista de noduri
        for (Node n : listaNoduri)
        {
            n.drawNode(g,node_diam);
        }
    }

    private Point getNodeCenter(Node n) {
        if (n == null) return null;
        int cx = n.getCoordX() + n.getWidth() / 2;
        int cy = n.getCoordY() + n.getHeight() / 2;
        return new Point(cx, cy);
    }

    private int[][] getAdjacencyMatrix() {
        int n = listaNoduri.size();
        int[][] matrix = new int[n][n];

        for (Arc a : listaArce) {
            int startIndex = listaNoduri.indexOf(a.getStartNode());
            int endIndex = listaNoduri.indexOf(a.getEndNode());

            if (startIndex != -1 && endIndex != -1) {
                matrix[startIndex][endIndex] = 1;
                if (!isDirected) {
                    matrix[endIndex][startIndex] = 1;
                }
            }
        }
        return matrix;
    }

    private void findConnectedComponents() {
        int[][] adjMatrix = getAdjacencyMatrix();
        ConnectedComponents cc = new ConnectedComponents(adjMatrix);
        cc.findComponents();
        int[] components = cc.getComponents();
        int numComponents = cc.getComponentCount();

        for (int i = 0; i < listaNoduri.size(); i++) {
            Node node = listaNoduri.get(i);
            int componentId = components[i];
            if (componentId != -1) {
                node.setColor(componentColors.get(componentId % componentColors.size()));
            } else {
                node.setColor(Color.RED); // culoare implicita daca nu face parte din nicio componenta
            }
        }
        repaint();
        JOptionPane.showMessageDialog(this, "Numarul de componente conexe: " + numComponents);
    }

    private void findStronglyConnectedComponents() {
        int[][] adjMatrix = getAdjacencyMatrix();
        if (adjMatrix.length == 0) {
            JOptionPane.showMessageDialog(this, "Graful este gol.");
            return;
        }

        CTC ctc = new CTC(adjMatrix);
        ctc.findStronglyConnectedComponents();
        List<List<Integer>> scc = ctc.getStronglyConnectedComponents();
        int[] componentMapping = ctc.getComponentMapping();

        Vector<Node> originalNodes = new Vector<>(listaNoduri);
        Vector<Arc> originalArcs = new Vector<>(listaArce);

        listaNoduri.clear();
        listaArce.clear();
        nodeNr = 1;

        int panelWidth = getWidth();
        int panelHeight = getHeight();
        int centerX = panelWidth / 2;
        int centerY = panelHeight / 2;
        int radius = Math.min(centerX, centerY) - 80;

        for (int i = 0; i < scc.size(); i++) {
            double angle = 2 * Math.PI * i / scc.size();
            int x = (int) (centerX + radius * Math.cos(angle));
            int y = (int) (centerY + radius * Math.sin(angle));

            String label = scc.get(i).stream()
                    .map(nodeIndex -> originalNodes.get(nodeIndex).getLabel())
                    .collect(Collectors.joining(","));

            Node newNode = new Node(x, y, "{" + label + "}");
            newNode.setColor(componentColors.get(i % componentColors.size()));
            listaNoduri.add(newNode);
        }

        for (Arc arc : originalArcs) {
            int startNodeIndex = originalNodes.indexOf(arc.getStartNode());
            int endNodeIndex = originalNodes.indexOf(arc.getEndNode());

            if (startNodeIndex != -1 && endNodeIndex != -1) {
                int startComponent = componentMapping[startNodeIndex];
                int endComponent = componentMapping[endNodeIndex];

                if (startComponent != -1 && endComponent != -1 && startComponent != endComponent) {
                    Node startNode = listaNoduri.get(startComponent);
                    Node endNode = listaNoduri.get(endComponent);

                    boolean arcExists = false;
                    for (Arc existingArc : listaArce) {
                        if (existingArc.getStartNode() == startNode && existingArc.getEndNode() == endNode) {
                            arcExists = true;
                            break;
                        }
                    }
                    if (!arcExists) {//adaugam arcul doar daca nu exista deja
                        listaArce.add(new Arc(startNode, endNode, true));
                    }
                }
            }
        }

        repaint();
        JOptionPane.showMessageDialog(this, "Numarul de componente tare conexe: " + scc.size());
    }

    private void performTopologicalSort() {
        int[][] adjMatrix = getAdjacencyMatrix();
        int n = adjMatrix.length;
        if (n == 0) {
            JOptionPane.showMessageDialog(this, "Graful este gol.");
            return;
        }

        TopologicalSort ts = new TopologicalSort(adjMatrix);
        List<Integer> sorted = ts.sort();

        if (sorted == null) {
            JOptionPane.showMessageDialog(this, "Graful contine cicluri. Sortare topologica imposibila.");
            System.out.println("Topological sort: impossible (cycle detected).");
            return;
        }

        String orderLabels = sorted.stream()
                .map(i -> listaNoduri.get(i).getLabel())
                .collect(Collectors.joining(" -> "));
        System.out.println("Topological order: " + orderLabels);
        JOptionPane.showMessageDialog(this, "Sortare topologica: " + orderLabels);

        int panelWidth = getWidth();
        int panelHeight = getHeight();
        int count = sorted.size();
        if (count > 0) {
            int spacing = panelWidth / (count + 1);
            int y = panelHeight / 2;
            for (int i = 0; i < count; i++) {
                Node node = listaNoduri.get(sorted.get(i));
                int newX = spacing * (i + 1) - node.getWidth() / 2;
                int newY = y - node.getHeight() / 2;
                node.setCoordX(newX);
                node.setCoordY(newY);
            }

            listaArce.clear();
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (adjMatrix[i][j] == 1) {
                        Node start = listaNoduri.get(i);
                        Node end = listaNoduri.get(j);
                        listaArce.add(new Arc(start, end, true));
                    }
                }
            }

            repaint();
        }
    }

    private void performShortestPathsFromS() {
        int[][] adjMatrix = getAdjacencyMatrix();
        int n = adjMatrix.length;
        if (n == 0) {
            JOptionPane.showMessageDialog(this, "Graful este gol.");
            return;
        }

        String input = JOptionPane.showInputDialog(this, "Introduceti nodul sursa (eticheta):");
        if (input == null || input.trim().isEmpty()) return;
        String sourceLabel = input.trim();

        int sourceIndex = -1;
        for (int i = 0; i < listaNoduri.size(); i++) {
            if (listaNoduri.get(i).getLabel().equals(sourceLabel)) {
                sourceIndex = i;
                break;
            }
        }
        if (sourceIndex == -1) {
            JOptionPane.showMessageDialog(this, "Nod sursa invalid.");
            return;
        }

        CTC ctc = new CTC(adjMatrix);
        ctc.findStronglyConnectedComponents();
        List<List<Integer>> scc = ctc.getStronglyConnectedComponents();

        boolean hasCycle = false;
        for (List<Integer> comp : scc) {
            if (comp.size() > 1) {
                hasCycle = true;
                break;
            }
            if (comp.size() == 1) {
                int v = comp.get(0);
                if (adjMatrix[v][v] != 0) {
                    hasCycle = true;
                    break;
                }
            }
        }

        if (hasCycle) {
            JOptionPane.showMessageDialog(this, "Graful contine circuite (are componente tare-conexe de dimensiune >1). Operatie intrerupta.");
            return;
        }

        TopologicalSort ts = new TopologicalSort(adjMatrix);
        List<Integer> topo = ts.sort();
        if (topo == null) {
            JOptionPane.showMessageDialog(this, "Graful contine cicluri. Sortare topologica imposibila.");
            return;
        }

        DAGShortestPaths.Result res = DAGShortestPaths.computeShortestPaths(adjMatrix, sourceIndex, topo);
        int[] parents = res.parents;
        int[] dist = res.distances;

        for (int target = 0; target < n; target++) {

            if (target == sourceIndex) {
                continue;
            }

            if (dist[target] == DAGShortestPaths.INF) {
                JOptionPane.showMessageDialog(this, "Nu exista drum de la " + sourceLabel + " la " + listaNoduri.get(target).getLabel());
                continue;
            }

            ArrayList<Integer> pathNodes = new ArrayList<>();
            ArrayList<int[]> pathEdges = new ArrayList<>();
            int cur = target;
            while (cur != sourceIndex && cur != -1) {
                pathNodes.add(0, cur);
                int p = parents[cur];
                if (p != -1) {
                    pathEdges.add(0, new int[]{p, cur});
                }
                cur = p;
            }
            if (cur == sourceIndex) {
                pathNodes.add(0, sourceIndex);
            }

            if (pathNodes.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nu exista drum de la " + sourceLabel + " la " + listaNoduri.get(target).getLabel());
                continue;
            }

            originalNodeColors.clear();
            for (int idx : pathNodes) {
                Node node = listaNoduri.get(idx);
                originalNodeColors.put(idx, node.getColor());
                node.setColor(Color.GREEN);
            }
            highlightedEdges.clear();
            highlightedEdges.addAll(pathEdges);

            repaint();

            String pathStr = pathNodes.stream().map(i -> listaNoduri.get(i).getLabel()).collect(Collectors.joining(" -> "));
            JOptionPane.showMessageDialog(this, "Drum de la " + sourceLabel + " la " + listaNoduri.get(target).getLabel() + " (lungime " + dist[target] + "):\n" + pathStr);

            for (int idx : pathNodes) {
                Node node = listaNoduri.get(idx);
                Color orig = originalNodeColors.get(idx);
                if (orig != null) node.setColor(orig);
            }
            highlightedEdges.clear();
            repaint();
        }

        JOptionPane.showMessageDialog(this, "Afisare drumuri finalizata.");
    }


    public void saveMatrixFile(String filename) throws IOException
    {
        int n=listaNoduri.size();
        int[][] matrix=new int[n][n];

        for(Arc a:listaArce)
        {
            int startIndex = listaNoduri.indexOf(a.getStartNode());
            int endIndex = listaNoduri.indexOf(a.getEndNode());

            if(startIndex!=-1 && endIndex!=-1) {
                matrix[startIndex][endIndex] = 1;
                if(!isDirected)
                    matrix[endIndex][startIndex] = 1;
            }
        }

        FileWriter fw=new FileWriter(filename);
        fw.write(n+"\n");

        for(int i=0;i<n;i++) {
            for(int j=0;j<n;j++) {
                fw.write(matrix[i][j]+" ");
            }
            fw.write("\n");
        }
        fw.close();

    }
}
