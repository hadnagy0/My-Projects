package org.example;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Graf
{
    private static void initUI() {
        JFrame f = new JFrame("Algoritmica Grafurilor");

        Object[] options = {"Orientat", "Neorientat"};
        int choice = JOptionPane.showOptionDialog(f,
                "Alegeti tipul de graf:",
                "Tip Graf",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        boolean isDirected = (choice == JOptionPane.YES_OPTION);

        //sa se inchida aplicatia atunci cand inchid fereastra
        final MyPanel panel = new MyPanel(isDirected);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(panel);
        f.setSize(700, 500);
        f.setVisible(true);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                try{
                    panel.saveMatrixFile("graf.txt");
                    System.out.println("Matrica de adiacenta s-a salvat!");
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable() //new Thread()
        {
            public void run()
            {
                initUI();
            }
        });
    }
}
