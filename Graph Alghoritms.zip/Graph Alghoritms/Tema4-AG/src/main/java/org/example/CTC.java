package org.example;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Stack;


public class CTC {
    private final int[][] adjMatrix;
    private final int numNodes;
    private List<List<Integer>> stronglyConnectedComponents;
    private int[] componentMapping;

    public CTC(int[][] adjMatrix) {
        this.adjMatrix = adjMatrix;
        this.numNodes = adjMatrix.length;
        this.stronglyConnectedComponents = new ArrayList<>();
        this.componentMapping = new int[numNodes];
    }

    public void findStronglyConnectedComponents() {
        //PTDF(G)
        PTDF ptdf1 = new PTDF(adjMatrix);
        ptdf1.run();
        int[] finishingTimes = ptdf1.getT2();

        //sorteaza nodurile descrescator dupa timpii de finalizare
        List<Integer> nodeOrder = new ArrayList<>();
        for (int i = 0; i < numNodes; i++) {
            nodeOrder.add(i);
        }
        nodeOrder.sort(Comparator.comparingInt((Integer i) -> finishingTimes[i]).reversed());

        //inversare graf => G^-1
        int[][] transposedMatrix = transposeGraph();

        //aplica PTDF(G^-1)
        PTDF ptdf2 = new PTDF(transposedMatrix);
        ptdf2.run(nodeOrder);
        int[] parents = ptdf2.getParents();

        //Construim componentele tare conexe
        boolean[] visited = new boolean[numNodes];
        int componentIndex = 0;
        for (int i = 0; i < numNodes; i++) {
            if (parents[i] == -1) { // nod rădăcină
                List<Integer> currentComponent = new ArrayList<>();
                for (int j = 0; j < numNodes; j++) {
                    if (findRoot(j, parents) == i) {
                        currentComponent.add(j);
                    }
                }
                if (!currentComponent.isEmpty()) {
                    stronglyConnectedComponents.add(currentComponent);
                    for (int node : currentComponent) {
                        componentMapping[node] = componentIndex;
                    }
                    componentIndex++;
                }
            }
        }

        printComponents();
    }

    // Colectează nodurile dintr-o componentă tare conexă folosind DFS
    private void collectComponentNodes(int start, int[] parents, boolean[] visited, List<Integer> component) {
        Stack<Integer> st = new Stack<>();
        st.push(start);

        while (!st.isEmpty()) {
            int u = st.pop();

            // Dacă nodul nu a fost vizitat, îl adăugăm în componentă
            if (!visited[u]) {
                visited[u] = true;
                component.add(u);

                // Adaugă toți vecinii nevizitați care aparțin aceleiași componente
                for (int v = 0; v < numNodes; v++) {
                    if (!visited[v] && findRoot(v, parents) == u) {
                        st.push(v);
                    }
                }
            }
        }
    }

    private int[][] transposeGraph() {
        int[][] transposed = new int[numNodes][numNodes];
        for (int i = 0; i < numNodes; i++) {
            for (int j = 0; j < numNodes; j++) {
                transposed[i][j] = adjMatrix[j][i];
            }
        }
        return transposed;
    }

    private int findRoot(int node, int[] parents) {
        int current = node;
        while (parents[current] != -1) {
            current = parents[current];
        }
        return current;
    }

    private void printComponents() {
        System.out.println("\nComponente Tare Conexe (CTC):");
        for (int i = 0; i < stronglyConnectedComponents.size(); i++) {
            System.out.println("Componenta " + (i + 1) + ": " + stronglyConnectedComponents.get(i));
        }
    }

    public List<List<Integer>> getStronglyConnectedComponents() {
        return stronglyConnectedComponents;
    }

    public int[] getComponentMapping() {
        return componentMapping;
    }
}
