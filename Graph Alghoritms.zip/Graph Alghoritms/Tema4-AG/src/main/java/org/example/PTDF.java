package org.example;

import java.util.*;

public class PTDF {
    private final int[][] adjMatrix;
    private final int numNodes;
    private final int[] p;
    private final int[] t1;
    private final int[] t2;
    private int time;
    private int[] color;

    private static final int WHITE = 0;//U
    private static final int GRAY = 1;//V
    private static final int BLACK = 2;//W

    public PTDF(int[][] adjMatrix) {
        this.adjMatrix = adjMatrix;
        this.numNodes = adjMatrix.length;
        this.p = new int[numNodes];
        this.t1 = new int[numNodes];
        this.t2 = new int[numNodes];
        this.color = new int[numNodes];
    }

    public void run() {
        List<Integer> nodeOrder = new ArrayList<>();//ordinea naturala
        for (int i = 0; i < numNodes; i++) {
            nodeOrder.add(i);
        }
        run(nodeOrder);
    }

    public void run(List<Integer> nodeOrder) {
        // Initializare
        for (int i = 0; i < numNodes; i++) {
            p[i] = -1;
            t1[i] = Integer.MAX_VALUE;
            t2[i] = Integer.MAX_VALUE;
            color[i] = WHITE;
        }

        time = 0;

        for (int i : nodeOrder) {
            if (color[i] == WHITE) {
                Stack<Integer> V = new Stack<Integer>();
                V.push(i);//
                color[i] = GRAY;
                time++;
                t1[i] = time;
                p[i] = -1; // radacina arborelui DFS

                while (!V.isEmpty()) {
                    int x = V.peek();

                    Integer y = findUnvisitedNeighbor(x);

                    if (y != null) {
                        color[y] = GRAY;
                        V.push(y);
                        p[y] = x;
                        time++;
                        t1[y] = time;
                    } else { // nu are x vecini nevizitati
                        V.pop();
                        color[x] = BLACK; // x in W
                        time++;
                        t2[x] = time;
                    }
                }
            }
        }
        printResults();
    }

    private Integer findUnvisitedNeighbor(int u) {
        for (int v = 0; v < numNodes; v++) {
            if (adjMatrix[u][v] == 1 && color[v] == WHITE) {
                return v;
            }
        }
        return null;
    }

    public int[] getT2() {
        return t2;
    }

    public int[] getParents() {
        return p;
    }

    private void printResults() {
        System.out.println("PTDF Results:");
        System.out.println("Node | Parent | t1 (Discovery) | t2 (Finish)");
        System.out.println("---------------------------------------------");
        for (int i = 0; i < numNodes; i++) {
            String parentStr = (p[i] == -1) ? "null" : String.valueOf(p[i]);
            System.out.printf("%-4d | %-6s | %-14d | %-10d\n", i, parentStr, t1[i], t2[i]);
        }
    }
}
