package org.example;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class TopologicalSort {
    private final int[][] adjMatrix;
    private final int numNodes;

    public TopologicalSort(int[][] adjMatrix) {
        this.adjMatrix = adjMatrix;
        this.numNodes = adjMatrix.length;
    }

    public List<Integer> sort() {
        if (numNodes == 0)
            return new ArrayList<>();

        int[] indegree = new int[numNodes];
        for (int u = 0; u < numNodes; u++) {
            for (int v = 0; v < numNodes; v++) {
                if (adjMatrix[u][v] != 0) {
                    indegree[v]++;
                }
            }
        }

        // Use a max-priority queue so we always pick the highest-index zero-indegree node first
        PriorityQueue<Integer> pq = new PriorityQueue<>(Comparator.reverseOrder());
        for (int i = 0; i < numNodes; i++) {
            if (indegree[i] == 0) pq.add(i);
        }

        List<Integer> result = new ArrayList<>(numNodes);
        while (!pq.isEmpty()) {
            int u = pq.poll();
            result.add(u);

            // iterate neighbors from high to low so higher-index neighbors become available earlier
            for (int v = numNodes - 1; v >= 0; v--) {
                if (adjMatrix[u][v] != 0) {
                    indegree[v]--;
                    if (indegree[v] == 0)
                        pq.add(v);
                }
            }
        }

        if (result.size() != numNodes) {
            return null;
        }
        return result;
    }
}
