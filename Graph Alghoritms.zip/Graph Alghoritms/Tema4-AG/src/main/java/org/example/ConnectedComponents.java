package org.example;

import java.util.*;

public class ConnectedComponents {

    private final int[][] adjMatrix;
    private final int numNodes;
    private int[] components;
    private int componentCount;

    public ConnectedComponents(int[][] adjMatrix) {
        this.adjMatrix = adjMatrix;
        this.numNodes = adjMatrix.length;
        this.components = new int[numNodes];
    }

    public void findComponents() {

        PTDF ptdf = new PTDF(adjMatrix);
        ptdf.run();

        int[] parents = ptdf.getParents();

        // Initializare
        Arrays.fill(components, -1);
        componentCount = 0;

        Map<Integer, Integer> rootToCompId = new HashMap<>();//Mapare radacina -> id componenta

        for (int node = 0; node < numNodes; node++) {
            // găsește rădăcina arborelui DFS pentru nodul curent
            int root = node;
            while (parents[root] != -1) {
                root = parents[root];
            }
            // Atribuie un ID unic componentei corespunzătoare rădăcinii
            Integer compId = rootToCompId.get(root);
            if (compId == null) {
                compId = componentCount;
                rootToCompId.put(root, compId);
                componentCount++;
            }
            components[node] = compId;
        }
    }

    public int[] getComponents() {
        return components;
    }

    public int getComponentCount() {
        return componentCount;
    }
}
