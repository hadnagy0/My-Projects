package org.example;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class Node
{
    private int coordX;
    private int coordY;
    private String label;
    private Color color;
    private int width;
    private final int height = 30;

    public Node(int coordX, int coordY, String label)
    {
        this.coordX = coordX;
        this.coordY = coordY;
        this.label = label;
        this.color = Color.RED;
        this.width = 30;
    }

    public int getCoordX() {
        return coordX;
    }
    public void setCoordX(int coordX) {
        this.coordX = coordX;
    }
    public int getCoordY() {
        return coordY;
    }
    public void setCoordY(int coordY) {
        this.coordY = coordY;
    }
    public String getLabel() {
        return label;
    }
    public void setLabel(String label) {
        this.label = label;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void drawNode(Graphics g, int node_diam)
    {
        Font font = new Font("TimesRoman", Font.BOLD, 15);
        g.setFont(font);

        // Adjust node width based on label length
        FontMetrics fm = g.getFontMetrics();
        this.width = fm.stringWidth(label) + 20;

        g.setColor(this.color);
        g.fillOval(coordX, coordY, width, height);
        g.setColor(Color.BLACK);
        g.drawOval(coordX, coordY, width, height);
        g.setColor(Color.WHITE);
        g.drawString(label, coordX + 10, coordY + 20);
    }
}
