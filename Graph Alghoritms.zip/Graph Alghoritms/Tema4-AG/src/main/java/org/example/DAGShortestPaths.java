package org.example;

import java.util.List;
import java.util.ArrayList;

public class DAGShortestPaths {

    public static final int INF = Integer.MAX_VALUE / 2;

    public static class Result {
        public final int[] parents;
        public final int[] distances;

        public Result(int[] parents, int[] distances) {
            this.parents = parents;
            this.distances = distances;
        }
    }

    public static Result computeShortestPaths(int[][] adjMatrix, int source, List<Integer> topoOrder) {
        int n = adjMatrix.length;
        if (n == 0) return new Result(new int[0], new int[0]);
        if (source < 0 || source >= n) throw new IllegalArgumentException("Invalid source index");

        // completează ordinea topologică dacă este necesar
        if (topoOrder == null) {
            topoOrder = new ArrayList<>(n);
            for (int i = 0; i < n; i++)
                topoOrder.add(i);
        } else if (topoOrder.size() != n) {
            boolean[] present = new boolean[n];
            for (int v : topoOrder) {
                if (v >= 0 && v < n)
                    present[v] = true;
            }
            for (int i = 0; i < n; i++) {
                if (!present[i])
                    topoOrder.add(i);
            }
        }

        int[] p = new int[n];
        int[] d = new int[n];

        // initializare
        for (int i = 0; i < n; i++) {
            p[i] = -1;
            d[i] = INF;
        }
        d[source] = 0;

        // găsește poziția sursei în ordinea topologică
        int U = -1;
        for (int i = 0; i < topoOrder.size(); i++) {
            if (topoOrder.get(i) == source) {
                U = i;
                break;
            }
        }
        if (U == -1) {

            return new Result(p, d);// sursa nu este în graf
        }

        // parcurge nodurile în ordinea topologică începând de la sursă
        for (int k = U; k < topoOrder.size(); k++) {
            int x = topoOrder.get(k);
            if (d[x] == INF) continue;
            for (int y = 0; y < n; y++) {
                if (adjMatrix[x][y] != 0) {
                    if (d[x] + 1 < d[y]) {
                        p[y] = x;
                        d[y] = d[x] + 1;
                    }
                }
            }
        }

        return new Result(p, d);// returnează părinții și distanțele
    }
}
