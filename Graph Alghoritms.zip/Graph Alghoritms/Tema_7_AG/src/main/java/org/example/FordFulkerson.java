package org.example;

import java.util.*;

public class FordFulkerson {
    private List<Node> nodes;
    private List<Arc> arcs;
    private Map<Node, Integer> nodeToIndex;
    private int[][] capacity;
    private int[][] flow;
    private int n;

    public FordFulkerson(List<Node> nodes, List<Arc> arcs) {
        this.nodes = new ArrayList<>(nodes);
        this.arcs = arcs;
        this.n = this.nodes.size();
        this.nodeToIndex = new HashMap<>();
        for (int i = 0; i < n; i++) {
            nodeToIndex.put(this.nodes.get(i), i);
        }

        this.capacity = new int[n][n];
        this.flow = new int[n][n];

        for (Arc arc : arcs) {
            int u = nodeToIndex.get(arc.getStartNode());
            int v = nodeToIndex.get(arc.getEndNode());
            this.capacity[u][v] = arc.getCapacity();
        }
    }

    public int run(Node source, Node sink) {
        int s = nodeToIndex.get(source);
        int t = nodeToIndex.get(sink);
        int totalFlow = 0;

        while (true) {
            int[] parent = new int[n];
            Arrays.fill(parent, -1);
            Queue<Integer> q = new LinkedList<>();

            q.add(s);
            parent[s] = s;

            while (!q.isEmpty()) {
                int u = q.poll();
                for (int v = 0; v < n; v++) {
                    if (parent[v] == -1 && capacity[u][v] - flow[u][v] > 0) {
                        parent[v] = u;
                        q.add(v);
                        if (v == t) break;
                    }
                }
                if (parent[t] != -1) break;
            }

            if (parent[t] == -1) {
                break;
            }

            int pathFlow = Integer.MAX_VALUE;
            for (int v = t; v != s; v = parent[v]) {
                int u = parent[v];
                pathFlow = Math.min(pathFlow, capacity[u][v] - flow[u][v]);
            }

            for (int v = t; v != s; v = parent[v]) {
                int u = parent[v];
                flow[u][v] += pathFlow;
                flow[v][u] -= pathFlow;
            }

            totalFlow += pathFlow;
        }
        return totalFlow;
    }

    public int getFlow(Arc arc) {
        int u = nodeToIndex.get(arc.getStartNode());
        int v = nodeToIndex.get(arc.getEndNode());
        return flow[u][v];
    }


    public List<Node> getNodesReachableFromSourceInResidualGraph(Node sourceNode) {
        List<Node> reachableNodes = new ArrayList<>();
        boolean[] visited = new boolean[n];
        int s = nodeToIndex.get(sourceNode);

        Queue<Integer> q = new LinkedList<>();
        q.add(s);
        visited[s] = true;

        while (!q.isEmpty()) {
            int u = q.poll();
            for (int v = 0; v < n; v++) {
                if (!visited[v] && capacity[u][v] - flow[u][v] > 0) {
                    visited[v] = true;
                    q.add(v);
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                reachableNodes.add(nodes.get(i));
            }
        }
        return reachableNodes;
    }
}

