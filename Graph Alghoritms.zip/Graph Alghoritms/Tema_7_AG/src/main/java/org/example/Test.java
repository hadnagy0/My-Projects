package org.example;

import java.util.*;

public class Test {
    private List<Node> nodes;
    private List<Arc> originalArcs;
    private Map<Node, Integer> nodeToIndex;
    private int n;
    private int[][] flow;
    private int[][] capacity;
    private int[][] cost;

    public Test(List<Node> nodes, List<Arc> arcs) {
        this.nodes = new ArrayList<>(nodes);
        this.originalArcs = arcs;
        this.n = this.nodes.size();
        this.nodeToIndex = new HashMap<>();
        for (int i = 0; i < n; i++) {
            nodeToIndex.put(this.nodes.get(i), i);
        }

        this.capacity = new int[n][n];
        this.cost = new int[n][n];
        this.flow = new int[n][n];

        for (Arc arc : arcs) {
            int u = nodeToIndex.get(arc.getStartNode());
            int v = nodeToIndex.get(arc.getEndNode());
            this.capacity[u][v] = arc.getCapacity();
            this.cost[u][v] = arc.getCost();
            this.flow[u][v] = arc.getFlow(); // Use initial flow if provided
        }
    }

    public void run() {
        while (true) {
            List<List<int[]>> residualAdj = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                residualAdj.add(new ArrayList<>());
            }

            for (int u = 0; u < n; u++) {
                for (int v = 0; v < n; v++) {

                    if (flow[u][v] < capacity[u][v]) {
                        residualAdj.get(u).add(new int[]{v, cost[u][v]});
                    }
                    if (flow[u][v] > 0) {
                        residualAdj.get(v).add(new int[]{u, -cost[u][v]});
                    }
                }
            }

            Test2.Result bfResult = Test2.run(n, residualAdj, -1);

            if (bfResult.nodeInCycle == -1) {
                break;
            }

            int[] p = bfResult.predecessors;
            List<Integer> cycle = new ArrayList<>();
            int curr = bfResult.nodeInCycle;

            for (int i = 0; i < n; ++i) {
                if (curr == -1) {
                    return;
                }
                curr = p[curr];
            }

            int cycleNode = curr;
            do {
                cycle.add(cycleNode);
                cycleNode = p[cycleNode];
            } while (cycleNode != curr);
            cycle.add(curr);
            Collections.reverse(cycle);//in ordine corecta

            int delta = Integer.MAX_VALUE;
            for (int i = 0; i < cycle.size() - 1; i++) {
                int u = cycle.get(i);
                int v = cycle.get(i + 1);

                if (capacity[u][v] > 0 && cost[u][v] == bfResult.distances[v] - bfResult.distances[u]) {
                    delta = Math.min(delta, capacity[u][v] - flow[u][v]);
                } else {
                    delta = Math.min(delta, flow[v][u]);
                }
            }

            if (delta == 0 || delta == Integer.MAX_VALUE) {
                break;
            }

            for (int i = 0; i < cycle.size() - 1; i++) {
                int u = cycle.get(i);
                int v = cycle.get(i + 1);

                if (capacity[u][v] > 0 && cost[u][v] == bfResult.distances[v] - bfResult.distances[u]) {
                    flow[u][v] += delta;
                } else {
                    flow[v][u] -= delta;
                }
            }
        }
    }

    public int getFlow(Arc arc) {
        int u = nodeToIndex.get(arc.getStartNode());
        int v = nodeToIndex.get(arc.getEndNode());
        return flow[u][v];
    }
}
