package org.example;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MyPanel extends JPanel
{
    private int nodeNr = 1;
    private int node_diam = 30;
    private Vector<Node> listaNoduri;
    private Vector<Arc> listaArce;

    private Node selectedNode = null;
    private Point offset=null;

    private Node arcStartNode = null;
    private Point arcTempEnd = null;

    boolean isDragging = false;

    public MyPanel()
    {
        listaNoduri = new Vector<Node>();
        listaArce = new Vector<Arc>();

        // borderul panel-ului
        setBorder(BorderFactory.createLineBorder(Color.black));

        addMouseListener(new MouseAdapter() {
            //evenimentul care se produce la apasarea mousse-ului
            public void mousePressed(MouseEvent e) {
                boolean shiftDown = (e.getModifiersEx() & MouseEvent.SHIFT_DOWN_MASK) != 0;
                Node clickedNode = getNodeAt(e.getPoint());

                if(shiftDown && clickedNode != null){
                    selectedNode = clickedNode;
                    offset = new Point(e.getX() - selectedNode.getCoordX(), e.getY()- selectedNode.getCoordY());
                }else{
                    arcStartNode=clickedNode;
                }

            }

            //evenimentul care se produce la eliberarea mousse-ului
            public void mouseReleased(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode = null;
                    offset = null;
                } else if (arcStartNode != null) {
                    Node arcEndNode = getNodeAt(e.getPoint());
                    if (arcEndNode != null && arcEndNode != arcStartNode) {
                        String capacityStr = JOptionPane.showInputDialog("Introduceti capacitatea arcului:");
                        String costStr = JOptionPane.showInputDialog("Introduceti costul arcului:");
                        String flowStr = JOptionPane.showInputDialog("Introduceti fluxul initial (optional, default 0):");
                        try {
                            int capacity = Integer.parseInt(capacityStr);
                            int cost = Integer.parseInt(costStr);
                            int flow = 0;
                            if (flowStr != null && !flowStr.trim().isEmpty()) {
                                flow = Integer.parseInt(flowStr);
                            }

                            if (flow > capacity) {
                                JOptionPane.showMessageDialog(null, "Fluxul initial nu poate depasi capacitatea.");
                                return;
                            }

                            Arc arc = new Arc(arcStartNode, arcEndNode, capacity, cost);
                            arc.setFlow(flow);
                            listaArce.add(arc);
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Date invalide. Introduceti numere intregi.");
                        }
                    }

                } else {
                    addNode(e.getX(), e.getY());
                }
                arcStartNode = null;
                arcTempEnd = null;
                repaint();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            //evenimentul care se produce la drag&drop pe mousse
            public void mouseDragged(MouseEvent e) {
                if (selectedNode != null) {
                    selectedNode.setCoordX(e.getX()-offset.x);
                    selectedNode.setCoordY(e.getY()-offset.y);
                    repaint();
                }else if(arcStartNode != null){
                    arcTempEnd=e.getPoint();
                    repaint();
                }
            }
        });
    }

    private Node getNodeAt(Point p) {
        for (Node n : listaNoduri) {
            int dx = n.getCoordX() + node_diam / 2 - p.x;
            int dy = n.getCoordY() + node_diam / 2 - p.y;
            int radius = node_diam / 2;
            if (dx * dx + dy * dy <= radius * radius) {
                return n;
            }
        }
        return null;
    }

    private Point getNodeCenterAt(Point p) {
        for (Node n : listaNoduri) {
            int centerX = n.getCoordX() + node_diam / 2;
            int centerY = n.getCoordY() + node_diam / 2;
            int dx = centerX - p.x;
            int dy = centerY - p.y;
            int radius = node_diam / 2;
            if (dx * dx + dy * dy <= radius * radius) {
                return new Point(centerX, centerY);
            }
        }
        return null;
    }

    //metoda care se apeleaza la eliberarea mouse-ului
    private void addNode(int x, int y) {
        int distMin=node_diam;
        for(Node n:listaNoduri){
            int dx=n.getCoordX()-x;
            int dy=n.getCoordY()-y;
            if(dx*dx+dy*dy<distMin*distMin)
                return;
        }

        //Daca nu este suprapunere
        Node node = new Node(x, y, nodeNr);
        listaNoduri.add(node);
        nodeNr++;
        repaint();
    }

    //se executa atunci cand apelam repaint()
    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);//apelez metoda paintComponent din clasa de baza
        //deseneaza arcele existente in lista
        for (Arc a : listaArce)
        {
            a.drawArc(g,node_diam);
        }
        //deseneaza arcul curent; cel care e in curs de desenare
        if (arcStartNode != null && arcTempEnd != null){
            Point start = new Point(arcStartNode.getCoordX() + node_diam / 2,
                    arcStartNode.getCoordY() + node_diam / 2);

            g.setColor(Color.RED);
            g.drawLine(start.x, start.y, arcTempEnd.x, arcTempEnd.y);

        }
        //deseneaza lista de noduri
        for (Node n : listaNoduri)
        {
            n.drawNode(g,node_diam);
        }
    }

    public void runFordFulkerson() {
        resetFlowsAndColors();

        String sourceStr = JOptionPane.showInputDialog("Introduceti nodul sursa (numar):");
        String sinkStr = JOptionPane.showInputDialog("Introduceti nodul destinatie (numar):");

        try {
            int sourceId = Integer.parseInt(sourceStr);
            int sinkId = Integer.parseInt(sinkStr);

            Node sourceNode = findNodeById(sourceId);
            Node sinkNode = findNodeById(sinkId);

            if (sourceNode == null || sinkNode == null) {
                JOptionPane.showMessageDialog(this, "Sursa sau destinatia nu au fost gasite.");
                return;
            }

            FordFulkerson ff = new FordFulkerson(listaNoduri, listaArce);
            int maxFlow = ff.run(sourceNode, sinkNode);

            // Update flows on arcs
            for (Arc arc : listaArce) {
                arc.setFlow(ff.getFlow(arc));
            }

            // Highlight min-cut
            List<Node> reachable = ff.getNodesReachableFromSourceInResidualGraph(sourceNode);
            for (Arc arc : listaArce) {
                if (reachable.contains(arc.getStartNode()) && !reachable.contains(arc.getEndNode())) {
                    arc.setColor(Color.BLUE); // Min-cut arcs
                }
            }

            repaint();
            JOptionPane.showMessageDialog(this, "Algoritmul Ford-Fulkerson a fost executat.\nFlux Maxim: " + maxFlow);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID-uri invalide. Introduceti numere intregi.");
        }
    }

    /*
    public void runMinCostFlow() {
        resetFlowsAndColors();

        Test mcf = new Test(listaNoduri, listaArce);
        mcf.run();

        for (Arc arc : listaArce) {
            arc.setFlow(mcf.getFlow(arc));
        }

        repaint();
        JOptionPane.showMessageDialog(this, "Algoritmul de Flux de Cost Minim a fost executat.");
    }*/

    private Node findNodeById(int id) {
        for (Node node : listaNoduri) {
            if (node.getNumber() == id) {
                return node;
            }
        }
        return null;
    }

    private void resetFlowsAndColors() {
        for (Arc arc : listaArce) {
            arc.setFlow(0);
            arc.setColor(Color.RED);
        }
        repaint();
    }
}
