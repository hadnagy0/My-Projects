package org.example;

import java.util.*;

public class Test2 {

    public static class Result {
        public final double[] distances;
        public final int[] predecessors;
        public final int nodeInCycle; //detectare ciclu negativ

        public Result(double[] distances, int[] predecessors, int nodeInCycle) {
            this.distances = distances;
            this.predecessors = predecessors;
            this.nodeInCycle = nodeInCycle;
        }
    }


    public static Result run(int n, List<List<int[]>> adj, int sourceIndex) {
        double[] d = new double[n];
        int[] p = new int[n];
        Arrays.fill(d, Double.POSITIVE_INFINITY);
        Arrays.fill(p, -1);

        if (sourceIndex >= 0 && sourceIndex < n) {
            d[sourceIndex] = 0;
        }

        // Relax edges repeatedly
        for (int i = 0; i < n - 1; i++) {
            for (int u = 0; u < n; u++) {
                if (d[u] == Double.POSITIVE_INFINITY) continue;
                for (int[] edge : adj.get(u)) {
                    int v = edge[0];
                    int cost = edge[1];
                    if (d[v] > d[u] + cost) {
                        d[v] = d[u] + cost;
                        p[v] = u;
                    }
                }
            }
        }

        int nodeInCycle = -1;
        for (int u = 0; u < n; u++) {
            if (d[u] == Double.POSITIVE_INFINITY) continue;
            for (int[] edge : adj.get(u)) {
                int v = edge[0];
                int cost = edge[1];
                if (d[v] > d[u] + cost) {
                    nodeInCycle = v;
                    p[v] = u;
                    return new Result(d, p, nodeInCycle);
                }
            }
        }

        return new Result(d, p, -1);
    }
}
