package org.example;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.SwingUtilities;

public class Graf
{
    private static void initUI() {
        JFrame f = new JFrame("Algoritmica Grafurilor - Flux & Cost");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MyPanel panel = new MyPanel();

        f.add(panel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton ffButton = new JButton("Ford-Fulkerson");
        ffButton.addActionListener(e -> panel.runFordFulkerson());
        buttonPanel.add(ffButton);

        //JButton mcfButton = new JButton("Flux Cost Minim (Circuite Negative)");
        //mcfButton.addActionListener(e -> panel.runMinCostFlow());
        //buttonPanel.add(mcfButton);

        f.add(buttonPanel, BorderLayout.SOUTH);

        f.setSize(500, 500);
        f.setVisible(true);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {

            }
        });
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable() //new Thread()
        {
            public void run()
            {
                initUI();
            }
        });
    }
}
