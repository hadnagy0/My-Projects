# NotepadPlusPlus - WPF Application
## Aplicatie similara Notepad++ realizata in C# cu WPF (.NET 8)

---

## STRUCTURA PROIECTULUI

```
NotepadPlusPlus/
├── NotepadPlusPlus.csproj      # Fisierul proiect (.NET 8 WPF)
├── App.xaml                    # Resurse globale (teme, stiluri)
├── App.xaml.cs                 # Entry point aplicatie
├── MainWindow.xaml             # UI principal (meniu, toolbar, tab-uri, explorer)
├── MainWindow.xaml.cs          # Logica principala (toate functionalitatile)
├── TabData.cs                  # Model pentru tab-uri (nume, stare salvare, editor)
├── AboutWindow.xaml            # Fereastra About
├── AboutWindow.xaml.cs
├── InputDialog.xaml            # Dialog pentru input text (ex: New File)
└── InputDialog.xaml.cs
```

---

## CERINTE DE SISTEM

- **Windows 10/11** (WPF este exclusiv Windows)
- **.NET 8 SDK** – https://dotnet.microsoft.com/download/dotnet/8
- **Visual Studio 2022** (recomandat) sau VS Code cu extensia C#

---

## CUM SA RULEZI IN VISUAL STUDIO

1. Deschide **Visual Studio 2022**
2. **File → Open → Project/Solution**
3. Selecteaza `NotepadPlusPlus.csproj`
4. Apasa **F5** sau butonul **▶ Start** pentru a rula

## CUM SA RULEZI DIN LINIA DE COMANDA

```bash
cd NotepadPlusPlus
dotnet run
```

---

## FUNCTIONALITATI IMPLEMENTATE

### 1. Tab-uri
- La deschiderea aplicatiei se creeaza automat un tab gol (File 1, File 2, ...)
- Fiecare tab afiseaza **numele fisierului** deschis
- Fisierele **nesalvate** au un **punct portocaliu** si numele scris cu **portocaliu**
- Buton **✕** pe fiecare tab pentru inchidere

### 2. File → New File (Ctrl+N)
- Creeaza un tab nou gol cu nume automat (File 1, File 2 etc.)

### 3. File → Open File... (Ctrl+O)
- Deschide dialog pentru a selecta fisiere
- Filtre: `.txt` implicit, dar si `All Files`
- Daca fisierul e deja deschis, selecteaza tab-ul existent

### 4. File → Save File (Ctrl+S)
- Salveaza fisierul curent; daca nu are cale, deschide Save As

### 5. File → Save File As... (Ctrl+Shift+S)
- Deschide dialog pentru alegerea caii si numelui

### 6. File → Close All Files
- Inchide toate tab-urile cu prompt pentru fisierele nesalvate

### 7. File → Exit
- Iesire din aplicatie (cu prompt salvare daca exista fisiere nesalvate)

### 8. Folder Explorer (Ctrl+E / View → Folder Explorer)
- Panou lateral cu structura arbore de directoare
- Directoarele se **expandeaza/colapeaza** cu click
- **Dublu-click** pe fisier → deschide intr-un tab nou

### 9. Context Menu pe directoare (click dreapta):
- **New File** – creeaza un fisier nou in directorul selectat (cu dialog pentru nume)
- **Copy Path** – copiaza calea in clipboard
- **Copy Folder** – copiaza folderul in memorie
- **Paste Folder** – lipeste folderul copiat (dezactivat daca nu exista niciunul copiat)

### 10. Search → Find... (Ctrl+F)
- Bara de cautare inline (sub toolbar)
- Cautare in tab curent sau in toate tab-urile (toggle din Search menu)
- **Enter** = cauta urmatoarea aparitie

### 11. Search → Replace... (Ctrl+H)
- Bara de replace inline
- Replace (inlocuieste selectia curenta)

### 12. Search → Replace All...
- Inlocuieste toate aparitiile in tab-ul curent sau in toate tab-urile

### 13. Search → All tabs / Selected tab
- Toggle pentru scopul cautarii/inlocuirii

### 14. View → Standard
- Colapeaza panoul Folder Explorer

### 15. View → Folder Explorer
- Expandeaza/colapeaza panoul lateral

### 16. Help → About
- Fereastra cu: **Numele studentului**, **Grupa**, **Link email institutional**

---

## BARA DE MENIURI

```
File  |  Search  |  View  |  Help
```

### File:
- New File (Ctrl+N)
- Open File... (Ctrl+O)
- ─────────────
- Save File (Ctrl+S)
- Save File As... (Ctrl+Shift+S)
- ─────────────
- Close All Files
- ─────────────
- Exit

### Search:
- Find... (Ctrl+F)
- Replace... (Ctrl+H)
- Replace All...
- ─────────────
- Search in: All Tabs / Selected Tab (toggle)

### View:
- Standard
- Folder Explorer (Ctrl+E)

### Help:
- About

---

## BARA DE BUTOANE (TOOLBAR)

| Buton | Actiune |
|-------|---------|
| 📄 | New File |
| 📂 | Open File |
| 💾 | Save File |
| 📑 | Save File As |
| 🔍 | Find |
| 🔄 | Replace |
| 📁 | Toggle Folder Explorer |
| ✖ | Close All Files |

---

## PERSONALIZARE (AboutWindow.xaml)

In fisierul `AboutWindow.xaml`, modifica:
```xml
<TextBlock Text="Student Name" .../>      <!-- Numele tau -->
<TextBlock Text="Group XYZ" .../>         <!-- Grupa ta -->
<Hyperlink NavigateUri="mailto:student@university.edu">
    student@university.edu               <!-- Email-ul tau institutional -->
</Hyperlink>
```

---

## NOTA TEHNICA

- Tema vizuala: **Dark theme** (inspirat din JetBrains / VS Code)
- Font editor: **Consolas** (monospaced)
- Encoding fisiere: **UTF-8**
- Folder tree: **lazy loading** (incarca continutul la expandare)
- Status bar: afiseaza linia si coloana curenta + encoding
