using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;

namespace NotepadPlusPlus
{
    /// <summary>
    /// Represents the data associated with each editor tab.
    /// </summary>
    public class TabData
    {
        private static int _newFileCounter = 0;

        public TextBox Editor { get; set; }
        public string? FilePath { get; set; }
        public bool IsSaved { get; set; }
        public string DisplayName { get; private set; }
        public TabItem TabItem { get; set; }

        // Track original content to detect changes
        private string _savedContent = string.Empty;

        public TabData(TabItem tabItem, TextBox editor, string? filePath = null)
        {
            TabItem = tabItem;
            Editor = editor;
            FilePath = filePath;
            IsSaved = filePath != null;

            if (filePath != null)
            {
                DisplayName = System.IO.Path.GetFileName(filePath);
            }
            else
            {
                _newFileCounter++;
                DisplayName = $"File {_newFileCounter}";
            }

            UpdateTabHeader();
        }

        public string SavedContent
        {
            get => _savedContent;
            set => _savedContent = value;
        }

        public bool HasUnsavedChanges => Editor.Text != _savedContent;

        public void MarkAsSaved()
        {
            _savedContent = Editor.Text;
            IsSaved = true;
            UpdateTabHeader();
        }

        public void UpdateFilePath(string newPath)
        {
            FilePath = newPath;
            DisplayName = System.IO.Path.GetFileName(newPath);
            UpdateTabHeader();
        }

        public void UpdateTabHeader()
        {
            // Build the tab header with close button
            var panel = new StackPanel { Orientation = Orientation.Horizontal };

            // File name text
            var nameText = new TextBlock
            {
                Text = DisplayName,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 4, 0),
                FontSize = 12
            };

            if (HasUnsavedChanges)
            {
                // Unsaved: show orange dot + name in orange
                nameText.Foreground = new SolidColorBrush(Color.FromRgb(0xFF, 0x8C, 0x00));

                var dot = new TextBlock
                {
                    Text = "●",
                    Foreground = new SolidColorBrush(Color.FromRgb(0xFF, 0x8C, 0x00)),
                    FontSize = 8,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 4, 0)
                };
                panel.Children.Add(dot);
            }
            else
            {
                nameText.Foreground = new SolidColorBrush(Color.FromRgb(0xA9, 0xB7, 0xC6));
            }

            panel.Children.Add(nameText);

            // Close button
            var closeBtn = new Button
            {
                Content = "✕",
                Background = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Foreground = new SolidColorBrush(Color.FromRgb(0x88, 0x88, 0x88)),
                FontSize = 10,
                Padding = new Thickness(2, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Cursor = System.Windows.Input.Cursors.Hand,
                Tag = this
            };

            closeBtn.MouseEnter += (s, e) =>
            {
                closeBtn.Foreground = new SolidColorBrush(Colors.White);
                closeBtn.Background = new SolidColorBrush(Color.FromRgb(0xCC, 0x44, 0x44));
            };
            closeBtn.MouseLeave += (s, e) =>
            {
                closeBtn.Foreground = new SolidColorBrush(Color.FromRgb(0x88, 0x88, 0x88));
                closeBtn.Background = Brushes.Transparent;
            };

            // The close button click is handled in MainWindow
            closeBtn.Click += (s, e) =>
            {
                var mainWindow = Application.Current.MainWindow as MainWindow;
                mainWindow?.CloseTab(this);
                e.Handled = true;
            };

            panel.Children.Add(closeBtn);
            TabItem.Header = panel;
        }

        public static void ResetCounter() => _newFileCounter = 0;
    }
}
