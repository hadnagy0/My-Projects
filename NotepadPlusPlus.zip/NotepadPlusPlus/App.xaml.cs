using System.Windows;

namespace NotepadPlusPlus
{
    public partial class App : Application
    {
    }
}
