using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace NotepadPlusPlus
{
    public partial class MainWindow : Window
    {
        // ─── State ───────────────────────────────────────────────────────────
        private readonly List<TabData> _tabs = new();
        private TabData? _currentTab;
        private bool _searchAllTabs = true;       // true = All Tabs, false = Selected Tab
        private string? _currentFindText;
        private int _findStartIndex = 0;

        // Folder explorer state
        private string? _copiedFolderPath;

        // Find/Replace mode
        private enum FindMode { Find, Replace, ReplaceAll }
        private FindMode _findMode = FindMode.Find;

        // ─── Keyboard shortcuts ──────────────────────────────────────────────
        public static readonly RoutedCommand NewFileCmd = new();
        public static readonly RoutedCommand OpenFileCmd = new();
        public static readonly RoutedCommand SaveFileCmd = new();
        public static readonly RoutedCommand SaveFileAsCmd = new();
        public static readonly RoutedCommand FindCmd = new();
        public static readonly RoutedCommand ReplaceCmd = new();
        public static readonly RoutedCommand FolderExplorerCmd = new();

        public MainWindow()
        {
            InitializeComponent();
            SetupKeyBindings();
            NewTab(); // Start with one empty tab
            UpdateStatus("Ready");
        }

        // ════════════════════════════════════════════════════════════════════
        //  KEYBOARD BINDINGS
        // ════════════════════════════════════════════════════════════════════
        private void SetupKeyBindings()
        {
            CommandBindings.Add(new CommandBinding(NewFileCmd, (s, e) => NewTab()));
            CommandBindings.Add(new CommandBinding(OpenFileCmd, (s, e) => OpenFile()));
            CommandBindings.Add(new CommandBinding(SaveFileCmd, (s, e) => SaveFile()));
            CommandBindings.Add(new CommandBinding(SaveFileAsCmd, (s, e) => SaveFileAs()));
            CommandBindings.Add(new CommandBinding(FindCmd, (s, e) => ShowFind()));
            CommandBindings.Add(new CommandBinding(ReplaceCmd, (s, e) => ShowReplace()));
            CommandBindings.Add(new CommandBinding(FolderExplorerCmd, (s, e) => ToggleFolderExplorer()));

            InputBindings.Add(new KeyBinding(NewFileCmd, Key.N, ModifierKeys.Control));
            InputBindings.Add(new KeyBinding(OpenFileCmd, Key.O, ModifierKeys.Control));
            InputBindings.Add(new KeyBinding(SaveFileCmd, Key.S, ModifierKeys.Control));
            InputBindings.Add(new KeyBinding(SaveFileAsCmd, Key.S, ModifierKeys.Control | ModifierKeys.Shift));
            InputBindings.Add(new KeyBinding(FindCmd, Key.F, ModifierKeys.Control));
            InputBindings.Add(new KeyBinding(ReplaceCmd, Key.H, ModifierKeys.Control));
            InputBindings.Add(new KeyBinding(FolderExplorerCmd, Key.E, ModifierKeys.Control));
        }

        // ════════════════════════════════════════════════════════════════════
        //  TAB MANAGEMENT
        // ════════════════════════════════════════════════════════════════════

        /// <summary>Creates a new empty tab and selects it.</summary>
        private TabData NewTab(string? filePath = null, string? content = null)
        {
            var editor = CreateEditor();
            var tabItem = new TabItem
            {
                Style = (Style)FindResource("TabItemStyle")
            };

            var tabData = new TabData(tabItem, editor, filePath);

            if (content != null)
            {
                editor.Text = content;
                tabData.SavedContent = content;
                tabData.UpdateTabHeader();
            }

            // Wire text-change tracking
            editor.TextChanged += (s, e) => OnEditorTextChanged(tabData);

            // Wire caret position tracking
            editor.SelectionChanged += (s, e) => UpdateLineCol(editor);

            tabItem.Content = editor;
            MainTabControl.Items.Add(tabItem);
            MainTabControl.SelectedItem = tabItem;

            _tabs.Add(tabData);
            _currentTab = tabData;
            UpdateEmptyHint();
            UpdateStatus($"New file created: {tabData.DisplayName}");
            return tabData;
        }

        private TextBox CreateEditor()
        {
            return new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(0x2B, 0x2B, 0x2B)),
                Foreground = new SolidColorBrush(Color.FromRgb(0xA9, 0xB7, 0xC6)),
                CaretBrush = new SolidColorBrush(Colors.White),
                SelectionBrush = new SolidColorBrush(Color.FromArgb(0x80, 0x58, 0x9D, 0xF6)),
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                FontSize = 14,
                AcceptsReturn = true,
                AcceptsTab = true,
                TextWrapping = TextWrapping.NoWrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(8),
                VerticalContentAlignment = VerticalAlignment.Top
            };
        }

        private void OnEditorTextChanged(TabData tabData)
        {
            tabData.UpdateTabHeader();
        }

        /// <summary>Closes a tab, prompting to save if needed. Returns false if user cancels.</summary>
        public bool CloseTab(TabData tabData)
        {
            if (tabData.HasUnsavedChanges)
            {
                var result = MessageBox.Show(
                    $"'{tabData.DisplayName}' has unsaved changes.\n\nSave before closing?",
                    "Unsaved Changes",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    if (!SaveTabToFile(tabData)) return false; // Save cancelled
                }
                else if (result == MessageBoxResult.Cancel)
                    return false;
            }

            MainTabControl.Items.Remove(tabData.TabItem);
            _tabs.Remove(tabData);

            if (_tabs.Count == 0)
            {
                _currentTab = null;
                UpdateEmptyHint();
            }

            UpdateStatus("File closed");
            return true;
        }

        // ════════════════════════════════════════════════════════════════════
        //  FILE OPERATIONS
        // ════════════════════════════════════════════════════════════════════

        private void NewFile()  => NewTab();

        private void OpenFile()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Open File",
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                DefaultExt = ".txt"
            };

            if (dlg.ShowDialog() == true)
                OpenFileInTab(dlg.FileName);
        }

        private void OpenFileInTab(string filePath)
        {
            // Check if already open
            var existing = _tabs.FirstOrDefault(t => t.FilePath == filePath);
            if (existing != null)
            {
                MainTabControl.SelectedItem = existing.TabItem;
                return;
            }

            try
            {
                var content = File.ReadAllText(filePath);
                var tab = NewTab(filePath, content);
                tab.MarkAsSaved();
                UpdateStatus($"Opened: {filePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not open file:\n{ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool SaveFile()
        {
            if (_currentTab == null) return false;
            return SaveTabToFile(_currentTab);
        }

        private bool SaveFileAs()
        {
            if (_currentTab == null) return false;
            return SaveTabToFileAs(_currentTab);
        }

        private bool SaveTabToFile(TabData tabData)
        {
            if (tabData.FilePath == null)
                return SaveTabToFileAs(tabData);

            try
            {
                File.WriteAllText(tabData.FilePath, tabData.Editor.Text);
                tabData.MarkAsSaved();
                UpdateStatus($"Saved: {tabData.FilePath}");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not save file:\n{ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private bool SaveTabToFileAs(TabData tabData)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Save File As",
                Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                DefaultExt = ".txt",
                FileName = tabData.FilePath ?? tabData.DisplayName
            };

            if (dlg.ShowDialog() != true) return false;

            tabData.UpdateFilePath(dlg.FileName);
            return SaveTabToFile(tabData);
        }

        private void CloseAllFiles()
        {
            var tabsCopy = _tabs.ToList();
            foreach (var tab in tabsCopy)
            {
                if (!CloseTab(tab)) return; // User cancelled
            }
        }

        // ════════════════════════════════════════════════════════════════════
        //  FIND / REPLACE
        // ════════════════════════════════════════════════════════════════════

        private void ShowFind()
        {
            _findMode = FindMode.Find;
            FindReplaceMode.Text = "Find:";
            ReplaceLabel.Visibility = Visibility.Collapsed;
            ReplaceTextBox.Visibility = Visibility.Collapsed;
            ReplaceBtn.Visibility = Visibility.Collapsed;
            ReplaceAllBtn.Visibility = Visibility.Collapsed;
            FindReplaceBar.Visibility = Visibility.Visible;
            FindTextBox.Focus();
            FindTextBox.SelectAll();
            UpdateScopeIndicator();
        }

        private void ShowReplace()
        {
            _findMode = FindMode.Replace;
            FindReplaceMode.Text = "Replace:";
            ReplaceLabel.Visibility = Visibility.Visible;
            ReplaceTextBox.Visibility = Visibility.Visible;
            ReplaceBtn.Visibility = Visibility.Visible;
            ReplaceAllBtn.Visibility = Visibility.Visible;
            FindReplaceBar.Visibility = Visibility.Visible;
            FindTextBox.Focus();
            FindTextBox.SelectAll();
            UpdateScopeIndicator();
        }

        private void ShowReplaceAll()
        {
            _findMode = FindMode.ReplaceAll;
            ShowReplace();
        }

        private void UpdateScopeIndicator()
        {
            ScopeIndicator.Text = _searchAllTabs ? "[All Tabs]" : "[Selected Tab]";
        }

        private void FindNext(bool showNotFound = true)
        {
            var searchText = FindTextBox.Text;
            if (string.IsNullOrEmpty(searchText)) return;

            if (_searchAllTabs)
                FindNextInAllTabs(searchText, showNotFound);
            else
                FindNextInCurrentTab(searchText, showNotFound);
        }

        private void FindNextInCurrentTab(string searchText, bool showNotFound)
        {
            if (_currentTab == null) return;
            var editor = _currentTab.Editor;
            var text = editor.Text;
            var startIdx = editor.SelectionStart + (editor.SelectionLength > 0 ? editor.SelectionLength : 0);

            var idx = text.IndexOf(searchText, startIdx, StringComparison.OrdinalIgnoreCase);
            if (idx < 0) idx = text.IndexOf(searchText, 0, StringComparison.OrdinalIgnoreCase); // wrap

            if (idx >= 0)
            {
                editor.Focus();
                editor.Select(idx, searchText.Length);
                editor.ScrollToLine(editor.GetLineIndexFromCharacterIndex(idx));
                UpdateStatus($"Found at position {idx}");
            }
            else if (showNotFound)
            {
                MessageBox.Show($"'{searchText}' not found.", "Find", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void FindNextInAllTabs(string searchText, bool showNotFound)
        {
            if (_tabs.Count == 0) return;

            // Search from current tab forward
            int currentTabIndex = _currentTab != null ? _tabs.IndexOf(_currentTab) : 0;

            for (int i = 0; i < _tabs.Count; i++)
            {
                var tabIndex = (currentTabIndex + i) % _tabs.Count;
                var tab = _tabs[tabIndex];
                var text = tab.Editor.Text;
                var startPos = (i == 0 && _currentTab != null)
                    ? _currentTab.Editor.SelectionStart + _currentTab.Editor.SelectionLength
                    : 0;

                var idx = text.IndexOf(searchText, startPos, StringComparison.OrdinalIgnoreCase);
                if (idx < 0 && i == 0)
                    idx = text.IndexOf(searchText, 0, StringComparison.OrdinalIgnoreCase);

                if (idx >= 0)
                {
                    MainTabControl.SelectedItem = tab.TabItem;
                    tab.Editor.Focus();
                    tab.Editor.Select(idx, searchText.Length);
                    tab.Editor.ScrollToLine(tab.Editor.GetLineIndexFromCharacterIndex(idx));
                    UpdateStatus($"Found in '{tab.DisplayName}' at position {idx}");
                    return;
                }
            }

            if (showNotFound)
                MessageBox.Show($"'{searchText}' not found in any open file.", "Find",
                    MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ReplaceOne()
        {
            if (_currentTab == null) return;
            var searchText = FindTextBox.Text;
            var replaceText = ReplaceTextBox.Text;
            if (string.IsNullOrEmpty(searchText)) return;

            var editor = _currentTab.Editor;

            // If current selection matches search text, replace it
            if (editor.SelectedText.Equals(searchText, StringComparison.OrdinalIgnoreCase))
            {
                int selStart = editor.SelectionStart;
                editor.SelectedText = replaceText;
                editor.Select(selStart, replaceText.Length);
                UpdateStatus("Replaced 1 occurrence");
            }

            // Find next
            FindNext(false);
        }

        private void ReplaceAll()
        {
            var searchText = FindTextBox.Text;
            var replaceText = ReplaceTextBox.Text;
            if (string.IsNullOrEmpty(searchText)) return;

            var tabsToProcess = _searchAllTabs ? _tabs : (_currentTab != null ? new List<TabData> { _currentTab } : new List<TabData>());
            int totalReplaced = 0;

            foreach (var tab in tabsToProcess)
            {
                var original = tab.Editor.Text;
                var replaced = System.Text.RegularExpressions.Regex.Replace(
                    original, System.Text.RegularExpressions.Regex.Escape(searchText),
                    replaceText, System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                if (replaced != original)
                {
                    int count = (original.Length - original.Replace(searchText, "", StringComparison.OrdinalIgnoreCase).Length) / searchText.Length;
                    totalReplaced += count;
                    tab.Editor.Text = replaced;
                }
            }

            UpdateStatus($"Replaced {totalReplaced} occurrence(s)" + (_searchAllTabs ? " in all tabs" : " in current tab"));
            MessageBox.Show($"Replaced {totalReplaced} occurrence(s).", "Replace All",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // ════════════════════════════════════════════════════════════════════
        //  FOLDER EXPLORER
        // ════════════════════════════════════════════════════════════════════

        private void OpenFolder()
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select a folder to explore",
                UseDescriptionForTitle = true
            };

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                LoadFolderTree(dlg.SelectedPath);
        }

        private void LoadFolderTree(string rootPath)
        {
            FolderTreeView.Items.Clear();
            var rootItem = CreateTreeItem(rootPath, isDirectory: true);
            FolderTreeView.Items.Add(rootItem);
            rootItem.IsExpanded = true;
            UpdateStatus($"Folder: {rootPath}");
        }

        private TreeViewItem CreateTreeItem(string path, bool isDirectory)
        {
            var item = new TreeViewItem
            {
                Tag = new FileSystemItem { Path = path, IsDirectory = isDirectory },
                Foreground = new SolidColorBrush(Color.FromRgb(0xA9, 0xB7, 0xC6))
            };

            var panel = new StackPanel { Orientation = Orientation.Horizontal };

            var icon = new TextBlock
            {
                Text = isDirectory ? "📁 " : GetFileIcon(path),
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center
            };
            panel.Children.Add(icon);

            var name = new TextBlock
            {
                Text = Path.GetFileName(path),
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center
            };
            if (!isDirectory)
                name.Foreground = new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC));

            panel.Children.Add(name);
            item.Header = panel;

            if (isDirectory)
            {
                // Add dummy child to show expand arrow
                item.Items.Add(new TreeViewItem { Header = "Loading...", Foreground = Brushes.Gray });
                item.Expanded += DirectoryItem_Expanded;
                item.ContextMenu = (ContextMenu)FindResource("FolderContextMenu");
            }

            return item;
        }

        private string GetFileIcon(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return ext switch
            {
                ".txt" => "📄 ",
                ".cs" => "📝 ",
                ".xml" or ".xaml" => "📋 ",
                ".json" => "📋 ",
                ".png" or ".jpg" or ".jpeg" or ".gif" or ".bmp" => "🖼 ",
                ".exe" or ".dll" => "⚙ ",
                ".zip" or ".rar" or ".7z" => "📦 ",
                _ => "📄 "
            };
        }

        private void DirectoryItem_Expanded(object sender, RoutedEventArgs e)
        {
            var item = (TreeViewItem)sender;
            if (item.Items.Count == 1 && item.Items[0] is TreeViewItem dummy && dummy.Header?.ToString() == "Loading...")
            {
                item.Items.Clear();
                var fsi = (FileSystemItem)item.Tag;

                try
                {
                    // Add subdirectories
                    foreach (var dir in Directory.GetDirectories(fsi.Path).OrderBy(d => d))
                    {
                        item.Items.Add(CreateTreeItem(dir, isDirectory: true));
                    }
                    // Add files
                    foreach (var file in Directory.GetFiles(fsi.Path).OrderBy(f => f))
                    {
                        item.Items.Add(CreateTreeItem(file, isDirectory: false));
                    }

                    // Update folder icon to open
                    if (item.Header is StackPanel panel && panel.Children[0] is TextBlock iconBlock)
                        iconBlock.Text = "📂 ";
                }
                catch (UnauthorizedAccessException)
                {
                    item.Items.Add(new TreeViewItem
                    {
                        Header = "⛔ Access Denied",
                        Foreground = Brushes.Red
                    });
                }
            }
            e.Handled = true;
        }

        private void ToggleFolderExplorer()
        {
            if (FolderExplorerPanel.Visibility == Visibility.Visible)
            {
                FolderExplorerPanel.Visibility = Visibility.Collapsed;
                // Collapse the splitter column too
                var grid = FolderExplorerPanel.Parent as Grid;
                if (grid != null)
                {
                    grid.ColumnDefinitions[0].Width = new GridLength(0);
                    grid.ColumnDefinitions[1].Width = new GridLength(0);
                }
            }
            else
            {
                FolderExplorerPanel.Visibility = Visibility.Visible;
                var grid = FolderExplorerPanel.Parent as Grid;
                if (grid != null)
                {
                    grid.ColumnDefinitions[0].Width = new GridLength(230);
                    grid.ColumnDefinitions[1].Width = new GridLength(4);
                }
            }
        }

        // ════════════════════════════════════════════════════════════════════
        //  FOLDER CONTEXT MENU ACTIONS
        // ════════════════════════════════════════════════════════════════════

        private TreeViewItem? _rightClickedItem;

        private void FolderContextMenu_NewFile(object sender, RoutedEventArgs e)
        {
            if (_rightClickedItem?.Tag is not FileSystemItem fsi || !fsi.IsDirectory) return;

            var dialog = new InputDialog("New File", "Enter file name:", "NewFile.txt") { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                var newPath = Path.Combine(fsi.Path, dialog.InputText);
                try
                {
                    File.WriteAllText(newPath, "");
                    RefreshTreeItem(_rightClickedItem);
                    OpenFileInTab(newPath);
                    UpdateStatus($"Created: {newPath}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Could not create file:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void FolderContextMenu_CopyPath(object sender, RoutedEventArgs e)
        {
            if (_rightClickedItem?.Tag is not FileSystemItem fsi) return;
            Clipboard.SetText(fsi.Path);
            UpdateStatus($"Path copied: {fsi.Path}");
        }

        private void FolderContextMenu_CopyFolder(object sender, RoutedEventArgs e)
        {
            if (_rightClickedItem?.Tag is not FileSystemItem fsi || !fsi.IsDirectory) return;
            _copiedFolderPath = fsi.Path;
            UpdateStatus($"Folder copied: {fsi.Path}");
        }

        private void FolderContextMenu_PasteFolder(object sender, RoutedEventArgs e)
        {
            if (_rightClickedItem?.Tag is not FileSystemItem fsi || !fsi.IsDirectory) return;
            if (_copiedFolderPath == null) return;

            try
            {
                var destPath = Path.Combine(fsi.Path, Path.GetFileName(_copiedFolderPath));
                CopyDirectory(_copiedFolderPath, destPath);
                RefreshTreeItem(_rightClickedItem);
                UpdateStatus($"Folder pasted to: {destPath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not paste folder:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static void CopyDirectory(string sourceDir, string destDir)
        {
            Directory.CreateDirectory(destDir);
            foreach (var file in Directory.GetFiles(sourceDir))
            {
                File.Copy(file, Path.Combine(destDir, Path.GetFileName(file)), overwrite: true);
            }
            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                CopyDirectory(dir, Path.Combine(destDir, Path.GetFileName(dir)));
            }
        }

        private void RefreshTreeItem(TreeViewItem item)
        {
            if (item.Tag is not FileSystemItem fsi || !fsi.IsDirectory) return;

            // Update icon back to closed folder
            if (item.Header is StackPanel panel && panel.Children[0] is TextBlock iconBlock)
                iconBlock.Text = "📁 ";

            item.Items.Clear();
            item.Items.Add(new TreeViewItem { Header = "Loading...", Foreground = Brushes.Gray });
            item.IsExpanded = false;
        }

        // ════════════════════════════════════════════════════════════════════
        //  HELPER / UI UPDATE
        // ════════════════════════════════════════════════════════════════════

        private void UpdateStatus(string message)
        {
            StatusText.Text = message;
        }

        private void UpdateLineCol(TextBox editor)
        {
            int lineIndex = editor.GetLineIndexFromCharacterIndex(editor.CaretIndex);
            int colIndex = editor.CaretIndex - editor.GetCharacterIndexFromLineIndex(lineIndex);
            LineColText.Text = $"Ln {lineIndex + 1}, Col {colIndex + 1}";
        }

        private void UpdateEmptyHint()
        {
            EmptyHint.Visibility = _tabs.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        // ════════════════════════════════════════════════════════════════════
        //  MENU / BUTTON EVENT HANDLERS
        // ════════════════════════════════════════════════════════════════════

        private void NewFile_Click(object sender, RoutedEventArgs e) => NewFile();
        private void OpenFile_Click(object sender, RoutedEventArgs e) => OpenFile();
        private void SaveFile_Click(object sender, RoutedEventArgs e) => SaveFile();
        private void SaveFileAs_Click(object sender, RoutedEventArgs e) => SaveFileAs();

        private void CloseAllFiles_Click(object sender, RoutedEventArgs e) => CloseAllFiles();

        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        private void Find_Click(object sender, RoutedEventArgs e) => ShowFind();
        private void Replace_Click(object sender, RoutedEventArgs e) => ShowReplace();
        private void ReplaceAll_Click(object sender, RoutedEventArgs e) => ShowReplaceAll();

        private void ToggleSearchScope_Click(object sender, RoutedEventArgs e)
        {
            _searchAllTabs = !_searchAllTabs;
            SearchScopeMenuItem.Header = _searchAllTabs ? "Search in: _All Tabs" : "Search in: _Selected Tab";
            UpdateScopeIndicator();
            UpdateStatus(_searchAllTabs ? "Search scope: All Tabs" : "Search scope: Selected Tab");
        }

        private void ViewStandard_Click(object sender, RoutedEventArgs e)
        {
            // Collapse folder explorer if open
            if (FolderExplorerPanel.Visibility == Visibility.Visible)
                ToggleFolderExplorer();
        }

        private void ViewFolderExplorer_Click(object sender, RoutedEventArgs e) => ToggleFolderExplorer();

        private void About_Click(object sender, RoutedEventArgs e)
        {
            new AboutWindow { Owner = this }.ShowDialog();
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e) => OpenFolder();

        // Find/Replace bar buttons
        private void FindNext_Click(object sender, RoutedEventArgs e) => FindNext();
        private void ReplaceOne_Click(object sender, RoutedEventArgs e) => ReplaceOne();
        private void ReplaceAllAction_Click(object sender, RoutedEventArgs e) => ReplaceAll();
        private void CloseFindReplace_Click(object sender, RoutedEventArgs e)
        {
            FindReplaceBar.Visibility = Visibility.Collapsed;
            _currentTab?.Editor.Focus();
        }

        private void FindTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) FindNext();
            if (e.Key == Key.Escape) FindReplaceBar.Visibility = Visibility.Collapsed;
        }

        // Tab selection changed
        private void MainTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MainTabControl.SelectedItem is TabItem selectedTabItem)
            {
                _currentTab = _tabs.FirstOrDefault(t => t.TabItem == selectedTabItem);
                if (_currentTab != null)
                {
                    Title = $"{_currentTab.DisplayName} - NotepadPlusPlus";
                    UpdateLineCol(_currentTab.Editor);
                }
            }
        }

        // TreeView double-click (open file)
        private void FolderTreeView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (FolderTreeView.SelectedItem is TreeViewItem item &&
                item.Tag is FileSystemItem fsi && !fsi.IsDirectory)
            {
                OpenFileInTab(fsi.Path);
                e.Handled = true;
            }
        }

        // Right-click in TreeView
        private void FolderTreeView_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Update Paste Folder menu item enabled state
            if (FindResource("FolderContextMenu") is ContextMenu cm)
            {
                foreach (var menuItem in cm.Items.OfType<MenuItem>())
                {
                    if (menuItem.Header?.ToString() == "Paste Folder")
                        menuItem.IsEnabled = _copiedFolderPath != null;
                }
            }
        }

        private void TreeViewItem_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TreeViewItem item && item.Tag is FileSystemItem fsi && fsi.IsDirectory)
            {
                item.IsSelected = true;
                _rightClickedItem = item;
                e.Handled = true;
            }
        }

        // Window closing - prompt to save unsaved files
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            var unsaved = _tabs.Where(t => t.HasUnsavedChanges).ToList();
            if (unsaved.Count > 0)
            {
                var names = string.Join("\n  • ", unsaved.Select(t => t.DisplayName));
                var result = MessageBox.Show(
                    $"The following files have unsaved changes:\n\n  • {names}\n\nSave all before exiting?",
                    "Unsaved Changes",
                    MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    foreach (var tab in unsaved)
                        if (!SaveTabToFile(tab)) { e.Cancel = true; return; }
                }
                else if (result == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                    return;
                }
            }
            base.OnClosing(e);
        }
    }

    // ─── Helper types ────────────────────────────────────────────────────────

    public class FileSystemItem
    {
        public string Path { get; set; } = "";
        public bool IsDirectory { get; set; }
    }
}
