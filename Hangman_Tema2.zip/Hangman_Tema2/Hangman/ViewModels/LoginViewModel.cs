using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using Hangman.Commands;
using Hangman.Models;
using Hangman.Services;
using Microsoft.Win32;

namespace Hangman.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly DataService _dataService;

        public ObservableCollection<User> Users { get; } = new();

        private User? _selectedUser;
        public User? SelectedUser
        {
            get => _selectedUser;
            set
            {
                SetProperty(ref _selectedUser, value);
                OnPropertyChanged(nameof(IsUserSelected));
            }
        }

        public bool IsUserSelected => _selectedUser != null;

        private string _newUsername = string.Empty;
        public string NewUsername
        {
            get => _newUsername;
            set => SetProperty(ref _newUsername, value);
        }

        private string _selectedImagePath = string.Empty;
        public string SelectedImagePath
        {
            get => _selectedImagePath;
            set
            {
                SetProperty(ref _selectedImagePath, value);
                OnPropertyChanged(nameof(HasImage));
            }
        }

        public bool HasImage => !string.IsNullOrEmpty(_selectedImagePath);

        public ObservableCollection<string> PredefinedImages { get; } = new();
        private int _predefinedIndex = 0;

        public ICommand PlayCommand { get; }
        public ICommand DeleteUserCommand { get; }
        public ICommand NewUserCommand { get; }
        public ICommand BrowseImageCommand { get; }
        public ICommand SaveNewUserCommand { get; }
        public ICommand NextImageCommand { get; }
        public ICommand PrevImageCommand { get; }

        public event Action<User>? PlayRequested;
        public event Action? NewUserPanelRequested;

        public LoginViewModel()
        {
            _dataService = new DataService();
            _dataService.EnsureDefaultWords();

            PlayCommand = new RelayCommand(_ => Play(), _ => IsUserSelected);
            DeleteUserCommand = new RelayCommand(_ => DeleteUser(), _ => IsUserSelected);
            NewUserCommand = new RelayCommand(_ => NewUserPanelRequested?.Invoke());
            BrowseImageCommand = new RelayCommand(_ => BrowseImage());
            SaveNewUserCommand = new RelayCommand(_ => SaveNewUser(), _ => !string.IsNullOrWhiteSpace(NewUsername));
            NextImageCommand = new RelayCommand(_ => CyclePredefined(1));
            PrevImageCommand = new RelayCommand(_ => CyclePredefined(-1));

            LoadPredefinedImages();
            LoadUsers();
        }

        private void LoadPredefinedImages()
        {
            var dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Images", "Users");
            if (Directory.Exists(dir))
            {
                foreach (var f in Directory.GetFiles(dir, "*.jpg").Concat(Directory.GetFiles(dir, "*.png")).Concat(Directory.GetFiles(dir, "*.gif")))
                    PredefinedImages.Add(MakeRelative(f));
            }
            if (PredefinedImages.Count == 0)
                PredefinedImages.Add(string.Empty); 

            SelectedImagePath = PredefinedImages[0];
        }

        private void CyclePredefined(int direction)
        {
            if (PredefinedImages.Count == 0) return;
            _predefinedIndex = (_predefinedIndex + direction + PredefinedImages.Count) % PredefinedImages.Count;
            SelectedImagePath = PredefinedImages[_predefinedIndex];
        }

        private void LoadUsers()
        {
            Users.Clear();
            foreach (var u in _dataService.LoadUsers())
                Users.Add(u);
        }

        private void Play()
        {
            if (_selectedUser != null)
                PlayRequested?.Invoke(_selectedUser);
        }

        private void DeleteUser()
        {
            if (_selectedUser == null) return;
            var result = MessageBox.Show($"Delete user '{_selectedUser.Username}'?\nAll saves and statistics will be erased.",
                "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result != MessageBoxResult.Yes) return;
            _dataService.DeleteUser(_selectedUser.Username);
            LoadUsers();
            SelectedUser = null;
        }

        private void BrowseImage()
        {
            var dlg = new OpenFileDialog
            {
                Title = "Select Avatar Image",
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp"
            };
            if (dlg.ShowDialog() == true)
                SelectedImagePath = MakeRelative(dlg.FileName);
        }

        private void SaveNewUser()
        {
            var name = NewUsername.Trim();
            if (string.IsNullOrEmpty(name) || name.Contains(' '))
            {
                MessageBox.Show("Username must be a single word (no spaces).", "Invalid Username", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var existing = _dataService.LoadUsers();
            if (existing.Any(u => u.Username.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Username already exists.", "Duplicate", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var user = new User { Username = name, ImagePath = SelectedImagePath };
            _dataService.AddUser(user);
            LoadUsers();
            SelectedUser = Users.FirstOrDefault(u => u.Username == name);
            NewUsername = string.Empty;
        }

        private static string MakeRelative(string absolutePath)
        {
            var baseUri = new Uri(AppDomain.CurrentDomain.BaseDirectory);
            try
            {
                var fileUri = new Uri(absolutePath);
                return baseUri.MakeRelativeUri(fileUri).ToString().Replace('/', Path.DirectorySeparatorChar);
            }
            catch { return absolutePath; }
        }
    }
}
