using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Hangman.Commands;
using Hangman.Models;
using Hangman.Services;

namespace Hangman.ViewModels
{
    public class LetterItem : ViewModelBase
    {
        private bool _isEnabled = true;
        public char Letter { get; set; }
        public bool IsEnabled
        {
            get => _isEnabled;
            set => SetProperty(ref _isEnabled, value);
        }
    }

    public class GameViewModel : ViewModelBase
    {
        private readonly DataService _dataService;
        private readonly DispatcherTimer _timer;
        private const int MaxWrong = 6;
        private const double GameDuration = 30.0;
        private const int LevelsToWin = 3;

        public User CurrentUser { get; }

        private string _currentWord = string.Empty;
        private string _currentCategory = "All Categories";
        private List<char> _guessedLetters = new();
        private int _wrongGuesses;
        private int _consecutiveLevel;    
        private double _timeRemaining;
        private bool _gameActive;


        public ObservableCollection<LetterItem> Alphabet { get; } = new();

        private string _wordDisplay = string.Empty;
        public string WordDisplay
        {
            get => _wordDisplay;
            private set => SetProperty(ref _wordDisplay, value);
        }

        private string _categoryDisplay = "All Categories";
        public string CategoryDisplay
        {
            get => _categoryDisplay;
            set => SetProperty(ref _categoryDisplay, value);
        }

        public int WrongGuesses
        {
            get => _wrongGuesses;
            private set
            {
                SetProperty(ref _wrongGuesses, value);
                OnPropertyChanged(nameof(HangmanImagePath));
                OnPropertyChanged(nameof(LivesDisplay));
            }
        }

        public int ConsecutiveLevel
        {
            get => _consecutiveLevel;
            private set
            {
                if (SetProperty(ref _consecutiveLevel, value))
                {
                    OnPropertyChanged(nameof(LevelDisplay));
                }
            }
        }

        public string LevelDisplay => $"⭐ Level: {ConsecutiveLevel}/3";

        public double TimeRemaining
        {
            get => _timeRemaining;
            private set
            {
                SetProperty(ref _timeRemaining, value);
                OnPropertyChanged(nameof(TimeDisplay));
            }
        }

        public string TimeDisplay => $"{(int)_timeRemaining}s";

        public string LivesDisplay => $"❌ {_wrongGuesses} / {MaxWrong}";

        public string HangmanImagePath
        {
            get
            {
                var dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Images", "Hangman");
                var file = Path.Combine(dir, $"hangman{_wrongGuesses}.png");
                if (File.Exists(file)) return file;
                return string.Empty;
            }
        }

        private string _statusMessage = string.Empty;
        public string StatusMessage
        {
            get => _statusMessage;
            private set => SetProperty(ref _statusMessage, value);
        }

        public string UserImagePath
        {
            get
            {
                var rel = CurrentUser.ImagePath;
                if (string.IsNullOrEmpty(rel)) return string.Empty;
                var abs = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rel);
                return File.Exists(abs) ? abs : rel;
            }
        }

        public ICommand NewGameCommand { get; }
        public ICommand SaveGameCommand { get; }
        public ICommand OpenGameCommand { get; }
        public ICommand ShowStatisticsCommand { get; }
        public ICommand CancelCommand { get; }
        public ICommand GuessLetterCommand { get; }
        public ICommand SetCategoryCommand { get; }

        public event Action? CancelRequested;
        public event Action<List<UserStatistics>>? ShowStatisticsRequested;
        public event Func<string?>? SaveNameRequested;
        public event Func<List<string>, string?>? OpenGameRequested;

        public GameViewModel(User user)
        {
            CurrentUser = user;
            _dataService = new DataService();

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += TimerTick;

            NewGameCommand = new RelayCommand(_ => { ConsecutiveLevel = 0; StartNewGame(); });
            SaveGameCommand = new RelayCommand(_ => SaveGame(), _ => _gameActive);
            OpenGameCommand = new RelayCommand(_ => OpenGame());
            ShowStatisticsCommand = new RelayCommand(_ => ShowStats());
            CancelCommand = new RelayCommand(_ => { _timer.Stop(); CancelRequested?.Invoke(); });
            GuessLetterCommand = new RelayCommand(p => GuessLetter((char)p!));
            SetCategoryCommand = new RelayCommand(p => SetCategory((string)p!));

            BuildAlphabet();
            StatusMessage = "Select File → New Game to start!";
        }


        private void SetCategory(string category)
        {
            _currentCategory = category;
            CategoryDisplay = category;
            ConsecutiveLevel = 0;
            StartNewGame();
        }

       
        public void StartNewGame()
        {
            _timer.Stop();
            var words = _dataService.GetWords(_currentCategory);
            if (words.Count == 0)
            {
                MessageBox.Show("No words found for this category.", "No Words", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var rng = new Random();
            _currentWord = words[rng.Next(words.Count)];
            _guessedLetters = new List<char>();
            WrongGuesses = 0;
            TimeRemaining = GameDuration;
            _gameActive = true;
            (SaveGameCommand as RelayCommand)?.RaiseCanExecuteChanged();
            StatusMessage = string.Empty;
            ResetAlphabet();
            UpdateWordDisplay();
            _timer.Start();
        }


        private void GuessLetter(char letter)
        {
            if (!_gameActive || _guessedLetters.Contains(letter)) return;
            _guessedLetters.Add(letter);

            var item = Alphabet.FirstOrDefault(a => a.Letter == letter);
            if (item != null) item.IsEnabled = false;

            if (_currentWord.Contains(letter))
            {
                UpdateWordDisplay();
                if (CheckWin()) OnWin();
            }
            else
            {
                WrongGuesses++;
                if (WrongGuesses >= MaxWrong) OnLose();
            }
        }

        public void HandleKeyPress(char letter)
        {
            letter = char.ToUpper(letter);
            if (letter >= 'A' && letter <= 'Z')
            {
                var item = Alphabet.FirstOrDefault(a => a.Letter == letter);
                if (item != null && item.IsEnabled)
                    GuessLetter(letter);
            }
        }


        private bool CheckWin()
            => _currentWord.All(c => _guessedLetters.Contains(c));

        private void OnWin()
        {
            _timer.Stop();
            _gameActive = false;
            ConsecutiveLevel++;
            StatusMessage = $"🎉 Correct! Level {ConsecutiveLevel}/{LevelsToWin}";

            if (ConsecutiveLevel >= LevelsToWin)
            {
                _dataService.RecordGame(CurrentUser.Username, _currentCategory, won: true);
                ConsecutiveLevel = 0;
                (SaveGameCommand as RelayCommand)?.RaiseCanExecuteChanged();
                MessageBox.Show("🏆 You won the game! 3 consecutive words guessed!", "Victory!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                var r = MessageBox.Show($"Word guessed! Level {ConsecutiveLevel}/{LevelsToWin}. Continue to next word?",
                    "Level Complete", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (r == MessageBoxResult.Yes) StartNewGame();
            }
        }

        private void OnLose()
        {
            _timer.Stop();
            _gameActive = false;
            (SaveGameCommand as RelayCommand)?.RaiseCanExecuteChanged();
            StatusMessage = $"💀 Game Over! The word was: {_currentWord}";
            _dataService.RecordGame(CurrentUser.Username, _currentCategory, won: false);
            ConsecutiveLevel = 0;
            RevealWord();
            MessageBox.Show($"Game over! The word was: {_currentWord}", "You Lost", MessageBoxButton.OK, MessageBoxImage.Exclamation);
        }


        private void TimerTick(object? s, EventArgs e)
        {
            TimeRemaining--;
            if (TimeRemaining <= 0) OnLose();
        }


        private void SaveGame()
        {
            var name = SaveNameRequested?.Invoke();
            if (string.IsNullOrWhiteSpace(name)) return;
            _timer.Stop();
            var state = new GameState
            {
                Username = CurrentUser.Username,
                SaveName = name,
                Category = _currentCategory,
                Word = _currentWord,
                GuessedLetters = new List<char>(_guessedLetters),
                WrongGuesses = _wrongGuesses,
                Level = _consecutiveLevel,
                TimeRemaining = _timeRemaining,
                SavedAt = DateTime.Now
            };
            _dataService.SaveGame(state);
            MessageBox.Show($"Game saved as '{name}'.", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
            if (_gameActive) _timer.Start();
        }

        private void OpenGame()
        {
            _timer.Stop();
            var saves = _dataService.GetSavesForUser(CurrentUser.Username)
                                    .Select(s => s.Substring(CurrentUser.Username.Length + 1))
                                    .ToList();
            if (saves.Count == 0)
            {
                MessageBox.Show("No saved games found.", "Open Game", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var saveName = OpenGameRequested?.Invoke(saves);
            if (string.IsNullOrEmpty(saveName)) return;

            var state = _dataService.LoadGame(CurrentUser.Username, saveName);
            if (state == null)
            {
                MessageBox.Show("Could not load save.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            RestoreState(state);
        }

        private void RestoreState(GameState state)
        {
            _currentWord = state.Word;
            _currentCategory = state.Category;
            CategoryDisplay = state.Category;
            _guessedLetters = new List<char>(state.GuessedLetters);
            WrongGuesses = state.WrongGuesses;
            ConsecutiveLevel = state.Level;
            TimeRemaining = state.TimeRemaining;
            _gameActive = true;
            (SaveGameCommand as RelayCommand)?.RaiseCanExecuteChanged();
            ResetAlphabet();
            foreach (var c in _guessedLetters)
            {
                var item = Alphabet.FirstOrDefault(a => a.Letter == c);
                if (item != null) item.IsEnabled = false;
            }
            UpdateWordDisplay();
            _timer.Start();
        }

        private void ShowStats()
        {
            var stats = _dataService.LoadStatistics();
            ShowStatisticsRequested?.Invoke(stats);
        }


        private void BuildAlphabet()
        {
            for (char c = 'A'; c <= 'Z'; c++)
                Alphabet.Add(new LetterItem { Letter = c, IsEnabled = true });
        }

        private void ResetAlphabet()
        {
            foreach (var item in Alphabet)
                item.IsEnabled = true;
        }

        private void UpdateWordDisplay()
        {
            WordDisplay = string.Join(" ", _currentWord.Select(c => _guessedLetters.Contains(c) ? c.ToString() : "_"));
        }

        private void RevealWord()
        {
            WordDisplay = string.Join(" ", _currentWord);
        }
    }
}
