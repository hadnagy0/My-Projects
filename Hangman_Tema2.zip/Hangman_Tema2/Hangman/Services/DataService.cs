using System.IO;
using Newtonsoft.Json;
using Hangman.Models;

namespace Hangman.Services
{
    public class DataService
    {
        private static readonly string BaseDir = AppDomain.CurrentDomain.BaseDirectory;
        private static readonly string DataDir = Path.Combine(BaseDir, "Data");
        private static readonly string UsersFile = Path.Combine(DataDir, "users.json");
        private static readonly string StatsFile = Path.Combine(DataDir, "statistics.json");
        private static readonly string SavesDir = Path.Combine(DataDir, "Saves");
        private static readonly string WordsDir = Path.Combine(BaseDir, "Assets", "Words");

        public DataService()
        {
            Directory.CreateDirectory(DataDir);
            Directory.CreateDirectory(SavesDir);
            Directory.CreateDirectory(WordsDir);
        }


        public List<User> LoadUsers()
        {
            if (!File.Exists(UsersFile)) return new List<User>();
            var json = File.ReadAllText(UsersFile);
            return JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
        }

        public void SaveUsers(List<User> users)
        {
            File.WriteAllText(UsersFile, JsonConvert.SerializeObject(users, Formatting.Indented));
        }

        public void AddUser(User user)
        {
            var users = LoadUsers();
            users.Add(user);
            SaveUsers(users);
        }

        public void DeleteUser(string username)
        {
            var users = LoadUsers();
            users.RemoveAll(u => u.Username == username);
            SaveUsers(users);

            var saves = GetSavesForUser(username);
            foreach (var save in saves)
            {
                var path = Path.Combine(SavesDir, save + ".json");
                if (File.Exists(path)) File.Delete(path);
            }

            var stats = LoadStatistics();
            stats.RemoveAll(s => s.Username == username);
            SaveStatistics(stats);
        }


        public List<string> GetCategories()
        {
            if (!Directory.Exists(WordsDir)) return new List<string>();
            return Directory.GetFiles(WordsDir, "*.txt")
                            .Select(f => Path.GetFileNameWithoutExtension(f))
                            .ToList();
        }

        public List<string> GetWords(string category)
        {
            if (category == "All Categories")
            {
                var all = new List<string>();
                foreach (var cat in GetCategories())
                    all.AddRange(GetWordsFromFile(cat));
                return all;
            }
            return GetWordsFromFile(category);
        }

        private List<string> GetWordsFromFile(string category)
        {
            var file = Path.Combine(WordsDir, category + ".txt");
            if (!File.Exists(file)) return new List<string>();
            return File.ReadAllLines(file)
                       .Select(l => l.Trim().ToUpper())
                       .Where(l => !string.IsNullOrEmpty(l))
                       .ToList();
        }

        public void EnsureDefaultWords()
        {
            CreateWordFile("Cars", new[] { "FERRARI", "LAMBORGHINI", "PORSCHE", "MUSTANG", "CORVETTE", "BUGATTI", "MCLAREN", "ASTON", "BENTLEY", "ROLLS" });
            CreateWordFile("Movies", new[] { "INCEPTION", "TITANIC", "AVATAR", "GLADIATOR", "MATRIX", "INTERSTELLAR", "JOKER", "PARASITE", "GRAVITY", "TENET" });
            CreateWordFile("Rivers", new[] { "AMAZON", "NILE", "DANUBE", "MISSISSIPPI", "VOLGA", "YANGTZE", "GANGES", "RHINE", "THAMES", "MEKONG" });
            CreateWordFile("Countries", new[] { "ROMANIA", "FRANCE", "GERMANY", "BRAZIL", "JAPAN", "AUSTRALIA", "CANADA", "MEXICO", "INDIA", "EGYPT" });
            CreateWordFile("Animals", new[] { "ELEPHANT", "GIRAFFE", "PENGUIN", "DOLPHIN", "CHEETAH", "KANGAROO", "FLAMINGO", "CROCODILE", "JAGUAR", "PANDA" });
        }

        private void CreateWordFile(string category, string[] words)
        {
            var file = Path.Combine(WordsDir, category + ".txt");
            if (!File.Exists(file))
                File.WriteAllLines(file, words);
        }


        public List<string> GetSavesForUser(string username)
        {
            return Directory.GetFiles(SavesDir, $"{username}_*.json")
                            .Select(f => Path.GetFileNameWithoutExtension(f))
                            .ToList();
        }

        public void SaveGame(GameState state)
        {
            var key = $"{state.Username}_{state.SaveName}";
            var path = Path.Combine(SavesDir, key + ".json");
            File.WriteAllText(path, JsonConvert.SerializeObject(state, Formatting.Indented));
        }

        public GameState? LoadGame(string username, string saveName)
        {
            var key = $"{username}_{saveName}";
            var path = Path.Combine(SavesDir, key + ".json");
            if (!File.Exists(path)) return null;
            var json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<GameState>(json);
        }

        public void DeleteSave(string username, string saveName)
        {
            var key = $"{username}_{saveName}";
            var path = Path.Combine(SavesDir, key + ".json");
            if (File.Exists(path)) File.Delete(path);
        }


        public List<UserStatistics> LoadStatistics()
        {
            if (!File.Exists(StatsFile)) return new List<UserStatistics>();
            var json = File.ReadAllText(StatsFile);
            return JsonConvert.DeserializeObject<List<UserStatistics>>(json) ?? new List<UserStatistics>();
        }

        public void SaveStatistics(List<UserStatistics> stats)
        {
            File.WriteAllText(StatsFile, JsonConvert.SerializeObject(stats, Formatting.Indented));
        }

        public void RecordGame(string username, string category, bool won)
        {
            var stats = LoadStatistics();
            var user = stats.FirstOrDefault(s => s.Username == username);
            if (user == null)
            {
                user = new UserStatistics { Username = username };
                stats.Add(user);
            }
            if (!user.Categories.ContainsKey(category))
                user.Categories[category] = new CategoryStat();
            user.Categories[category].GamesPlayed++;
            if (won) user.Categories[category].GamesWon++;
            SaveStatistics(stats);
        }
    }
}
