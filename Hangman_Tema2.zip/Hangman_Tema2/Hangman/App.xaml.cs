using System.Windows;

namespace Hangman
{
    public partial class App : Application
    {
    }
}
