using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Hangman.Models;
using Hangman.Services;
using Hangman.ViewModels;

namespace Hangman.Views
{
    public partial class GameWindow : Window
    {
        private readonly GameViewModel _vm;
        private readonly DataService _dataService;

        public event Action? GameClosed;

        public GameWindow(User user)
        {
            InitializeComponent();
            _dataService = new DataService();
            _vm = new GameViewModel(user);
            DataContext = _vm;

            _vm.CancelRequested += OnCancel;
            _vm.ShowStatisticsRequested += OnShowStatistics;
            _vm.SaveNameRequested += OnSaveNameRequested;
            _vm.OpenGameRequested += OnOpenGameRequested;
            _vm.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(_vm.HangmanImagePath))
                    UpdateHangmanImage();
                if (e.PropertyName == nameof(_vm.TimeRemaining))
                    UpdateTimerColor();
            };

            LoadCategories();
            LoadUserAvatar(user);
        }

        private void LoadCategories()
        {
            var categories = _dataService.GetCategories();
            foreach (var cat in categories)
            {
                var item = new System.Windows.Controls.MenuItem
                {
                    Header = cat,
                    Command = _vm.SetCategoryCommand,
                    CommandParameter = cat
                };
                CategoriesMenu.Items.Add(item);
            }
        }

        private void LoadUserAvatar(User user)
        {
            if (string.IsNullOrEmpty(user.ImagePath)) return;
            var abs = Path.IsPathRooted(user.ImagePath)
                ? user.ImagePath
                : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, user.ImagePath);
            if (File.Exists(abs))
            {
                try { UserAvatar.Source = new BitmapImage(new Uri(abs)); }
                catch { }
            }
        }

        private void UpdateHangmanImage()
        {
            var path = _vm.HangmanImagePath;
            if (!string.IsNullOrEmpty(path) && File.Exists(path))
            {
                try { HangmanImage.Source = new BitmapImage(new Uri(path)); }
                catch { }
            }
            else
            {
                HangmanImage.Source = null;
            }
        }

        private void UpdateTimerColor()
        {
            TimerLabel.Foreground = _vm.TimeRemaining <= 10
                ? System.Windows.Media.Brushes.OrangeRed
                : System.Windows.Media.Brushes.White;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.A && e.Key <= Key.Z)
            {
                var letter = (char)('A' + (e.Key - Key.A));
                _vm.HandleKeyPress(letter);
                e.Handled = true;
            }
        }

        private void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            var win = new AboutWindow();
            win.Owner = this;
            win.ShowDialog();
        }

        private void OnCancel()
        {
            GameClosed?.Invoke();
            this.Close();
        }

        private void OnShowStatistics(List<UserStatistics> stats)
        {
            var win = new StatisticsWindow(stats);
            win.Owner = this;
            win.ShowDialog();
        }

        private string? OnSaveNameRequested()
        {
            var dlg = new InputDialog("Save Game", "Enter a name for this save:");
            dlg.Owner = this;
            if (dlg.ShowDialog() == true)
                return dlg.InputValue;
            return null;
        }

        private string? OnOpenGameRequested(List<string> saves)
        {
            var dlg = new SelectSaveDialog(saves);
            dlg.Owner = this;
            if (dlg.ShowDialog() == true)
                return dlg.SelectedSave;
            return null;
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            GameClosed?.Invoke();
        }
    }
}
