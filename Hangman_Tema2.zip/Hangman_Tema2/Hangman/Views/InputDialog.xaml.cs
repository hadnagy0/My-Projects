using System.Windows;
using System.Windows.Input;

namespace Hangman.Views
{
    public partial class InputDialog : Window
    {
        public string InputValue { get; private set; } = string.Empty;

        public InputDialog(string title, string prompt)
        {
            InitializeComponent();
            Title = title;
            PromptLabel.Text = prompt;
            InputBox.Focus();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e) => Confirm();
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) Confirm();
            else if (e.Key == Key.Escape) { DialogResult = false; Close(); }
        }

        private void Confirm()
        {
            var val = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(val))
            {
                System.Windows.MessageBox.Show("Please enter a value.", "Required",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
           
            foreach (var c in System.IO.Path.GetInvalidFileNameChars())
                val = val.Replace(c.ToString(), "");
            InputValue = val;
            DialogResult = true;
            Close();
        }
    }
}
