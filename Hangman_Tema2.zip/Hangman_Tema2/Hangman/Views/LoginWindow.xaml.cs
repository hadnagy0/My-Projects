using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using Hangman.Models;
using Hangman.ViewModels;

namespace Hangman.Views
{
    public partial class LoginWindow : Window
    {
        private readonly LoginViewModel _vm;

        public LoginWindow()
        {
            InitializeComponent();
            _vm = new LoginViewModel();
            DataContext = _vm;

            _vm.PlayRequested += OnPlayRequested;
            _vm.NewUserPanelRequested += ToggleNewUserPanel;
            _vm.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(_vm.SelectedUser) || e.PropertyName == nameof(_vm.SelectedImagePath))
                    UpdateAvatar();
            };
        }

        private void UpdateAvatar()
        {
        
            string path = _vm.SelectedUser?.ImagePath ?? _vm.SelectedImagePath ?? string.Empty;
            if (!string.IsNullOrEmpty(path))
            {
                var abs = Path.IsPathRooted(path) ? path : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
                if (File.Exists(abs))
                {
                    try
                    {
                        AvatarImage.Source = new BitmapImage(new Uri(abs));
                        return;
                    }
                    catch { }
                }
            }
            AvatarImage.Source = null;
        }

        private void ToggleNewUserPanel()
        {
            NewUserPanel.Visibility = NewUserPanel.Visibility == Visibility.Visible
                ? Visibility.Collapsed : Visibility.Visible;

            if (NewUserPanel.Visibility == Visibility.Visible)
            {
                _vm.SelectedUser = null;
            }
            else
            {
                UpdateAvatar();
            }
        }

        private void NewUserButton_Click(object sender, RoutedEventArgs e){}

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void OnPlayRequested(User user)
        {
            var gameWindow = new GameWindow(user);
            gameWindow.GameClosed += () =>
            {
                this.Show();
            };
            this.Hide();
            gameWindow.Show();
        }
    }
}
