using System.Windows;
using System.Windows.Input;

namespace Hangman.Views
{
    public partial class SelectSaveDialog : Window
    {
        public string? SelectedSave { get; private set; }

        public SelectSaveDialog(List<string> saves)
        {
            InitializeComponent();
            SavesList.ItemsSource = saves;
            if (saves.Count > 0) SavesList.SelectedIndex = 0;
        }

        private void OpenButton_Click(object sender, RoutedEventArgs e) => Confirm();
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void SavesList_DoubleClick(object sender, MouseButtonEventArgs e) => Confirm();

        private void Confirm()
        {
            if (SavesList.SelectedItem is string selected)
            {
                SelectedSave = selected;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please select a save.", "No Selection",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
