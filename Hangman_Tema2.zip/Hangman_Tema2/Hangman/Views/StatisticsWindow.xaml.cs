using System.Windows;
using Hangman.Models;

namespace Hangman.Views
{
    public partial class StatisticsWindow : Window
    {
        public StatisticsWindow(List<UserStatistics> stats)
        {
            InitializeComponent();

            var rows = new List<StatRow>();
            foreach (var user in stats)
            {
                foreach (var kvp in user.Categories)
                {
                    rows.Add(new StatRow
                    {
                        Username = user.Username,
                        Category = kvp.Key,
                        GamesPlayed = kvp.Value.GamesPlayed,
                        GamesWon = kvp.Value.GamesWon,
                        WinRate = kvp.Value.GamesPlayed > 0
                            ? $"{(kvp.Value.GamesWon * 100 / kvp.Value.GamesPlayed)}%"
                            : "0%"
                    });
                }
                if (!user.Categories.Any())
                    rows.Add(new StatRow { Username = user.Username, Category = "–", GamesPlayed = 0, GamesWon = 0, WinRate = "0%" });
            }
            StatsGrid.ItemsSource = rows;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();
    }

    public class StatRow
    {
        public string Username { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public int GamesPlayed { get; set; }
        public int GamesWon { get; set; }
        public string WinRate { get; set; } = "0%";
    }
}
