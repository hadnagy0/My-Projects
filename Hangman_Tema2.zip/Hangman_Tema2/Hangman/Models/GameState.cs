namespace Hangman.Models
{
    public class GameState
    {
        public string Username { get; set; } = string.Empty;
        public string SaveName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Word { get; set; } = string.Empty;
        public List<char> GuessedLetters { get; set; } = new();
        public int WrongGuesses { get; set; }
        public int Level { get; set; }          
        public double TimeRemaining { get; set; }
        public DateTime SavedAt { get; set; } = DateTime.Now;
    }
}
