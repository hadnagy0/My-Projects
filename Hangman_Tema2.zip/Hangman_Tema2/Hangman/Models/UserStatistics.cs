namespace Hangman.Models
{
    public class UserStatistics
    {
        public string Username { get; set; } = string.Empty;
        public Dictionary<string, CategoryStat> Categories { get; set; } = new();
    }

    public class CategoryStat
    {
        public int GamesPlayed { get; set; }
        public int GamesWon { get; set; }
    }
}
